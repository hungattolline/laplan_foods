<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * MailChimp Form Shortcode
 *
 * @param string $atts['title']
 * @param string $atts['id']
 * @param string $atts['style']
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 * @param string $atts['css']
 */

if ( ! function_exists( 'bakery_mailchimp_form_shortcode' ) ) {
	function bakery_mailchimp_form_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'title' => '',
			'description' => '',
			'id' => '',
			'style' => '',
			'class' => '',
			'css' => ''
		), $atts, 'vu_mailchimp_form' );

		if ( function_exists( 'vc_shortcode_custom_css_class' ) ) {
			$atts['class'] .= ' ' . vc_shortcode_custom_css_class( $atts['css'] );
		}

		$atts['class'] = trim( $atts['class'] );

		ob_start(); ?>
		<div class="vu_mailchimp-form vu_mcf-style-<?php echo esc_attr( $atts['style'] ); ?> clearfix<?php bakery_extra_class( $atts['class'] ); ?>">
			<?php if ( ! empty( $atts['title'] ) ) : ?>
				<h4 class="vu_mcf-title"><?php echo esc_html( $atts['title'] ); ?></h4>
			<?php endif; ?>

			<?php if ( ! empty( $atts['description'] ) ) : ?>
				<div class="vu_mcf-description">
					<?php echo wpautop( $atts['description'] ); ?>
				</div>
			<?php endif; ?>

			<?php echo do_shortcode( bakery_generate_shortcode( 'mc4wp_form', array( 'id' => $atts['id'] ), $content ) ); ?>
		</div>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_mailchimp_form', 'bakery_mailchimp_form_shortcode' );

/**
 * MailChimp Form VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_mailchimp_form' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_mailchimp_form extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_mailchimp_form', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_mailchimp_form', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'MailChimp Form', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Newsletter/Subscribe', 'bakery-shortcodes' ),
			'base' => 'vu_mailchimp_form',
			'class' => 'vc_vu_mailchimp_form',
			'icon' => 'vu_element-icon vu_mailchimp-form-icon',
			'controls' => 'full',
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Title', 'bakery-shortcodes' ),
					'param_name' => 'title',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter form title. Leave blank if no title is needed.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textarea',
					'heading' => esc_html__( 'Description', 'bakery-shortcodes' ),
					'param_name' => 'description',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter form description.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'select2',
					'heading' => esc_html__( 'Form', 'bakery-shortcodes' ),
					'param_name' => 'id',
					'admin_label' => true,
					'options' => array(
						'source' => admin_url( 'admin-ajax.php?action=bakery_get_mc4wp' ),
						'tags' => true
					),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select MailChimp form.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Style', 'bakery-shortcodes' ),
					'param_name' => 'style',
					'value' => array(
						esc_html__( 'Default', 'bakery-shortcodes' ) => 'default',
						esc_html__( 'Inverse', 'bakery-shortcodes' ) => 'inverse'
					),
					'save_always' => true,
					'description' => esc_html__( 'Select form style.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Design Options', 'bakery-shortcodes' ),
					'type' => 'css_editor',
					'heading' => esc_html__( 'CSS box', 'bakery-shortcodes' ),
					'param_name' => 'css'
				)
			)
		)
	);
}
