<?php if ( ! defined( 'ABSPATH' ) ) exit();
	
/**
 * Blog Shortcode
 *
 * @param string $atts['query']
 * @param string $atts['type']
 * @param string $atts['layout']
 * @param string $atts['ratio']
 * @param string $atts['show_date']
 * @param string $atts['show_author']
 * @param string $atts['show_categories']
 * @param string $atts['show_comments']
 * @param string $atts['show_content']
 * @param string $atts['num_of_words']
 * @param string $atts['show_pagination']
 * @param string $atts['c_show_navigation']
 * @param string $atts['c_navigation_position']
 * @param string $atts['c_show_pagination']
 * @param string $atts['c_autoplay']
 * @param string $atts['c_stop_on_hover']
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 */

if ( ! function_exists( 'bakery_blog_shortcode' ) ) {
	function bakery_blog_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'query' => '',
			'type' => '',
			'layout' => '',
			'ratio' => '',
			'show_date' => '',
			'show_author' => '',
			'show_categories' => '',
			'show_comments' => '',
			'show_content' => '',
			'num_of_words' => '',
			'show_pagination' => '',
			'c_show_navigation' => '',
			'c_navigation_position' => '',
			'c_show_pagination' => '',
			'c_autoplay' => '',
			'c_stop_on_hover' => '',
			'class' => '',
			'css' => ''
		), $atts, 'vu_blog' );

		if ( stripos( $atts['query'], 'post_type:post' ) === false ){
			$atts['query'] .= '|post_type:post';
		}

		if ( $atts['type'] == 'grid' && $atts['show_pagination'] == '1' ) {
			$atts['query'] .= '|paged:' . get_query_var( 'paged' );
		}

		$BakeryVcLoopQueryBuilder = new BakeryVcLoopQueryBuilder( esc_attr( $atts['query'] ) );
		$blog_query = $BakeryVcLoopQueryBuilder->build();

		if ( function_exists( 'vc_shortcode_custom_css_class' ) ) {
			$atts['class'] .= ' ' . vc_shortcode_custom_css_class( $atts['css'] );
		}

		if ( $atts['type'] == 'carousel' && $atts['c_show_navigation'] == '1' && ! empty( $atts['c_navigation_position'] ) ) {
			$custom_class = bakery_custom_class();
			$atts['class'] .= ' ' . $custom_class;
		}

		$atts['class'] = trim( $atts['class'] );

		ob_start(); ?>
		<div class="vu_blog vu_b-type-<?php echo esc_attr( $atts['type'] ); ?> vu_b-layout-<?php echo esc_attr( $atts['layout'] ); ?> clearfix<?php bakery_extra_class( $atts['class'] ); ?>">
			<?php if ( $atts['type'] == 'carousel' ) : 
				$carousel_options = array(
					'singleItem' => false,
					'items' => absint( $atts['layout'] ),
					'itemsDesktop' => array( 1199, absint( $atts['layout'] ) ),
					'itemsDesktopSmall' => array( 980, 2 ),
					'itemsTablet' => array( 768, 2 ),
					'itemsMobile' => array( 479, 1 ),
					'navigation' => ( $atts['c_show_navigation'] == '1' ) ? true : false,
					'navigationText' => array( '<i class="fa fa-arrow-left" aria-hidden="true"></i>', '<i class="fa fa-arrow-right" aria-hidden="true"></i>' ),
					'pagination' => ( $atts['c_show_pagination'] == '1' ) ? true : false,
					'autoHeight' => true,
					'rewindNav' => true,
					'scrollPerPage' => true,
					'autoPlay' => ( $atts['c_autoplay'] == '' || $atts['c_autoplay'] == '0' ) ? false : absint( $atts['c_autoplay'] ),
					'stopOnHover' => ( $atts['c_stop_on_hover'] == '1' ) ? true : false
				);
				
				if ( $atts['c_show_navigation'] == '1' && ! empty( $atts['c_navigation_position'] ) ) : ?>
					<style scoped>.vu_blog.<?php echo esc_attr( $custom_class ); ?> .vu_carousel .owl-buttons .owl-prev, .vu_blog.<?php echo esc_attr( $custom_class ); ?> .vu_carousel .owl-buttons .owl-next { top: <?php echo esc_attr( $atts['c_navigation_position'] ); ?>; margin-top: -25px; }</style>
				<?php endif; ?>
				<div class="vu_b-carousel vu_carousel" data-options="<?php echo esc_attr( json_encode( $carousel_options ) ); ?>">
			<?php else : ?>
				<div class="row">
			<?php endif; ?>
				<?php if ( $blog_query->have_posts() ) : while( $blog_query->have_posts() ): $blog_query->the_post(); ?>
					<?php if ( $atts['type'] != 'carousel' ) : ?>
						<div class="vu_b-item-wrap col-md-<?php echo (12 / absint( $atts['layout'] ) ); ?> col-sm-6 col-xs-12">
					<?php endif; ?>
						<article <?php post_class( 'vu_blog-item' ); ?> data-id="<?php the_ID(); ?>">
							<?php if ( has_post_thumbnail() ) : ?>
								<div class="vu_bi-image">
									<a href="<?php the_permalink(); ?>" title="<?php echo esc_attr( get_the_title() ); ?>">
										<?php the_post_thumbnail( 'bakery_ratio-' . esc_attr( $atts['ratio'] ) ); ?>
									</a>
								</div>
							<?php endif; ?>

							<div class="vu_bi-content-wrapper">
								<header class="vu_bi-header">
									<h3 class="vu_bi-title">
										<a href="<?php the_permalink(); ?>" title="<?php echo esc_attr( get_the_title() ); ?>"><?php the_title(); ?></a>
									</h3>
								</header>

								<?php if ( $atts['show_content'] == '1' ) : ?>
									<div class="vu_bi-content">
										<?php bakery_the_excerpt( absint( $atts['num_of_words'] ) ); ?>
									</div>
								<?php endif; ?>

								<footer class="vu_bi-footer">
									<?php if ( $atts['show_author'] == '1' || $atts['show_date'] == '1' || $atts['show_categories'] == '1' || $atts['show_comments'] == '1' ) : ?>
										<div class="vu_bi-meta">
											<?php if ( $atts['show_author'] == '1' ) : ?>
												<span class="vu_bi-m-item vu_bi-author">
													<i class="fa fa-user-o"></i>
													<a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>" title="<?php esc_attr_e( 'Posts by', 'bakery-shortcodes' ); ?> <?php the_author(); ?>"><span><?php the_author(); ?></span></a>
												</span>
											<?php endif; ?>

											<?php if ( $atts['show_date'] == '1' ) : ?>
												<span class="vu_bi-m-item vu_bi-date">
													<i class="fa fa-calendar-o"></i>
													<time><?php echo get_the_date( get_option( 'date_format' ) ); ?></time>
												</span>
											<?php endif; ?>

											<?php if ( $atts['show_categories'] == '1' ) : ?>
												<span class="vu_bi-m-item vu_bi-categories">
													<i class="fa fa-folder-open-o"></i>
													<?php the_category( ', ' ); ?>	
												</span>
											<?php endif; ?>

											<?php if ( $atts['show_comments'] == '1' ) : ?>
												<span class="vu_bi-m-item vu_bi-comments">
													<i class="fa fa-comment-o"></i>
													<a href="<?php comments_link(); ?>"><?php comments_number( esc_html__( 'No Comments', 'bakery-shortcodes' ), esc_html__( 'One Comment ', 'bakery-shortcodes' ), esc_html__( '% Comments', 'bakery-shortcodes' ) ); ?></a>
												</span>
											<?php endif; ?>
										</div>
									<?php endif; ?>
								</footer>
								<div class="clear"></div>
							</div>
						</article>
					<?php if ( $atts['type'] != 'carousel' ) : ?>
						</div>
					<?php endif; ?>
				<?php endwhile; endif; ?>
				<?php if ( $atts['type'] == 'grid' && $atts['show_pagination'] == '1' ) { bakery_pagination( $blog_query ); } ?>
				<?php wp_reset_query(); ?>
			</div>
		</div>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_blog', 'bakery_blog_shortcode' );

/**
 * Blog VC Shortcode
 */

 if ( ! class_exists( 'WPBakeryShortCode_vu_blog' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_blog extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_blog', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_blog', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'Blog', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Show blog posts', 'bakery-shortcodes' ),
			'base' => 'vu_blog',
			'class' => 'vc_vu_blog',
			'icon' => 'vu_element-icon vu_blog-icon',
			'controls' => 'full',
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'loop',
					'heading' => esc_html__( 'Blog Query', 'bakery-shortcodes' ),
					'param_name' => 'query',
					'settings' => array(
						'size' => array( 'hidden' => false, 'value' => '6' ),
						'order_by' => array( 'value' => 'date' ),
						'categories' => array( 'hidden' => false ),
						'tags' => array( 'hidden' => false ),
						'tax_query' => array( 'hidden' => true ),
						'authors' => array( 'hidden' => true ),
						'post_type' => array( 'hidden' => true, 'value' => 'post' )
					),
					'value' => 'size:6|order_by:date|post_type:post',
					'save_always' => true,
					'description' => esc_html__( 'Create WordPress loop, to show posts from your site.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'dropdown',
					'heading' => esc_html__( 'Type', 'bakery-shortcodes' ),
					'param_name' => 'type',
					'admin_label' => true,
					'value' =>  array(
						esc_html__( 'Grid', 'bakery-shortcodes' ) => 'grid',
						esc_html__( 'Carousel', 'bakery-shortcodes' ) => 'carousel'
					),
					'save_always' => true,
					'description' => esc_html__( 'Select blog type.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'dropdown',
					'heading' => esc_html__( 'Layout', 'bakery-shortcodes' ),
					'param_name' => 'layout',
					'admin_label' => true,
					'value' => array(
						esc_html__( '1 Column', 'bakery-shortcodes' ) => '1',
						esc_html__( '2 Columns', 'bakery-shortcodes' ) => '2',
						esc_html__( '3 Columns', 'bakery-shortcodes' ) => '3',
						esc_html__( '4 Columns', 'bakery-shortcodes' ) => '4'
					),
					'std' => '3',
					'save_always' => true,
					'description' => esc_html__( 'Select blog layout.', 'bakery-shortcodes' ),
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'dropdown',
					'heading' => esc_html__( 'Ratio', 'bakery-shortcodes' ),
					'param_name' => 'ratio',
					'value' => bakery_get_image_ratios(),
					'std' => '4:3',
					'save_always' => true,
					'description' => esc_html__( 'Select image ratio.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Show date', 'bakery-shortcodes' ),
					'param_name' => 'show_date',
					'value' =>  array( 'Yes, please!' => '1' ),
					'std' => '1',
					'save_always' => true,
					'description' => esc_html__( 'Check to show post date.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Show author', 'bakery-shortcodes' ),
					'param_name' => 'show_author',
					'value' =>  array( 'Yes, please!' => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Check to show post author.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Show categories', 'bakery-shortcodes' ),
					'param_name' => 'show_categories',
					'value' =>  array( 'Yes, please!' => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Check to show post categories.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Show comments', 'bakery-shortcodes' ),
					'param_name' => 'show_comments',
					'value' =>  array( 'Yes, please!' => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Check to show post comments.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Show content', 'bakery-shortcodes' ),
					'param_name' => 'show_content',
					'value' =>  array( 'Yes, please!' => '1' ),
					'std' => '1',
					'save_always' => true,
					'description' => esc_html__( 'Check to show post content.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of words', 'bakery-shortcodes' ),
					'param_name' => 'num_of_words',
					'dependency' => array( 'element' => 'show_content', 'value' => '1' ),
					'value' => '20',
					'save_always' => true,
					'description' => esc_html__( 'Enter number of words to show as excerpt.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Show pagination', 'bakery-shortcodes' ),
					'param_name' => 'show_pagination',
					'dependency' => array( 'element' => 'type', 'value' => 'grid' ),
					'value' =>  array( 'Yes, please!' => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Check to show blog pagination.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Carousel Options', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Show navigation', 'bakery-shortcodes' ),
					'param_name' => 'c_show_navigation',
					'dependency' => array( 'element' => 'type', 'value' => 'carousel' ),
					'value' =>  array( 'Yes, please!' => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Check to show carousel navigation.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Carousel Options', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Navigation Position', 'bakery-shortcodes' ),
					'param_name' => 'c_navigation_position',
					'dependency' => array( 'element' => 'c_show_navigation', 'value' => '1' ),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter distance of navigation from top. (Note: CSS measurement units allowed).', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Carousel Options', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Show pagination', 'bakery-shortcodes' ),
					'param_name' => 'c_show_pagination',
					'dependency' => array( 'element' => 'type', 'value' => 'carousel' ),
					'value' =>  array( 'Yes, please!' => '1' ),
					'std' => '1',
					'save_always' => true,
					'description' => esc_html__( 'Check to show carousel pagination.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Carousel Options', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Auto play', 'bakery-shortcodes' ),
					'param_name' => 'c_autoplay',
					'dependency' => array( 'element' => 'type', 'value' => 'carousel' ),
					'value' => '',
					'save_always' => true,
					'description' => wp_kses( __( 'Change to any integrer for example <b>5000</b> to play every <b>5</b> seconds. Leave blank to disable autoplay.', 'bakery-shortcodes' ), array( 'b' => array() ) )
				),
				array(
					'group' => esc_html__( 'Carousel Options', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Stop autoplay on mouse hover', 'bakery-shortcodes' ),
					'param_name' => 'c_stop_on_hover',
					'dependency' => array( 'element' => 'c_autoplay', 'not_empty' => true ),
					'value' =>  array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'save_always' => true,
					'description' => esc_html__( 'Check to stop carousel on hover.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Design Options', 'bakery-shortcodes' ),
					'type' => 'css_editor',
					'heading' => esc_html__( 'CSS box', 'bakery-shortcodes' ),
					'param_name' => 'css'
				)
			)
		)
	);
}
