<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * Share Buttons Shortcode
 *
 * @param string $atts['size']
 * @param string $atts['alignment']
 * @param string $atts['custom_colors']
 * @param string $atts['icons_normal_color']
 * @param string $atts['icons_normal_bg_color']
 * @param string $atts['icons_hover_color']
 * @param string $atts['icons_hover_bg_color']
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 * @param string $atts['facebook']
 * @param string $atts['twitter']
 * @param string $atts['google_plus']
 * @param string $atts['pinterest']
 * @param string $atts['linkedin']
 * @param string $atts['css']
 */

if ( ! function_exists( 'bakery_share_buttons_shortcode' ) ) {
	function bakery_share_buttons_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'size' => '',
			'alignment' => '',
			'custom_colors' => '',
			'icons_normal_color' => '',
			'icons_normal_bg_color' => '',
			'icons_hover_color' => '',
			'icons_hover_bg_color' => '',
			'class' => '',
			'facebook' => '',
			'twitter' => '',
			'google_plus' => '',
			'pinterest' => '',
			'linkedin' => '',
			'css' => ''
		), $atts, 'vu_share_buttons' );

		if ( $atts['custom_colors'] == '1' ) {
			$custom_class = bakery_custom_class();
			$atts['class'] .= ' ' . $custom_class;
		}

		if ( function_exists( 'vc_shortcode_custom_css_class' ) ) {
			$atts['class'] .= ' ' . vc_shortcode_custom_css_class( $atts['css'] );
		}

		$atts['class'] = trim( $atts['class'] );

		global $post;

		if ( $post ) {
			$url = get_permalink();
			$title = get_the_title();
			$post_id = get_the_ID();
		} else {
			$url = '#';
			$title = '';
			$post_id = 0;
		}

		ob_start(); ?>
		<div class="vu_share-buttons vu_sb-size-<?php echo esc_attr( $atts['size'] ); ?> vu_sb-alignment-<?php echo esc_attr( $atts['alignment'] ); ?><?php bakery_extra_class( $atts['class'] ); ?>">
				<?php if ( $atts['custom_colors'] == '1' ) : ?>
					<style scoped>
						<?php if ( ! empty( $atts['icons_normal_color'] ) || ! empty( $atts['icons_normal_bg_color'] ) ) : ?>
							<?php if ( ! empty( $atts['icons_normal_color'] ) ) : ?>
								.vu_share-buttons.<?php echo esc_attr( $custom_class ); ?> .vu_sb-icon a { color: <?php echo esc_attr( $atts['icons_normal_color'] ); ?> !important; }
							<?php endif; ?>
							<?php if ( ! empty( $atts['icons_normal_bg_color'] ) ) : ?>
								.vu_share-buttons.<?php echo esc_attr( $custom_class ); ?> .vu_sb-icon a { background-color: <?php echo esc_attr( $atts['icons_normal_bg_color'] ); ?> !important; }
							<?php endif; ?>
						<?php endif; ?>
						<?php if ( ! empty( $atts['icons_hover_color'] ) || ! empty( $atts['icons_hover_bg_color'] ) ) : ?>
							<?php if ( ! empty( $atts['icons_hover_color'] ) ) : ?>
								.vu_share-buttons.<?php echo esc_attr( $custom_class ); ?> .vu_sb-icon a:hover { color: <?php echo esc_attr( $atts['icons_hover_color'] ); ?> !important; }
							<?php endif; ?>
							<?php if ( ! empty( $atts['icons_hover_bg_color'] ) ) : ?>
								.vu_share-buttons.<?php echo esc_attr( $custom_class ); ?> .vu_sb-icon a:hover { background-color: <?php echo esc_attr( $atts['icons_hover_bg_color'] ); ?> !important; }
							<?php endif; ?>
						<?php endif; ?>
					</style>
				<?php endif; ?>
			<div class="vu_sb-container">
				<?php if ( $atts['facebook'] == '1' ) : ?>
					<div class="vu_sb-icon">
						<a href="#" class="vu_sb-btn vu_social-link" data-href="http://www.facebook.com/sharer.php?u=<?php echo esc_url( $url ); ?>&amp;t=<?php echo urlencode( $title ); ?>"><i class="fa fa-facebook" aria-hidden="true"></i></a>
					</div>
				<?php endif; ?>

				<?php if ( $atts['twitter'] == '1' ) : ?>
					<div class="vu_sb-icon">
						<a href="#" class="vu_sb-btn vu_social-link" data-href="https://twitter.com/share?text=<?php echo urlencode( $title ); ?>&amp;url=<?php echo esc_url( $url ); ?>"><i class="fa fa-twitter" aria-hidden="true"></i></a>
					</div>
				<?php endif; ?>

				<?php if ( $atts['google_plus'] == '1' ) : ?>
					<div class="vu_sb-icon">
						<a href="#" class="vu_sb-btn vu_social-link" data-href="https://plus.google.com/share?url=<?php echo esc_url( $url ); ?>"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
					</div>
				<?php endif; ?>

				<?php if ( $atts['pinterest'] == '1' ) : ?>
					<div class="vu_sb-icon">
						<a href="#" class="vu_sb-btn vu_social-link" data-href="http://pinterest.com/pin/create/button/?url=<?php echo urlencode( $url ); ?>&amp;description=<?php echo urlencode( $title ); ?>&amp;media=<?php echo bakery_get_attachment_image_src( $post_id, array( 705, 470 ) ); ?>"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
					</div>
				<?php endif; ?>

				<?php if ( $atts['linkedin'] == '1' ) : ?>
					<div class="vu_sb-icon">
						<a href="#" class="vu_sb-btn vu_social-link" data-href="http://linkedin.com/shareArticle?mini=true&amp;title=<?php echo urlencode( $title ); ?>&amp;url=<?php echo esc_url( $url ); ?>"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_share_buttons', 'bakery_share_buttons_shortcode' );

/**
 * Share Buttons VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_share_buttons' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_share_buttons extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_share_buttons', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_share_buttons', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'Share Buttons', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Social media share links', 'bakery-shortcodes' ),
			'base' => 'vu_share_buttons',
			'class' => 'vc_vu_share_buttons',
			'icon' => 'vu_element-icon vu_share-buttons-icon',
			'controls' => 'full',
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'dropdown',
					'heading' => esc_html__( 'Size', 'bakery-shortcodes' ),
					'param_name' => 'size',
					'admin_label' => true,
					'value' => array(
						esc_html__( 'Large', 'bakery-shortcodes' ) => 'large',
						esc_html__( 'Medium', 'bakery-shortcodes' ) => 'medium',
						esc_html__( 'Small', 'bakery-shortcodes' ) => 'small'
					),
					'std' => 'medium',
					'save_always' => true,
					'description' => esc_html__( 'Select icon size.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'dropdown',
					'heading' => esc_html__( 'Alignment', 'bakery-shortcodes' ),
					'param_name' => 'alignment',
					'admin_label' => true,
					'value' => array(
						esc_html__( 'Left', 'bakery-shortcodes' ) => 'left',
						esc_html__( 'Center', 'bakery-shortcodes' ) => 'center',
						esc_html__( 'Right', 'bakery-shortcodes' ) => 'right'
					),
					'std' => 'left',
					'save_always' => true,
					'description' => esc_html__( 'Select share buttons alignment.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Custom Colors?', 'bakery-shortcodes' ),
					'param_name' => 'custom_colors',
					'value' =>  array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Check to use custom colors.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Icons Normal Color', 'bakery-shortcodes' ),
					'param_name' => 'icons_normal_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-6',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select icons normal color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Icons Normal BG Color', 'bakery-shortcodes' ),
					'param_name' => 'icons_normal_bg_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-6',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select icons normal background color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Icons Hover Color', 'bakery-shortcodes' ),
					'param_name' => 'icons_hover_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-6',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select icons hover color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Icons Hover BG Color', 'bakery-shortcodes' ),
					'param_name' => 'icons_hover_bg_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-6',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select icons hover background color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Buttons', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column',
					'heading' => esc_html__( 'Share Buttons', 'bakery-shortcodes' ),
					'param_name' => 'facebook',
					'value' => array( esc_html__( 'Facebook', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true
				),
				array(
					'group' => esc_html__( 'Buttons', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-5',
					'param_name' => 'twitter',
					'value' => array( esc_html__( 'Twitter', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true
				),
				array(
					'group' => esc_html__( 'Buttons', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-5',
					'param_name' => 'google_plus',
					'value' => array( esc_html__( 'Google+', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true
				),
				array(
					'group' => esc_html__( 'Buttons', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-5',
					'param_name' => 'pinterest',
					'value' => array( esc_html__( 'Pinterest', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true
				),
				array(
					'group' => esc_html__( 'Buttons', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-5',
					'param_name' => 'linkedin',
					'value' => array( esc_html__( 'LinkedIn', 'bakery-shortcodes' ) => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Select which share buttons to be shown.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Design Options', 'bakery-shortcodes' ),
					'type' => 'css_editor',
					'heading' => esc_html__( 'CSS box', 'bakery-shortcodes' ),
					'param_name' => 'css'
				)
			)
		)
	);
}
