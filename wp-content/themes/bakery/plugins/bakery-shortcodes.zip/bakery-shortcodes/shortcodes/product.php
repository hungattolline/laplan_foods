<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * Product Shortcode
 *
 * @param string $atts['style']
 * @param string $atts['image']
 * @param string $atts['image_size']
 * @param string $atts['image_display']
 * @param string $atts['content_display']
 * @param string $atts['label']
 * @param string $atts['name']
 * @param string $atts['link']
 * @param string $atts['description']
 * @param string $atts['price']
 * @param string $atts['currency']
 * @param string $atts['show_zoom_icon']
 * @param string $atts['zoom_icon']
 * @param string $atts['show_link_icon']
 * @param string $atts['link_icon']
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 */

if ( ! function_exists( 'bakery_product_shortcode' ) ) {
	function bakery_product_shortcode( $atts = null, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'style' => '',
			'image' => '',
			'image_size' => '',
			'image_display' => '',
			'content_display' => '',
			'label' => '',
			'name' => '',
			'link' => '',
			'description' => '',
			'price' => '',
			'currency' => '',
			'show_zoom_icon' => '',
			'zoom_icon' => '',
			'show_link_icon' => '',
			'link_icon' => '',
			'class' => ''
		), $atts, 'vu_product' );

		$link = ( function_exists( 'vc_build_link' ) ) ? vc_build_link( $atts['link'] ) : array( 'url' => '', 'title' => '', 'target' => '' );

		ob_start(); ?>
		<article class="vu_product vu_p-style-<?php echo esc_attr( $atts['style'] ); ?> clearfix<?php bakery_extra_class( $atts['class'] ); ?>">
			<?php if ( ! empty( $atts['image'] ) ) : ?>
				<?php if ( $atts['style'] == '1' ) : ?>
					<div class="vu_p-image">
						<?php if ( empty( $link['url'] ) && $atts['show_zoom_icon'] == '1' ) : ?>
							<a href="<?php echo esc_url( bakery_get_attachment_image_src( absint( $atts['image'] ), 'full' ) ); ?>" title="<?php echo esc_attr( $atts['name'] ); ?>" class="vu_lightbox">
								<?php echo wp_get_attachment_image( $atts['image'], 'thumbnail', false ); ?>
								<span class="vu_p-i-cover"><i class="<?php echo esc_attr( $atts['zoom_icon'] ); ?>" aria-hidden="true"></i></span>
							</a>
						<?php else : ?>
							<?php echo wp_get_attachment_image( $atts['image'], 'thumbnail', false ); ?>
						<?php endif; ?>
					</div>
				<?php else : ?>
					<?php if ( ! empty( $atts['label'] ) ) : ?>
						<div class="vu_p-label">
							<span><?php echo esc_html( $atts['label'] ); ?></span>
						</div>
					<?php endif; ?>

					<?php if ( $atts['style'] == "2" || $atts['style'] == "3" ) : ?>
						<div class="vu_p-image vu_p-img-<?php echo esc_attr( $atts['image_display'] ); ?> vu_lazy-load" data-img="<?php echo bakery_get_attachment_image_src( absint( $atts['image'] ), 'full' ); ?>" style="background-size: <?php echo ! empty( $atts['image_size'] ) ? esc_attr( $atts['image_size'] ) : 'contain'; ?>">
							<?php if ( ! empty( $link['url'] ) ) : ?>
								<a href="<?php echo esc_url( $link['url'] ); ?>"><?php echo wp_get_attachment_image( $atts['image'], 'bakery_ratio-1:1', false ); ?></a>
							<?php else : ?>
								<span><?php echo wp_get_attachment_image( $atts['image'], 'bakery_ratio-1:1', false ); ?></span>
							<?php endif; ?>
						</div>
					<?php else : ?>
						<div class="vu_p-image vu_lazy-load" data-img="<?php echo bakery_get_attachment_image_src( absint( $atts['image'] ), 'full' ); ?>" style="background-size: <?php echo ! empty( $atts['image_size'] ) ? esc_attr( $atts['image_size'] ) : 'contain'; ?>;">
							<span><?php echo wp_get_attachment_image( $atts['image'], 'bakery_ratio-1:1', false ); ?></span>
						</div>
					<?php endif; ?>
				<?php endif; ?>
			<?php endif; ?>

			<div class="vu_p-content<?php echo ( $atts['style'] == "2" || $atts['style'] == "3") ? ' vu_p-content-' . esc_attr( $atts['content_display'] ) : ''; ?>">
				<?php if ( $atts['style'] != '1' and ( $atts['show_zoom_icon'] == '1' || $atts['show_link_icon'] == '1' ) ) : ?>
					<div class="vu_p-icons">
						<?php if ( $atts['show_zoom_icon'] == '1' ) : ?>
							<a href="<?php echo esc_url( bakery_get_attachment_image_src( absint( $atts['image'] ), 'full' ) ); ?>" title="<?php echo esc_attr( $atts['name'] ); ?>" class="vu_p-icon vu_lightbox"><i class="<?php echo esc_attr( $atts['zoom_icon'] ); ?>"></i></a>
						<?php endif; ?>

						<?php if ( ! empty( $link['url'] ) && $atts['show_link_icon'] == '1' ) : ?>
							<a href="<?php echo esc_url( $link['url'] ); ?>" title="<?php echo esc_attr( $atts['name'] ); ?>" target="<?php echo ( strlen( $link['target'] ) ) > 0 ? esc_attr( $link['target'] ) : '_self'; ?>" class="vu_p-icon"><i class="<?php echo esc_attr( $atts['link_icon'] ); ?>"></i></a>
						<?php endif; ?>
					</div>
				<?php endif; ?>

				<?php if ( ! empty( $atts['name'] ) ) : ?>
					<h3 class="vu_p-name"><?php echo (! empty( $link['url'] ) ) ? '<a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $atts['name'] ) . '" target="' . ( strlen( $link['target'] ) > 0 ? esc_attr( $link['target'] ) : '_self' ) . '">' . esc_html( $atts['name'] ) . '</a>' : esc_html( $atts['name'] ); ?></h3>
				<?php endif; ?>

				<?php if ( ! empty( $atts['description'] ) ) : ?>
					<div class="vu_p-description">
						<?php echo wpautop( $atts['description'] ); ?>
					</div>
				<?php endif; ?>

				<?php if ( ! empty( $atts['price'] ) ) : ?>
					<div class="vu_p-price">
						<?php if ( ! empty( $atts['currency'] ) ) : ?>
							<span><?php echo bakery_get_currency_symbol( $atts['currency'] ); ?></span>
						<?php endif; ?>

						<?php if ( ! empty( $atts['price'] ) ) : ?>
							<span><?php echo esc_html( $atts['price'] ); ?></span>
						<?php endif; ?>
					</div>
				<?php endif; ?>
			</div>
		</article>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_product', 'bakery_product_shortcode' );

/**
 * Product VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_product' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_product extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_product', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_product', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'Product', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Single product item', 'bakery-shortcodes' ),
			'base' => 'vu_product',
			'icon' => 'vu_product-icon',
			'controls' => 'full',
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'type' => 'image_select',
					'heading' => esc_html__( 'Style', 'bakery-shortcodes' ),
					'param_name' => 'style',
					'value' => array(
						'1' => array(
							'title' => esc_html__( '#1', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/product-styles/1.jpg'
						),
						'2' => array(
							'title' => esc_html__( '#2', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/product-styles/2.jpg'
						),
						'3' => array(
							'title' => esc_html__( '#3', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/product-styles/3.jpg'
						),
						'4' => array(
							'title' => esc_html__( '#4', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/product-styles/4.jpg'
						),
						'5' => array(
							'title' => esc_html__( '#5', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/product-styles/5.jpg'
						)
					),
					'width' => 'calc(20% - 10px)',
					'height' => 'auto',
					'std' => '1',
					'save_always' => true,
					'description' => esc_html__( 'Select product display style.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'attach_image',
					'heading' => esc_html__( 'Image', 'bakery-shortcodes' ),
					'param_name' => 'image',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select image from media library.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Image Size', 'bakery-shortcodes' ),
					'param_name' => 'image_size',
					'dependency' => array( 'element' => 'style', 'value' => array( '2', '3', '4', '5' ) ),
					'value' => array(
						esc_html__( 'Cover', 'bakery-shortcodes' ) => 'cover',
						esc_html__( 'Contain', 'bakery-shortcodes' ) => 'contain'
					),
					'std' => 'contain',
					'save_always' => true,
					'description' => esc_html__( 'Select product image size.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Shape', 'bakery-shortcodes' ),
					'param_name' => 'image_display',
					'dependency' => array( 'element' => 'style', 'value' => array( '2', '3' ) ),
					'value' => array(
						esc_html__( 'Portrait', 'bakery-shortcodes' ) => 'portrait',
						esc_html__( 'Landscape', 'bakery-shortcodes' ) => 'landscape',
						esc_html__( 'Square', 'bakery-shortcodes' ) => 'square'
					),
					'save_always' => true,
					'description' => esc_html__( 'Select product shape.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Content', 'bakery-shortcodes' ),
					'param_name' => 'content_display',
					'dependency' => array( 'element' => 'style', 'value' => array( '2', '3' ) ),
					'value' => array(
						esc_html__( 'Only on hover', 'bakery-shortcodes' ) => 'hover',
						esc_html__( 'Always', 'bakery-shortcodes' ) => 'always'
					),
					'std' => 'hover',
					'save_always' => true,
					'description' => esc_html__( 'Select when to show product content.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Label', 'bakery-shortcodes' ),
					'param_name' => 'label',
					'dependency' => array( 'element' => 'style', 'value_not_equal_to' => '1' ),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter product label. Leave blank if no label is needed.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Name', 'bakery-shortcodes' ),
					'param_name' => 'name',
					'admin_label' => true,
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter product name.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'vc_link',
					'heading' => esc_html__( 'URL (Link)', 'bakery-shortcodes' ),
					'param_name' => 'link',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Add link to product.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textarea',
					'heading' => esc_html__( 'Description', 'bakery-shortcodes' ),
					'param_name' => 'description',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter product description.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Price', 'bakery-shortcodes' ),
					'param_name' => 'price',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter product price [eg. 3.69]', 'bakery-shortcodes' )
				),
				array(
					'type' => 'select2',
					'heading' => esc_html__( 'Currency', 'bakery-shortcodes' ),
					'param_name' => 'currency',
					'options' => array(
						'tags' => false
					),
					'value' => bakery_get_currencies(),
					'save_always' => true,
					'description' => esc_html__( 'Select product currency.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__( 'Show Zoom Icon', 'bakery-shortcodes' ),
					'param_name' => 'show_zoom_icon',
					'value' =>  array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Check to show zoom icon.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'iconpicker',
					'heading' => esc_html__( 'Zoom Icon', 'bakery-shortcodes' ),
					'param_name' => 'zoom_icon',
					'dependency' => array( 'element' => 'show_zoom_icon', 'value' => '1' ),
					'settings' => array(
						'type' => 'fontawesome',
						'emptyIcon' => false,
						'iconsPerPage' => 100
					),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Pick an icon from the library.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__( 'Show Link Icon', 'bakery-shortcodes' ),
					'param_name' => 'show_link_icon',
					'dependency' => array( 'element' => 'style', 'value_not_equal_to' => '1' ),
					'value' =>  array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Check to show link icon.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'iconpicker',
					'heading' => esc_html__( 'Link Icon', 'bakery-shortcodes' ),
					'param_name' => 'link_icon',
					'dependency' => array( 'element' => 'show_link_icon', 'value' => '1' ),
					'settings' => array(
						'type' => 'fontawesome',
						'emptyIcon' => false,
						'iconsPerPage' => 100
					),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Pick an icon from the library.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				)
			)
		)
	);
}
