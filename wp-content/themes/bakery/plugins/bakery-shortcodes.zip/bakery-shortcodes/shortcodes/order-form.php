<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * Order Form Shortcode
 *
 * @param string $atts['placeholder']
 * @param string $atts['contact_form_7']
 * @param string $atts['hide_valid_msgs']
 * @param string $atts['get_wc_products']
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 * @param string $atts['products']
 * @param string $atts['wc_products']
 * @param string $atts['css']
 */

if ( ! function_exists( 'bakery_order_form_shortcode' ) ) {
	function bakery_order_form_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'placeholder' => '',
			'contact_form_7' => '',
			'hide_valid_msgs' => '',
			'get_wc_products' => '',
			'class' => '',
			'products' => '',
			'wc_products' => '',
			'css' => ''
		), $atts, 'vu_order_form' );

		$cf7_atts = array(
			'id' => $atts['contact_form_7'],
			'html_class' => 'vu_cf7-frm'
		);

		if ( function_exists( 'vc_shortcode_custom_css_class' ) ) {
			$atts['class'] .= ' ' . vc_shortcode_custom_css_class( $atts['css'] );
		}

		$atts['class'] = trim( $atts['class'] );

		$products = array();

		if ( class_exists( 'WooCommerce' ) && $atts['get_wc_products'] == '1' ) {
			if ( stripos( $atts['wc_products'], 'post_type:product' ) === false ) {
				$atts['wc_products'] .= '|post_type:product';
			}

			$BakeryVcLoopQueryBuilder = new BakeryVcLoopQueryBuilder( esc_attr( $atts['wc_products'] ) );
			$wc_products_query = $BakeryVcLoopQueryBuilder->build();

			$p_index = 0;

			if ( $wc_products_query->have_posts() ) :
				$p_currency = get_woocommerce_currency_symbol();

				$p_decimal_separator = wc_get_price_decimal_separator();
				$p_thousand_separator = wc_get_price_thousand_separator();
				$p_decimals = wc_get_price_decimals();

				while ( $wc_products_query->have_posts() ) :
					$wc_products_query->the_post();

					$product = wc_get_product( get_the_ID() );

					$products[ $p_index ]['name'] = $product->get_name();
					$products[ $p_index ]['currency'] = $p_currency;
					$products[ $p_index ]['price'] = number_format( (float) $product->get_price(), $p_decimals, $p_decimal_separator, $p_thousand_separator );
					$products[ $p_index ]['image_id'] = $product->get_image_id();
					$products[ $p_index ]['image_url'] = bakery_get_attachment_image_src( $products[ $p_index ]['image_id'], 'thumbnail' );
					$products[ $p_index ]['desc'] = wp_strip_all_tags( $product->get_short_description() );
					
					$products[ $p_index ]['desc'] = strip_shortcodes( $products[ $p_index ]['desc'] );
					
					$products[ $p_index ]['desc'] = substr( $products[ $p_index ]['desc'], 0, 100 ) . '...';

					$p_index++;
				endwhile;
			endif;

			wp_reset_query();
		} else {
			$products = json_decode( rawurldecode( base64_decode( $atts['products'] ) ), true );

			if ( ! empty( $products ) && is_array( $products ) ) {
				$p_index = 0;

				foreach ( $products as $product ) {
					if ( ! empty( $product['image_id'] ) ) {
						$products[ $p_index ]['image_url'] = esc_url( bakery_get_attachment_image_src( absint( $product['image_id'] ), 'thumbnail' ) );
					}

					$p_index++;
				}
			}
		}

		ob_start(); ?>
		<div class="vu_order-form<?php echo ( $atts['hide_valid_msgs'] == '1' ) ? ' vu_of-hide-valid-msgs' : ''; ?> clearfix<?php bakery_extra_class( $atts['class'] ); ?>" data-products="<?php echo esc_attr( json_encode( $products ) ); ?>" data-placeholder="<?php echo esc_attr( $atts['placeholder'] ); ?>">

			<?php echo do_shortcode( bakery_generate_shortcode( 'contact-form-7', $cf7_atts ) ); ?>
		</div>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_order_form', 'bakery_order_form_shortcode' );

/**
 * Order Form VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_order_form' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_order_form extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_order_form', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_order_form', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'Order Form', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Custom order form', 'bakery-shortcodes' ),
			'base' => 'vu_order_form',
			'class' => 'vc_vu_order_form',
			'icon' => 'vu_element-icon vu_order-form-icon',
			'controls' => 'full',
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Products Input Placeholder', 'bakery-shortcodes' ),
					'param_name' => 'placeholder',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter placeholder text for products field.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'select2',
					'heading' => esc_html__( 'Form', 'bakery-shortcodes' ),
					'param_name' => 'contact_form_7',
					'admin_label' => true,
					'options' => array(
						'source' => admin_url( 'admin-ajax.php?action=bakery_get_cf7' ),
						'tags' => true
					),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select order form.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__( 'Hide Validation Messages?', 'bakery-shortcodes' ),
					'param_name' => 'hide_valid_msgs',
					'value' => array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Check to hide validation messages for all fields.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Class', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Use this to option to add an extra Class onto your contact form. Leave blank if no title is needed.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Products', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Get WooCommerce Products?', 'bakery-shortcodes' ),
					'param_name' => 'get_wc_products',
					'value' => array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Check to get woocommerce products.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Products', 'bakery-shortcodes' ),
					'type' => 'universal',
					'heading' => esc_html__( 'Products', 'bakery-shortcodes' ),
					'param_name' => 'products',
					'dependency' => array( 'element' => 'get_wc_products', 'value_not_equal_to' => '1' ),
					'template' => '<div class="vc_row"><div class="vc_col-xs-6 vu_m-b-10 vu_p-r-5"><div class="wpb_element_label">' . esc_html__( 'Name', 'bakery-shortcodes' ) . '</div><input name="name" type="text" value=""></div><div class="vc_col-xs-2 vu_m-b-10"><div class="wpb_element_label">' . esc_html__( 'Currency', 'bakery-shortcodes' ) . '</div><input name="currency" type="text" value=""></div><div class="vc_col-xs-4 vu_m-b-10 vu_p-l-5"><div class="wpb_element_label">' . esc_html__( 'Price', 'bakery-shortcodes' ) . '</div><input name="price" type="text" value=""></div><div class="vc_col-xs-6 vu_m-b-10 vu_p-r-5"><div class="wpb_element_label">' . esc_html__( 'Image', 'bakery-shortcodes' ) . '</div><div class="vu_param_media vc_clearfix"><div class="vu_param_m-img-holder"><span class="vu_param_m-img"></span></div><div class="vu_param_m-content"><input type="hidden" name="image_id" class="vu_param_m-img-id"><input type="text" name="image_url" class="vu_param_m-img-url" readonly="readonly" placeholder="' . esc_attr__( 'No image selected.', 'bakery-shortcodes' ) . '"><button type="button" class="vu_param_m-btn vu_as-param" data-control="upload" data-title="' . esc_attr__( 'Add Image', 'bakery-shortcodes' ) . '" data-button="' . esc_attr__( 'Add Image', 'bakery-shortcodes' ) . '">' . esc_html__( 'Upload', 'bakery-shortcodes' ) . '</button><button type="button" class="vu_param_m-btn vu_as-param" data-control="remove">' . esc_html__( 'Remove', 'bakery-shortcodes' ) . '</button></div></div></div><div class="vc_col-xs-6 vu_m-b-10"><div class="wpb_element_label">' . esc_html__( 'Description', 'bakery-shortcodes' ) . '</div><textarea name="desc" rows="3" style="height:80px;"></textarea></div></div>',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Add products.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Products', 'bakery-shortcodes' ),
					'type' => 'loop',
					'heading' => esc_html__( 'WC Products Query', 'bakery-shortcodes' ),
					'param_name' => 'wc_products',
					'dependency' => array( 'element' => 'get_wc_products', 'value' => '1' ),
					'settings' => array(
						'size'          => array( 'hidden' => false, 'value' => 'All' ),
						'order_by'      => array( 'value' => 'date' ),
						'categories'    => array( 'hidden' => true ),
						'tags'          => array( 'hidden' => true ),
						'tax_query'     => array( 'hidden' => false ),
						'authors'     	=> array( 'hidden' => true ),
						'post_type'     => array( 'hidden' => false, 'value' => 'product' )
					),
					'value' => 'size:All|order_by:date|post_type:product',
					'save_always' => true,
					'description' => esc_html__( 'Create WordPress loop, to show products from your site.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Design Options', 'bakery-shortcodes' ),
					'type' => 'css_editor',
					'heading' => esc_html__( 'CSS box', 'bakery-shortcodes' ),
					'param_name' => 'css'
				)
			)
		)
	);
}
