<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * Countdown Shortcode
 *
 * @param string $atts['date']
 * @param string $atts['format']
 * @param string $atts['size']
 * @param string $atts['alignment']
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 * @param string $atts['css']
 */

if ( ! function_exists( 'bakery_countdown_shortcode' ) ) {
	function bakery_countdown_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'date' => '',
			'format' => 'dHMS',
			'size' => '',
			'alignment' => '',
			'class' => '',
			'css' => ''
		), $atts, 'vu_countdown' );

		if ( function_exists( 'vc_shortcode_custom_css_class' ) ) {
			$atts['class'] .= ' ' . vc_shortcode_custom_css_class( $atts['css'] );
		}

		ob_start(); ?>
		<div class="vu_countdown vu_c-size-<?php echo esc_attr( $atts['size'] ); ?> vu_c-alignment-<?php echo esc_attr( $atts['alignment'] ); ?> clearfix<?php bakery_extra_class( $atts['class'] ); ?>" data-date="<?php echo esc_attr( $atts['date'] ); ?>" data-format="<?php echo esc_attr( $atts['format'] ); ?>"></div>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_countdown', 'bakery_countdown_shortcode' );

/**
 * Countdown VC Shortcode
 */

 if ( ! class_exists( 'WPBakeryShortCode_vu_countdown' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_countdown extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_countdown', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_countdown', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'Countdown', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Countdown element', 'bakery-shortcodes' ),
			'base' => 'vu_countdown',
			'class' => 'vc_vu_countdown',
			'icon' => 'vu_element-icon vu_countdown-icon',
			'controls' => 'full',
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Date', 'bakery-shortcodes' ),
					'param_name' => 'date',
					'admin_label' => true,
					'value' => '',
					'save_always' => true,
					'description' => wp_kses( __( "Enter date in '<b>yyyy-mm-dd</b>' format.", 'bakery-shortcodes' ), array( 'b' => array() ) )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Format', 'bakery-shortcodes' ),
					'param_name' => 'format',
					'admin_label' => true,
					'value' => 'dHMS',
					'save_always' => true,
					'description' => wp_kses( __( 'Enter date format. Default is <b>dHMS</b>.', 'bakery-shortcodes' ), array( 'b' => array() ) )
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Size', 'bakery-shortcodes' ),
					'param_name' => 'size',
					'value' => array(
						esc_html__( 'Large', 'bakery-shortcodes' ) => 'large',
						esc_html__( 'Medium', 'bakery-shortcodes' ) => 'medium',
						esc_html__( 'Small', 'bakery-shortcodes' ) => 'small'
					),
					'std' => 'large',
					'save_always' => true,
					'description' => esc_html__( 'Select countdown size.', 'bakery-shortcodes' ),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Alignment', 'bakery-shortcodes' ),
					'param_name' => 'alignment',
					'value' => array(
						esc_html__( 'Left', 'bakery-shortcodes' ) => 'left',
						esc_html__( 'Center', 'bakery-shortcodes' ) => 'center',
						esc_html__( 'Right', 'bakery-shortcodes' ) => 'right'
					),
					'std' => 'center',
					'save_always' => true,
					'description' => esc_html__( 'Select countdown alignment.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Design Options', 'bakery-shortcodes' ),
					'type' => 'css_editor',
					'heading' => esc_html__( 'CSS box', 'bakery-shortcodes' ),
					'param_name' => 'css'
				)
			)
		)
	);
}
