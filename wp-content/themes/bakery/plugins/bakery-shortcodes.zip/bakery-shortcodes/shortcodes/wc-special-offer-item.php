<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * WC Special Offer Item Shortcode
 *
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 */

if ( ! function_exists( 'bakery_wc_special_offer_item_shortcode' ) ) {
	function bakery_wc_special_offer_item_shortcode( $atts = null, $content = null ) {
		return '';
	}
}

add_shortcode( 'vu_wc_special_offer_item', 'bakery_wc_special_offer_item_shortcode' );

/**
 * WC Special Offer Item VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_wc_special_offer_item' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_wc_special_offer_item extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_wc_special_offer_item', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_wc_special_offer_item', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'WC Special Offer Item', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Add WC special offer item', 'bakery-shortcodes' ),
			'base' => 'vu_wc_special_offer_item',
			'icon' => 'vu_wc-special-offer-item-icon',
			'controls' => 'full',
			'as_child' => array( 'only' => 'vu_wc_special_offer' ),
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'type' => 'select2',
					'heading' => esc_html__( 'Product', 'bakery-shortcodes' ),
					'param_name' => 'product',
					'admin_label' => true,
					'options' => array(
						'source' => admin_url( 'admin-ajax.php?action=bakery_get_wc_products' ),
						'tags' => false
					),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select product.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Label', 'bakery-shortcodes' ),
					'param_name' => 'label',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter product label. Leave blank if no label is needed.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__( 'Show Name', 'bakery-shortcodes' ),
					'param_name' => 'show_name',
					'value' =>  array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true,
					'description' => esc_html__( 'Check to show name.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__( 'Show Content', 'bakery-shortcodes' ),
					'param_name' => 'show_content',
					'value' =>  array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true,
					'description' => esc_html__( 'Check to show content.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__( 'Show Price', 'bakery-shortcodes' ),
					'param_name' => 'show_price',
					'value' =>  array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true,
					'description' => esc_html__( 'Check to show price.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__( 'Show Button', 'bakery-shortcodes' ),
					'param_name' => 'show_button',
					'value' =>  array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true,
					'description' => esc_html__( 'Check to show button.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Button Type', 'bakery-shortcodes' ),
					'param_name' => 'button_type',
					'dependency' => array( 'element' => 'show_button', 'value' => '1' ),
					'value' =>  array(
						esc_html__( 'Add to Cart', 'bakery-shortcodes' ) => 'add_to_cart',
						esc_html__( 'Product Link', 'bakery-shortcodes' ) => 'product_link',
						esc_html__( 'Custom Link', 'bakery-shortcodes' ) => 'custom_link'
					),
					'std' => 'product_link',
					'save_always' => true,
					'description' => esc_html__( 'Select button type.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Button Text', 'bakery-shortcodes' ),
					'param_name' => 'button_text',
					'dependency' => array( 'element' => 'show_button', 'value' => '1' ),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter button text.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'vc_link',
					'heading' => esc_html__( 'Button URL (Link)', 'bakery-shortcodes' ),
					'param_name' => 'button_link',
					'dependency' => array( 'element' => 'button_type', 'value' => 'custom_link' ),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Add link to button.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				)
			)
		)
	);
}
