<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * Separator Shortcode
 *
 * @param string $atts['style']
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 */

if ( ! function_exists( 'bakery_separator_shortcode' ) ) {
	function bakery_separator_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'style' => '',
			'class' => ''
		), $atts, 'vu_separator' );

		ob_start(); ?>
		<div class="vu_separator vu_s-style-<?php echo esc_attr( $atts['style'] ); ?><?php bakery_extra_class( $atts['class'] ); ?>">
			<?php 
				if ( $atts['style'] == '1' ) {
					echo '<span class="vu_s-line-left"></span><span class="vu_s-bullet" data-number="1"></span><span class="vu_s-bullet" data-number="2"></span><span class="vu_s-bullet" data-number="3"></span><span class="vu_s-line-right"></span>';
				} elseif ( $atts['style'] == '2' ) {
					echo '<span class="vu_s-line"></span>';
				} elseif ( $atts['style'] == '3' ) {
					echo '<span class="vu_s-line"></span>';
				} elseif ( $atts['style'] == '4' ) {
					echo '<span class="vu_s-line"></span>';
				} else {
					echo '<span class="vu_s-line-left"></span><span class="vu_s-line-center"></span><span class="vu_s-line-right"></span>';
				}
			?>
		</div>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_separator', 'bakery_separator_shortcode' );

/**
 * Separator VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_separator' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_separator extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_separator', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_separator', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'Separator', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Separator/Divider', 'bakery-shortcodes' ),
			'base' => 'vu_separator',
			'class' => 'vc_vu_separator wpb_vc_separator',
			'icon' => 'vu_element-icon vu_separator-icon',
			'custom_markup' => '',
			'controls' => 'full',
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'type' => 'image_select',
					'heading' => esc_html__( 'Style', 'bakery-shortcodes' ),
					'param_name' => 'style',
					'value' => array(
						'1' => array(
							'title' => esc_html__( '#1', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/separator-styles/1.jpg'
						),
						'2' => array(
							'title' => esc_html__( '#2', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/separator-styles/2.jpg'
						),
						'3' => array(
							'title' => esc_html__( '#3', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/separator-styles/3.jpg'
						),
						'4' => array(
							'title' => esc_html__( '#4', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/separator-styles/4.jpg'
						),
						'5' => array(
							'title' => esc_html__( '#4', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/separator-styles/5.jpg'
						)
					),
					'width' => 'calc(50% - 10px)',
					'height' => 'auto',
					'std' => '1',
					'save_always' => true,
					'description' => esc_html__( 'Select separator style.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				)
			)
		)
	);
}
