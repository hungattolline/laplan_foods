<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * Map Shortcode
 */

if ( ! function_exists( 'bakery_map_shortcode' ) ) {
	function bakery_map_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'inherit_options' => '',
			'center_lat' => '',
			'center_lng' => '',
			'zoom_level' => '',
			'map_height' => '',
			'map_type' => '',
			'map_id' => '',
			'tilt_45' => '',
			'draggable' => '',
			'zoom_control' => '',
			'disable_double_click_zoom' => '',
			'pan_control' => '',
			'fullscreen_control' => '',
			'map_type_control' => '',
			'scale_control' => '',
			'street_view_control' => '',
			'use_custom_marker' => '',
			'custom_marker' => '',
			'enable_map_animation' => '',
			'locations' => '',
			'class' => ''
		), $atts, 'vu_map' );

		//map options
		if ( $atts['inherit_options'] != '1' ) {
			$map_options = array(
				'map_id' => esc_attr( $atts['map_id'] ),
				'zoom_level' => esc_attr( $atts['zoom_level'] ),
				'center_lat' => esc_attr( $atts['center_lat'] ),
				'center_lng' => esc_attr( $atts['center_lng'] ),
				'map_type' => esc_attr( $atts['map_type'] ),
				'tilt_45' => esc_attr( $atts['tilt_45'] ),
				'others_options' => array(
					'draggable' => esc_attr( $atts['draggable'] ),
					'zoomControl' => esc_attr( $atts['zoom_control'] ),
					'disableDoubleClickZoom' => esc_attr( $atts['disable_double_click_zoom'] ),
					'panControl' => esc_attr( $atts['pan_control'] ),
					'fullscreenControl' => esc_attr( $atts['fullscreen_control'] ),
					'mapTypeControl' => esc_attr( $atts['map_type_control'] ),
					'scaleControl' => esc_attr( $atts['scale_control'] ),
					'streetViewControl' => esc_attr( $atts['street_view_control'] )
				),
				'use_custom_marker' => esc_attr( $atts['use_custom_marker'] ),
				'custom_marker' => esc_url( bakery_get_attachment_image_src( $atts['custom_marker'], 'full' ) ),
				'enable_animation' => esc_attr( $atts['enable_map_animation'] ),
				'locations' => json_decode( rawurldecode( base64_decode( $atts['locations'] ) ), true )
			);
		} else {
			$map_options = bakery_get_map_options();
		}

		$map_height = ( $atts['inherit_options'] != '1' ) ? absint( $atts['map_height'] ) : absint( bakery_get_option( 'map-height' ) );

		return '<div class="vu_map vu_m-fullwith' . bakery_extra_class( $atts['class'], false ) . '" data-options="' . esc_attr( json_encode( $map_options ) ) . '"' . ( $map_height > 0 ? ' style="height:' . $map_height . 'px;"' : '' ) . '></div>';
	}
}

add_shortcode( 'vu_map', 'bakery_map_shortcode' );

/**
 * Map VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_map' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_map extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_map', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_map', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'Map', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Single or multiple locations', 'bakery-shortcodes' ),
			'base' => 'vu_map',
			'class' => 'vc_vu_map',
			'icon' => 'vu_element-icon vu_map-icon',
			'controls' => 'full',
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Inherit from Theme Options', 'bakery-shortcodes' ),
					'param_name' => 'inherit_options',
					'admin_label' => true,
					'value' => array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true,
					'description' => esc_html__( 'Map options will be inherited form general theme options. Uncheck to ignore and set up new options.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Center Latitude', 'bakery-shortcodes' ),
					'param_name' => 'center_lat',
					'dependency' => array( 'element' => 'inherit_options', 'value_not_equal_to' => '1' ),
					'admin_label' => true,
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter latitude for the map center point.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Center Longitude', 'bakery-shortcodes' ),
					'param_name' => 'center_lng',
					'dependency' => array( 'element' => 'inherit_options', 'value_not_equal_to' => '1' ),
					'admin_label' => true,
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter longitude for the map center point.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Default Zoom Level', 'bakery-shortcodes' ),
					'param_name' => 'zoom_level',
					'dependency' => array( 'element' => 'inherit_options', 'value_not_equal_to' => '1' ),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Value should be between 1-18, 1 being the entire earth and 18 being right at street level.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Height', 'bakery-shortcodes' ),
					'param_name' => 'map_height',
					'dependency' => array( 'element' => 'inherit_options', 'value_not_equal_to' => '1' ),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter map height.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'dropdown',
					'heading' => esc_html__( 'Type', 'bakery-shortcodes' ),
					'param_name' => 'map_type',
					'dependency' => array( 'element' => 'inherit_options', 'value_not_equal_to' => '1' ),
					'value' => array(
						esc_html__( 'Roadmap', 'bakery-shortcodes' ) => 'roadmap',
						esc_html__( 'Satellite', 'bakery-shortcodes' ) => 'satellite',
						esc_html__( 'Hybrid', 'bakery-shortcodes' ) => 'hybrid',
						esc_html__( 'Terrain', 'bakery-shortcodes' ) => 'terrain'
					),
					'save_always' => true,
					'description' => esc_html__( 'Select map type.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Tilt 45°', 'bakery-shortcodes' ),
					'param_name' => 'tilt_45',
					'dependency' => array( 'element' => 'map_type', 'value' => 'satellite' ),
					'value' => array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'save_always' => true
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column',
					'heading' => esc_html__( 'Others Options', 'bakery-shortcodes' ),
					'param_name' => 'draggable',
					'dependency' => array( 'element' => 'inherit_options', 'value_not_equal_to' => '1' ),
					'value' => array( esc_html__( 'Draggable', 'bakery-shortcodes' ) => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Select other options you want to apply on map.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-0',
					'param_name' => 'zoom_control',
					'dependency' => array( 'element' => 'inherit_options', 'value_not_equal_to' => '1' ),
					'value' => array( esc_html__( 'Zoom Control', 'bakery-shortcodes' ) => '1' ),
					'save_always' => true
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-0',
					'param_name' => 'disable_double_click_zoom',
					'dependency' => array( 'element' => 'inherit_options', 'value_not_equal_to' => '1' ),
					'value' => array( esc_html__( 'Disable Double Click Zoom', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-0',
					'param_name' => 'pan_control',
					'dependency' => array( 'element' => 'inherit_options', 'value_not_equal_to' => '1' ),
					'value' => array( esc_html__( 'Pan Control', 'bakery-shortcodes' ) => '1' ),
					'save_always' => true
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-0',
					'param_name' => 'fullscreen_control',
					'dependency' => array( 'element' => 'inherit_options', 'value_not_equal_to' => '1' ),
					'value' => array( esc_html__( 'Fullscreen Control', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-0',
					'param_name' => 'map_type_control',
					'dependency' => array( 'element' => 'inherit_options', 'value_not_equal_to' => '1' ),
					'value' => array( esc_html__( 'Type Control', 'bakery-shortcodes' ) => '1' ),
					'save_always' => true
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-0',
					'param_name' => 'scale_control',
					'dependency' => array( 'element' => 'inherit_options', 'value_not_equal_to' => '1' ),
					'value' => array( esc_html__( 'Scale Control', 'bakery-shortcodes' ) => '1' ),
					'save_always' => true
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-0',
					'param_name' => 'street_view_control',
					'dependency' => array( 'element' => 'inherit_options', 'value_not_equal_to' => '1' ),
					'value' => array( esc_html__( 'Street View Control', 'bakery-shortcodes' ) => '1' ),
					'save_always' => true
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'ID', 'bakery-shortcodes' ),
					'param_name' => 'map_id',
					'dependency' => array( 'element' => 'inherit_options', 'value_not_equal_to' => '1' ),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( "A map ID is an identifier that's associated with a specific map style or feature. Configure a map style and associate it with a map ID in the Google Cloud Console.", 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'dependency' => array( 'element' => 'inherit_options', 'value_not_equal_to' => '1' ),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Marker', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Use Custom Marker', 'bakery-shortcodes' ),
					'param_name' => 'use_custom_marker',
					'dependency' => array( 'element' => 'inherit_options', 'value_not_equal_to' => '1' ),
					'value' => array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'save_always' => true,
					'description' => esc_html__( 'Check to use a custom image as map marker.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Marker', 'bakery-shortcodes' ),
					'type' => 'attach_image',
					'heading' => esc_html__( 'Custom Marker', 'bakery-shortcodes' ),
					'param_name' => 'custom_marker',
					'dependency' => array( 'element' => 'use_custom_marker', 'value' => '1' ),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Upload custom image/icon marker.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Marker', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Enable Marker Animation', 'bakery-shortcodes' ),
					'param_name' => 'enable_map_animation',
					'dependency' => array( 'element' => 'inherit_options', 'value_not_equal_to' => '1' ),
					'value' => array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'save_always' => true,
					'description' => esc_html__( 'If checked, marker(s) will do a quick bounce as they load in.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Locations', 'bakery-shortcodes' ),
					'type' => 'universal',
					'heading' => esc_html__( 'Locations', 'bakery-shortcodes' ),
					'param_name' => 'locations',
					'dependency' => array( 'element' => 'inherit_options', 'value_not_equal_to' => '1' ),
					'template' => '<div class="vc_row"><div class="vc_col-xs-6 vu_m-b-10"><div class="wpb_element_label">' . esc_html__( 'Latitude', 'bakery-shortcodes' ) . '</div><input name="lat" type="text" value=""></div><div class="vc_col-xs-6 vu_m-b-10"><div class="wpb_element_label">' . esc_html__( 'Longitude', 'bakery-shortcodes' ) . '</div><input name="lng" type="text" value=""></div><div class="vc_col-xs-12 vu_m-b-10"><div class="wpb_element_label">' . esc_html__( 'Info Window', 'bakery-shortcodes' ) . '</div><textarea name="info"></textarea></div><div class="vc_col-xs-12 vu_m-b-10"><div class="wpb_element_label">' . esc_html__( 'Marker', 'bakery-shortcodes' ) . '</div><div class="vu_param_media vc_clearfix"><div class="vu_param_m-img-holder"><span class="vu_param_m-img"></span></div><div class="vu_param_m-content"><input type="hidden" name="marker_id" class="vu_param_m-img-id"><input type="text" name="marker_url" class="vu_param_m-img-url" readonly="readonly" placeholder="' . esc_attr__( 'No marker selected. Custom marker will be inhereted.', 'bakery-shortcodes' ) . '"><button type="button" class="vu_param_m-btn vu_as-param" data-control="upload" data-title="' . esc_attr__( 'Add Image', 'bakery-shortcodes' ) . '" data-button="' . esc_attr__( 'Add Image', 'bakery-shortcodes' ) . '">' . esc_html__( 'Upload', 'bakery-shortcodes' ) . '</button><button type="button" class="vu_param_m-btn vu_as-param" data-control="remove">' . esc_html__( 'Remove', 'bakery-shortcodes' ) . '</button></div></div></div></div>',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter map locations details.', 'bakery-shortcodes' )
				)
			)
		)
	);
}
