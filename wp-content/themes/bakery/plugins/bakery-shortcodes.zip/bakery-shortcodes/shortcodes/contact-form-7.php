<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * Contact Form 7 Shortcode
 *
 * @param string $atts['title']
 * @param string $atts['id']
 * @param string $atts['style']
 * @param string $atts['hide_valid_msgs']
 * @param string $atts['html_id']
 * @param string $atts['html_name']
 * @param string $atts['html_class'] Add a class name and then refer to it in your css file.
 * @param string $atts['css']
 */

if ( ! function_exists( 'bakery_contact_form_7_shortcode' ) ) {
	function bakery_contact_form_7_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'title' => '',
			'id' => '',
			'style' => '',
			'hide_valid_msgs' => '',
			'html_id' => '',
			'html_name' => '',
			'html_class' => '',
			'css' => ''
		), $atts, 'vu_contact_form_7' );

		$atts['html_class'] = trim( $atts['html_class'] . ' vu_cf7-frm' );

		if ( function_exists( 'vc_shortcode_custom_css_class' ) ) {
			$vc_shortcode_custom_css_class = ' ' . vc_shortcode_custom_css_class( $atts['css'] );
		}

		ob_start(); ?>
		<div class="vu_contact-form-7 vu_cf7-style-<?php echo esc_attr( $atts['style'] ); ?><?php echo ( $atts['hide_valid_msgs'] == '1' ) ? ' vu_cf7-hide-valid-msgs' : ''; ?> clearfix<?php echo ( isset( $vc_shortcode_custom_css_class ) && ! empty( $vc_shortcode_custom_css_class ) ) ? esc_attr( $vc_shortcode_custom_css_class ) : ''; ?>">
			<?php if ( ! empty( $atts['title'] ) ) : ?>
				<h4 class="vu_cf7-title"><?php echo esc_html( $atts['title'] ); ?></h4>
			<?php endif; ?>

			<?php echo do_shortcode( bakery_generate_shortcode( 'contact-form-7', $atts, $content ) ); ?>
		</div>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_contact_form_7', 'bakery_contact_form_7_shortcode' );

/**
 * Contact Form 7 VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_contact_form_7' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_contact_form_7 extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_contact_form_7', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_contact_form_7', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'Contact Form 7', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Contact Form 7', 'bakery-shortcodes' ),
			'base' => 'vu_contact_form_7',
			'class' => 'vc_vu_contact_form_7',
			'icon' => 'vu_element-icon vu_contact-form-icon',
			'controls' => 'full',
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Title', 'bakery-shortcodes' ),
					'param_name' => 'title',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter form title. Leave blank if no title is needed.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'select2',
					'heading' => esc_html__( 'Form', 'bakery-shortcodes' ),
					'param_name' => 'id',
					'admin_label' => true,
					'options' => array(
						'source' => admin_url( 'admin-ajax.php?action=bakery_get_cf7' ),
						'tags' => true
					),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select contact from.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Style', 'bakery-shortcodes' ),
					'param_name' => 'style',
					'value' => array(
						esc_html__( 'Default', 'bakery-shortcodes' ) => 'default',
						esc_html__( 'Inverse', 'bakery-shortcodes' ) => 'inverse'
					),
					'save_always' => true,
					'description' => esc_html__( 'Select form style.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__( 'Hide Validation Messages?', 'bakery-shortcodes' ),
					'param_name' => 'hide_valid_msgs',
					'value' => array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Check to hide validation messages for all fields.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'ID', 'bakery-shortcodes' ),
					'param_name' => 'html_id',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Use this to option to add an ID onto your contact form. Leave blank if no title is needed.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Name', 'bakery-shortcodes' ),
					'param_name' => 'html_name',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Use this to option to add an Name onto your contact form. Leave blank if no title is needed.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Class', 'bakery-shortcodes' ),
					'param_name' => 'html_class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Use this to option to add an extra Class onto your contact form. Leave blank if no title is needed.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Design Options', 'bakery-shortcodes' ),
					'type' => 'css_editor',
					'heading' => esc_html__( 'CSS box', 'bakery-shortcodes' ),
					'param_name' => 'css'
				)
			)
		)
	);
}
