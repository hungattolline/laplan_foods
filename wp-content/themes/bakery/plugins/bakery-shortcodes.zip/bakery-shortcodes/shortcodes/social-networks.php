<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * Social Networks Shortcode
 *
 * @param string $atts['size']
 * @param string $atts['alignment']
 * @param string $atts['custom_colors']
 * @param string $atts['icons_normal_color']
 * @param string $atts['icons_normal_bg_color']
 * @param string $atts['icons_hover_color']
 * @param string $atts['icons_hover_bg_color']
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 * @param string $atts['social_networks']
 * @param string $atts['css']
 */

if ( ! function_exists( 'bakery_social_networks_shortcode' ) ) {
	function bakery_social_networks_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'size' => '',
			'alignment' => '',
			'custom_colors' => '',
			'icons_normal_color' => '',
			'icons_normal_bg_color' => '',
			'icons_hover_color' => '',
			'icons_hover_bg_color' => '',
			'class' => '',
			'social_networks' => '',
			'css' => ''
		), $atts, 'vu_social_networks' );

		$social_networks = json_decode( rawurldecode( base64_decode( $atts['social_networks'] ) ), true );

		if ( $atts['custom_colors'] == '1' ) {
			$custom_class = bakery_custom_class();
			$atts['class'] .= ' ' . $custom_class;
		}

		if ( function_exists( 'vc_shortcode_custom_css_class' ) ) {
			$atts['class'] .= ' ' . vc_shortcode_custom_css_class( $atts['css'] );
		}

		$atts['class'] = trim( $atts['class'] );

		ob_start(); ?>
		<div class="vu_social-networks vu_sn-size-<?php echo esc_attr( $atts['size'] ); ?> vu_sn-alignment-<?php echo esc_attr( $atts['alignment'] ); ?><?php bakery_extra_class( $atts['class'] ); ?>">
				<?php if ( $atts['custom_colors'] == '1' ) : ?>
					<style scoped>
						<?php if ( ! empty( $atts['icons_normal_color'] ) || ! empty( $atts['icons_normal_bg_color'] ) ) : ?>
							<?php if ( ! empty( $atts['icons_normal_color'] ) ) : ?>
								.vu_social-networks.<?php echo esc_attr( $custom_class ); ?> .vu_social-icon a { color: <?php echo esc_attr( $atts['icons_normal_color'] ); ?> !important; }
							<?php endif; ?>
							<?php if ( ! empty( $atts['icons_normal_bg_color'] ) ) : ?>
								.vu_social-networks.<?php echo esc_attr( $custom_class ); ?> .vu_social-icon a { background-color: <?php echo esc_attr( $atts['icons_normal_bg_color'] ); ?> !important; }
							<?php endif; ?>
						<?php endif; ?>
						<?php if ( ! empty( $atts['icons_hover_color'] ) || ! empty( $atts['icons_hover_bg_color'] ) ) : ?>
							<?php if ( ! empty( $atts['icons_hover_color'] ) ) : ?>
								.vu_social-networks.<?php echo esc_attr( $custom_class ); ?> .vu_social-icon a:hover { color: <?php echo esc_attr( $atts['icons_hover_color'] ); ?> !important; }
							<?php endif; ?>
							<?php if ( ! empty( $atts['icons_hover_bg_color'] ) ) : ?>
								.vu_social-networks.<?php echo esc_attr( $custom_class ); ?> .vu_social-icon a:hover { background-color: <?php echo esc_attr( $atts['icons_hover_bg_color'] ); ?> !important; }
							<?php endif; ?>
						<?php endif; ?>
					</style>
				<?php endif; ?>
			<div class="vu_sn-container">
				<?php 
					if ( ! empty( $social_networks ) && is_array( $social_networks ) ) {
						foreach ( $social_networks as $social_network ) {
							$_atts = shortcode_atts( array(
								'url' => '#',
								'target' => '_blank',
								'rel' => 'nofollow',
								'icon' => '',
							), $social_network, 'vu_social_network' );

							$_atts['icon'] = ! empty( $_atts['icon'] ) ? $_atts['icon'] : '';

							
							echo do_shortcode( bakery_generate_shortcode( 'vu_social_network', $_atts, null ) );
						}
					}
				?>
			</div>
		</div>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_social_networks', 'bakery_social_networks_shortcode' );

/**
 * Social Networks VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_social_networks' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_social_networks extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_social_networks', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_social_networks', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'Social Networks', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Social media icons and links', 'bakery-shortcodes' ),
			'base' => 'vu_social_networks',
			'class' => 'vc_vu_social_networks',
			'icon' => 'vu_element-icon vu_social-networks-icon',
			'controls' => 'full',
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'dropdown',
					'heading' => esc_html__( 'Size', 'bakery-shortcodes' ),
					'param_name' => 'size',
					'admin_label' => true,
					'value' => array(
						esc_html__( 'Large', 'bakery-shortcodes' ) => 'large',
						esc_html__( 'Medium', 'bakery-shortcodes' ) => 'medium',
						esc_html__( 'Small', 'bakery-shortcodes' ) => 'small'
					),
					'std' => 'medium',
					'save_always' => true,
					'description' => esc_html__( 'Select icon size.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'dropdown',
					'heading' => esc_html__( 'Alignment', 'bakery-shortcodes' ),
					'param_name' => 'alignment',
					'admin_label' => true,
					'value' => array(
						esc_html__( 'Left', 'bakery-shortcodes' ) => 'left',
						esc_html__( 'Center', 'bakery-shortcodes' ) => 'center',
						esc_html__( 'Right', 'bakery-shortcodes' ) => 'right'
					),
					'std' => 'left',
					'save_always' => true,
					'description' => esc_html__( 'Select social networks alignment.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Custom Colors?', 'bakery-shortcodes' ),
					'param_name' => 'custom_colors',
					'value' =>  array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Check to use custom colors.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Icons Normal Color', 'bakery-shortcodes' ),
					'param_name' => 'icons_normal_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-6',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select icons normal color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Icons Normal BG Color', 'bakery-shortcodes' ),
					'param_name' => 'icons_normal_bg_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-6',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select icons normal background color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Icons Hover Color', 'bakery-shortcodes' ),
					'param_name' => 'icons_hover_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-6',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select icons hover color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Icons Hover BG Color', 'bakery-shortcodes' ),
					'param_name' => 'icons_hover_bg_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-6',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select icons hover background color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Social Networks', 'bakery-shortcodes' ),
					'type' => 'universal',
					'heading' => esc_html__( 'Social Networks', 'bakery-shortcodes' ),
					'param_name' => 'social_networks',
					'template' => '<div class="vc_row"><div class="vc_col-xs-3 vu_m-b-10"><div class="wpb_element_label">' . esc_html__( 'Icon', 'bakery-shortcodes' ) . '</div><div class="input-group vu_ipc-container"><input data-placement="right" name="icon" class="icp vu_iconpicker" value="fa fa-facebook" type="text" /><span class="input-group-addon vu_ipc-icon"></span></div></div><div class="vc_col-xs-9"><div class="wpb_element_label">' . esc_html__( 'URL', 'bakery-shortcodes' ) . '</div><input name="url" type="text" value=""></div></div>',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Add social networks.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Design Options', 'bakery-shortcodes' ),
					'type' => 'css_editor',
					'heading' => esc_html__( 'CSS box', 'bakery-shortcodes' ),
					'param_name' => 'css'
				)
			)
		)
	);
}
