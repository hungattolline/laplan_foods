<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * Pie Chart Shortcode
 *
 * @param string $atts['style']
 * @param string $atts['type']
 * @param string $atts['text']
 * @param string $atts['icon_library']
 * @param string $atts['icon_milingona']
 * @param string $atts['icon_fontawesome']
 * @param string $atts['icon_bakery']
 * @param string $atts['value']
 * @param string $atts['line_width']
 * @param string $atts['size']
 * @param string $atts['text_color']
 * @param string $atts['bar_color']
 * @param string $atts['track_color']
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 * @param string $atts['css']
 */

if ( ! function_exists( 'bakery_pie_chart_shortcode' ) ) {
	function bakery_pie_chart_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'style' => '',
			'type' => '',
			'text' => '',
			'icon_library' => '',
			'icon_milingona' => '',
			'icon_fontawesome' => '',
			'icon_bakery' => '',
			'font_size' => '',
			'value' => '',
			'line_width' => '',
			'size' => '',
			'text_color' => '',
			'bar_color' => '',
			'track_color' => '',
			'class' => '',
			'css' => ''
		), $atts, 'vu_pie_chart' );

		if ( function_exists( 'vc_shortcode_custom_css_class' ) ) {
			$atts['class'] .= ' ' . vc_shortcode_custom_css_class( $atts['css'] );
		}

		$atts['class'] = trim( $atts['class'] );

		$size = absint( $atts['size'] );

		$pie_chart_options = array();

		$pie_chart_options['scaleColor'] = false;
		$pie_chart_options['lineCap'] = 'square';
		$pie_chart_options['animate'] = array( 'duration' => 1000, 'enabled' => true );

		$pie_chart_options['barColor'] = esc_attr( $atts['bar_color'] );
		$pie_chart_options['trackColor'] = ( $atts['style'] != '1' ) ? esc_attr( $atts['track_color'] ) : false;
		$pie_chart_options['lineWidth'] = absint( $atts['line_width'] );
		$pie_chart_options['size'] = $size;

		$custom_class = 'vu_pc-custom-' . rand( 100000, 999999 );

		ob_start(); ?>
		<div class="vu_pie-chart vu_pc-style-<?php echo esc_attr( $atts['style'] ); ?> <?php echo esc_attr( $custom_class ); ?><?php bakery_extra_class( $atts['class'] ); ?>">
			<div class="vu_pc-graph" data-percent="<?php echo esc_attr( $atts['value'] ); ?>" data-options="<?php echo esc_attr( json_encode( $pie_chart_options ) ); ?>"<?php echo ( $size > 0 ) ? ' style="height:' . $size . 'px;"' : ''; ?>>
				<div class="vu_pc-graph-text"<?php echo ( $size > 0) ? ' style="width:' . $size . 'px;height:' . $size . 'px;line-height:' . $size . 'px;margin-left:-' . $size / 2 . 'px;"' : ''; ?>>
					<?php 
						if ( $atts['type'] == 'icon' ) {
							echo '<span class="vu_pc-icon"' . ( ! empty( $atts['text_color'] ) ? ' style="font-size:' . esc_attr( $atts['font_size'] ) . 'px;color:' . esc_attr( $atts['text_color'] ) . ';"' : '' ) . '><i class="' . esc_attr( $atts['icon_' . esc_attr( $atts['icon_library'] )] ) . '"></i></span>';
						} else {
							echo '<span class="vu_pc-text" title="' . esc_attr( $atts['text'] ) . '"' . ( ! empty( $atts['text_color'] ) ? ' style="font-size:' . esc_attr( $atts['font_size'] ) . 'px;color:' . esc_attr( $atts['text_color'] ) . ';"' : '' ) . '>' . esc_html( $atts['text'] ) . '</span>';
						}
					?>
				</div>

				<?php echo ! empty( $atts['track_color'] ) ? '<style scoped>.vu_pie-chart.' . esc_attr( $custom_class ) . ' .vu_pc-graph-text:before,.vu_pie-chart.' . esc_attr( $custom_class ) . ' .vu_pc-graph-text:after{border-color:' . esc_attr( $atts['track_color'] ) . '!important;}.vu_pie-chart.' . esc_attr( $custom_class ) . ' .vu_pc-graph-text:after{top:' . absint( $atts['line_width'] ) . 'px;right:' . absint( $atts['line_width'] ) . 'px;bottom:' . absint( $atts['line_width'] ) . 'px;left:' . absint( $atts['line_width'] ) . 'px;}</style>' : ''; ?>
			</div>
		</div>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_pie_chart', 'bakery_pie_chart_shortcode' );

/**
 * Pie Chart VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_pie_chart' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_pie_chart extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_pie_chart', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_pie_chart', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'Pie Chart', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Custom animate pie chart', 'bakery-shortcodes' ),
			'base' => 'vu_pie_chart',
			'class' => 'vc_vu_pie_chart',
			'icon' => 'vu_element-icon vu_pie-chart-icon',
			'controls' => 'full',
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'type' => 'image_select',
					'heading' => esc_html__( 'Style', 'bakery-shortcodes' ),
					'param_name' => 'style',
					'value' => array(
						'1' => array(
							'title' => esc_html__( '#1', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/pie-chart-styles/1.jpg'
						),
						'2' => array(
							'title' => esc_html__( '#2', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/pie-chart-styles/2.jpg'
						),
						'3' => array(
							'title' => esc_html__( '#3', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/pie-chart-styles/3.jpg'
						)
					),
					'width' => 'calc(33.33333% - 10px)',
					'height' => 'auto',
					'std' => '1',
					'save_always' => true,
					'description' => esc_html__( 'Select pie chart style.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Type', 'bakery-shortcodes' ),
					'param_name' => 'type',
					'value' => array(
						esc_html__( 'Text', 'bakery-shortcodes' ) => 'text',
						esc_html__( 'Icon', 'bakery-shortcodes' ) => 'icon'
					),
					'save_always' => true,
					'description' => esc_html__( 'Select pie chart type.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Text', 'bakery-shortcodes' ),
					'param_name' => 'text',
					'dependency' => array( 'element' => 'type', 'value' => 'text' ),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter pie chart text.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Icon Library', 'bakery-shortcodes' ),
					'param_name' => 'icon_library',
					'dependency' => array( 'element' => 'type', 'value' => 'icon' ),
					'value' => array(
						esc_html__( 'Milingona', 'bakery-shortcodes' ) => 'milingona',
						esc_html__( 'FontAwesome', 'bakery-shortcodes' ) => 'fontawesome',
						esc_html__( 'Bakery', 'bakery-shortcodes' ) => 'bakery'
					),
					'save_always' => true,
					'description' => esc_html__( 'Select icon library.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'iconpicker',
					'heading' => esc_html__( 'Icon', 'bakery-shortcodes' ),
					'param_name' => 'icon_milingona',
					'dependency' => array( 'element' => 'icon_library', 'value' => 'milingona' ),
					'settings' => array(
						'emptyIcon' => false,
						'type' => 'milingona',
						'iconsPerPage' => 100
					),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Pick an icon from the library.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'iconpicker',
					'heading' => esc_html__( 'Icon', 'bakery-shortcodes' ),
					'param_name' => 'icon_bakery',
					'dependency' => array( 'element' => 'icon_library', 'value' => 'bakery' ),
					'settings' => array(
						'emptyIcon' => false,
						'type' => 'bakery',
						'iconsPerPage' => 100
					),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Pick an icon from the library.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'iconpicker',
					'heading' => esc_html__( 'Icon', 'bakery-shortcodes' ),
					'param_name' => 'icon_fontawesome',
					'dependency' => array( 'element' => 'icon_library', 'value' => 'fontawesome' ),
					'settings' => array(
						'emptyIcon' => false,
						'iconsPerPage' => 100
					),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Pick an icon from the library.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Value', 'bakery-shortcodes' ),
					'param_name' => 'value',
					'admin_label' => true,
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter value for graph from 0 to 100.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Line Width', 'bakery-shortcodes' ),
					'param_name' => 'line_width',
					'value' => '10',
					'save_always' => true,
					'description' => esc_html__( 'Enter pie chart line width in px.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Size', 'bakery-shortcodes' ),
					'param_name' => 'size',
					'value' => '170',
					'save_always' => true,
					'description' => esc_html__( 'Enter chart size (note: it applies for both width and height).', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Font Size', 'bakery-shortcodes' ),
					'param_name' => 'font_size',
					'value' => '36',
					'save_always' => true,
					'description' => esc_html__( 'Enter font size for text/icon in integer.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Text Color', 'bakery-shortcodes' ),
					'param_name' => 'text_color',
					'value' => '#343434',
					'save_always' => true,
					'description' => esc_html__( 'Select text/icon color.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Bar Color', 'bakery-shortcodes' ),
					'param_name' => 'bar_color',
					'value' => '#fdb822',
					'save_always' => true,
					'description' => esc_html__( 'Select bar color.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Track Color', 'bakery-shortcodes' ),
					'param_name' => 'track_color',
					'value' => '#e1e1e1',
					'save_always' => true,
					'description' => esc_html__( 'Select track color.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Design Options', 'bakery-shortcodes' ),
					'type' => 'css_editor',
					'heading' => esc_html__( 'CSS box', 'bakery-shortcodes' ),
					'param_name' => 'css'
				)
			)
		)
	);
}
