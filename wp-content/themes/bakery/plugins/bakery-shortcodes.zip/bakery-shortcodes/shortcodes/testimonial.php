<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * Testimonial Shortcode
 *
 * @param string $atts['image']
 * @param string $atts['name']
 * @param string $atts['position']
 * @param string $atts['content']
 * @param string $atts['alignment']
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 * @param string $atts['style']
 * @param string $atts['custom_colors']
 * @param string $atts['description_color']
 * @param string $atts['name_color']
 * @param string $atts['position_color']
 * @param string $atts['line_color']
 * @param string $atts['css']
 */

if ( ! function_exists( 'bakery_testimonial_shortcode' ) ) {
	function bakery_testimonial_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'image' => '',
			'name' => '',
			'position' => '',
			'description' => '',
			'alignment' => '',
			'class' => '',
			'style' => '',
			'custom_colors' => '',
			'description_color' => '',
			'name_color' => '',
			'position_color' => '',
			'line_color' => '',
			'css' => ''
		), $atts, 'vu_testimonial' );

		if ( $atts['custom_colors'] == '1' ) {
			$custom_class = bakery_custom_class();
			$atts['class'] .= ' ' . $custom_class;
		}

		if ( function_exists( 'vc_shortcode_custom_css_class' ) ) {
			$atts['class'] .= ' ' . vc_shortcode_custom_css_class( $atts['css'] );
		}

		$atts['class'] = trim( $atts['class'] );

		ob_start(); ?>
		<div class="vu_testimonial vu_t-style-<?php echo esc_attr( $atts['style'] ); ?> vu_t-alignment-<?php echo esc_attr( $atts['alignment'] ); ?> clearfix<?php bakery_extra_class( $atts['class'] ); ?>">
			<?php if ( $atts['custom_colors'] == '1' ) : ?>
				<style scoped>
					<?php if ( ! empty( $atts['description_color'] ) ) : ?>
						.vu_testimonial.<?php echo esc_attr( $custom_class ); ?> .vu_t-content p { color: <?php echo esc_attr( $atts['description_color'] ); ?> !important; }
					<?php endif; ?>
					<?php if ( ! empty( $atts['line_color'] ) ) : ?>
						.vu_testimonial.<?php echo esc_attr( $custom_class ); ?> .vu_t-author .vu_t-author-name:before { background-color: <?php echo esc_attr( $atts['line_color'] ); ?> !important; }
					<?php endif; ?>
					<?php if ( ! empty( $atts['name_color'] ) ) : ?>
						.vu_testimonial.<?php echo esc_attr( $custom_class ); ?> .vu_t-author .vu_t-author-name { color: <?php echo esc_attr( $atts['name_color'] ); ?> !important; }
					<?php endif; ?>
					<?php if ( ! empty( $atts['position_color'] ) ) : ?>
						.vu_testimonial.<?php echo esc_attr( $custom_class ); ?> .vu_t-author .vu_t-author-position { color: <?php echo esc_attr( $atts['position_color'] ); ?> !important; }
					<?php endif; ?>
				</style>
			<?php endif; ?>

			<div class="vu_t-container">
				<?php if ( ! empty( $atts['image'] ) ) : ?>
					<?php if ( $atts['style'] == '1' ) : ?>
						<div class="vu_t-author-image">
							<div class="vu_t-ai-holder">
								<span class="vu_lazy-load" data-img="<?php echo bakery_get_attachment_image_src( absint( $atts['image'] ), 'full' ); ?>"><?php echo wp_get_attachment_image( absint( $atts['image'] ), 'thumbnail' ); ?></span>
							</div>
						</div>
					<?php else : ?>
						<div class="vu_t-author-image">
							<?php echo wp_get_attachment_image( absint( $atts['image'] ), 'thumbnail' ); ?>
						</div>
					<?php endif; ?>
				<?php endif; ?>
				
				<div class="vu_t-content">
					<div class="vu_t-description clearfix">
						<?php echo wpautop( $atts['description'] ); ?>
					</div>

					<?php if ( ! empty( $atts['name'] ) || ! empty( $atts['position'] ) ) : ?>
						<div class="vu_t-author">
							<?php if ( ! empty( $atts['name'] ) ) : ?>
								<h4 class="vu_t-author-name<?php echo ( $atts['style'] == '1' && empty( $atts['position'] ) ) ? ' m-t-10 m-b-10' : ''; ?>"><?php echo esc_html( $atts['name'] ); ?></h4>
							<?php endif; ?>

							<?php if ( ! empty( $atts['position'] ) ) : ?>
								<span class="vu_t-author-position"><?php echo esc_html( $atts['position'] ); ?></span>
							<?php endif; ?>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_testimonial', 'bakery_testimonial_shortcode' );

/**
 * Video Section VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_testimonial' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_testimonial extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_testimonial', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_testimonial', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'Testimonial', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Show what your clients say', 'bakery-shortcodes' ),
			'base' => 'vu_testimonial',
			'class' => 'vc_vu_testimonial',
			'icon' => 'vu_element-icon vu_testimonial-icon',
			'controls' => 'full',
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'type' => 'attach_image',
					'heading' => esc_html__( 'Image', 'bakery-shortcodes' ),
					'param_name' => 'image',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select image from media library.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Name', 'bakery-shortcodes' ),
					'param_name' => 'name',
					'admin_label' => true,
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter author name.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Position', 'bakery-shortcodes' ),
					'param_name' => 'position',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter author position.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textarea',
					'heading' => esc_html__( 'Content', 'bakery-shortcodes' ),
					'param_name' => 'description',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter content.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Alignment', 'bakery-shortcodes' ),
					'param_name' => 'alignment',
					'value' => array(
						esc_html__( 'Left', 'bakery-shortcodes' ) => 'left',
						esc_html__( 'Center', 'bakery-shortcodes' ) => 'center',
						esc_html__( 'Right', 'bakery-shortcodes' ) => 'right'
					),
					'std' => 'center',
					'save_always' => true,
					'description' => esc_html__( 'Select testimonial alignment.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Style', 'bakery-shortcodes' ),
					'type' => 'image_select',
					'heading' => esc_html__( 'Style', 'bakery-shortcodes' ),
					'param_name' => 'style',
					'value' => array(
						'1' => array(
								'title' => esc_html__( '#1', 'bakery-shortcodes' ),
								'image' => Bakery_Shortcodes::$_url . 'assets/img/testimonial-styles/1.jpg'
							),
						'2' => array(
								'title' => esc_html__( '#2', 'bakery-shortcodes' ),
								'image' => Bakery_Shortcodes::$_url . 'assets/img/testimonial-styles/2.jpg'
							)
					),
					'width' => 'calc(50% - 10px)',
					'height' => 'auto',
					'std' => '1',
					'save_always' => true,
					'description' => esc_html__( 'Select testimonial style.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Colors', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Custom Colors?', 'bakery-shortcodes' ),
					'param_name' => 'custom_colors',
					'value' =>  array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Check to use custom colors.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Colors', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Content Color', 'bakery-shortcodes' ),
					'param_name' => 'description_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-6',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select content color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Colors', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Line Color', 'bakery-shortcodes' ),
					'param_name' => 'line_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-6',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select line color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Colors', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Name Color', 'bakery-shortcodes' ),
					'param_name' => 'name_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-6',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select name color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Colors', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Position Color', 'bakery-shortcodes' ),
					'param_name' => 'position_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-6',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select position color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Design Options', 'bakery-shortcodes' ),
					'type' => 'css_editor',
					'heading' => esc_html__( 'CSS box', 'bakery-shortcodes' ),
					'param_name' => 'css'
				)
			)
		)
	);
}
