<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * Team Member Shortcode
 *
 * @param string $atts['image']
 * @param string $atts['ratio']
 * @param string $atts['name']
 * @param string $atts['link']
 * @param string $atts['position']
 * @param string $atts['description']
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 * @param string $atts['style']
 * @param string $atts['show_social_networks']
 * @param string $atts['social_networks']
 * @param string $atts['css']
 */

if ( ! function_exists( 'bakery_team_member_shortcode' ) ) {
	function bakery_team_member_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'image' => '',
			'ratio' => '',
			'name' => '',
			'link' => '',
			'position' => '',
			'description' => '',
			'class' => '',
			'style' => '',
			'show_social_networks' => '',
			'social_networks' => '',
			'css' => ''
		), $atts, 'vu_team_member' );

		$link = ( function_exists( 'vc_build_link' ) ) ? vc_build_link( $atts['link'] ) : array( 'url' => '', 'title' => '', 'target' => '' );

		$social_networks = json_decode( rawurldecode( base64_decode( $atts['social_networks'] ) ), true );

		if ( function_exists( 'vc_shortcode_custom_css_class' ) ) {
			$atts['class'] .= ' ' . vc_shortcode_custom_css_class( $atts['css'] );
		}

		$atts['class'] = trim( $atts['class'] );

		ob_start(); ?>
		<div class="vu_team-member vu_tm-style-<?php echo esc_attr( $atts['style'] ); ?><?php bakery_extra_class( $atts['class'] ); ?>">
			<?php if ( $atts['style'] != '2' ) : ?>
				<div class="vu_tm-container">
					<?php if ( ! empty( $atts['image'] ) ) : ?>
						<div class="vu_tm-image">
							<?php echo wp_get_attachment_image( $atts['image'], ( ( $atts['style'] == '1' ) ? 'bakery_ratio-' . $atts['ratio'] : 'medium' ), false ); ?>

							<?php if ( $atts['show_social_networks'] == "1" and is_array( $social_networks ) and ! empty( $social_networks ) ) : ?>
								<div class="vu_tm-social-networks">
									<ul class="list-unstyled">
										<?php 
											foreach ( $social_networks as $social_network ) {
												if ( ! empty( $social_network['icon'] ) ) {
													echo '<li><a href="' . esc_url( $social_network['url'] ) . '" target="_blank"><i class="fa ' . esc_attr( $social_network['icon'] ) . '"></i></a></li>';
												}
											}
										?>
									</ul>
								</div>
							<?php endif; ?>
						</div>
					<?php endif; ?>

					<div class="vu_tm-info">
						<?php 
							if ( strlen( $atts['link'] ) > 0 && strlen( $link['url'] ) > 0 ) {
								echo '<h4 class="vu_tm-name"><a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '" target="' . ( strlen( $link['target'] ) > 0 ? esc_attr( $link['target'] ) : '_self' ) . '">' . esc_html( $atts['name'] ) . '</a></h4>';
							} else {
								echo '<h4 class="vu_tm-name">' . esc_html( $atts['name'] ) . '</h4>';
							}
						?>
						
						<?php if ( ! empty( $atts['position'] ) ) : ?>
							<span class="vu_tm-position"><?php echo esc_html( $atts['position'] ); ?></span>
						<?php endif; ?>
					</div>
				</div>
				
				<?php if ( ! empty( $atts['description'] ) ) : ?>
					<div class="vu_tm-description">
						<?php echo wpautop( $atts['description'] ); ?>
					</div>
				<?php endif; ?>
			<?php else : ?>
				<?php if ( ! empty( $atts['image'] ) ) : ?>
					<div class="vu_tm-image">
						<?php echo wp_get_attachment_image( $atts['image'], 'bakery_ratio-' . $atts['ratio'], false ); ?>
					</div>
				<?php endif; ?>

				<div class="vu_tm-container">
					<div class="vu_tm-info">
						<?php 
							if ( strlen( $atts['link'] ) > 0 && strlen( $link['url'] ) > 0 ) {
								echo '<h4 class="vu_tm-name"><a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '" target="' . ( strlen( $link['target'] ) > 0 ? esc_attr( $link['target'] ) : '_self' ) . '">' . esc_html( $atts['name'] ) . '</a></h4>';
							} else {
								echo '<h4 class="vu_tm-name">' . esc_html( $atts['name'] ) . '</h4>';
							}
						?>
						
						<?php if ( ! empty( $atts['position'] ) ) : ?>
							<span class="vu_tm-position"><?php echo esc_html( $atts['position'] ); ?></span>
						<?php endif; ?>
					</div>
					
					<?php if ( ! empty( $atts['description'] ) ) : ?>
						<div class="vu_tm-description">
							<?php echo wpautop( $atts['description'] ); ?>
						</div>
					<?php endif; ?>

					<?php if ( $atts['show_social_networks'] == "1" && ! empty( $social_networks ) && is_array( $social_networks ) ) : ?>
						<div class="vu_tm-social-networks">
							<ul class="list-unstyled">
								<?php 
									foreach ( $social_networks as $social_network ) {
										if ( ! empty( $social_network['icon'] ) ) {
											echo '<li><a href="' . esc_url( $social_network['url'] ) . '" target="_blank"><i class="fa ' . esc_attr( $social_network['icon'] ) . '"></i></a></li>';
										}
									}
								?>
							</ul>
						</div>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_team_member', 'bakery_team_member_shortcode' );

/**
 * Team Member VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_team_member' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_team_member extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_team_member', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_team_member', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'Team Member', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Add team member', 'bakery-shortcodes' ),
			'base' => 'vu_team_member',
			'class' => 'vc_vu_team_member',
			'icon' => 'vu_element-icon vu_team-member-icon',
			'controls' => 'full',
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'attach_image',
					'heading' => esc_html__( 'Image', 'bakery-shortcodes' ),
					'param_name' => 'image',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select member image.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'dropdown',
					'heading' => esc_html__( 'Ratio', 'bakery-shortcodes' ),
					'param_name' => 'ratio',
					'value' => bakery_get_image_ratios(),
					'std' => '3:4',
					'save_always' => true,
					'description' => esc_html__( 'Select image ratio.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Name', 'bakery-shortcodes' ),
					'param_name' => 'name',
					'admin_label' => true,
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter member name.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'vc_link',
					'heading' => esc_html__( 'URL (Link)', 'bakery-shortcodes' ),
					'param_name' => 'link',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Add link to name.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Position', 'bakery-shortcodes' ),
					'param_name' => 'position',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter member position.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'textarea',
					'heading' => esc_html__( 'Description', 'bakery-shortcodes' ),
					'param_name' => 'description',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter member description.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Style', 'bakery-shortcodes' ),
					'type' => 'image_select',
					'heading' => esc_html__( 'Style', 'bakery-shortcodes' ),
					'param_name' => 'style',
					'value' =>  array(
						'1' => array(
							'title' => esc_html__( '#1', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/team-member-styles/1.jpg'
						),
						'2' => array(
							'title' => esc_html__( '#2', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/team-member-styles/2.jpg'
						),
						'3' => array(
							'title' => esc_html__( '#3', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/team-member-styles/3.jpg'
						)
					),
					'width' => 'calc(100% / 3 - 10px)',
					'height' => 'auto',
					'std' => '1',
					'save_always' => true,
					'description' => esc_html__( 'Select team member style.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Social Networks', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Show social networks?', 'bakery-shortcodes' ),
					'param_name' => 'show_social_networks',
					'value' =>  array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Check to show social networks.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Social Networks', 'bakery-shortcodes' ),
					'type' => 'universal',
					'heading' => esc_html__( 'Social Networks', 'bakery-shortcodes' ),
					'param_name' => 'social_networks',
					'dependency' => array( 'element' => 'show_social_networks', 'value' => '1' ),
					'template' => '<div class="vc_row"><div class="vc_col-xs-3 vu_m-b-10"><div class="wpb_element_label">' . esc_html__( 'Icon', 'bakery-shortcodes' ) . '</div><div class="input-group vu_ipc-container"><input data-placement="right" name="icon" class="icp vu_iconpicker" value="fa fa-facebook" type="text" /><span class="input-group-addon vu_ipc-icon"></span></div></div><div class="vc_col-xs-9"><div class="wpb_element_label">' . esc_html__( 'URL', 'bakery-shortcodes' ) . '</div><input name="url" type="text" value=""></div></div>',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Add social networks.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Design Options', 'bakery-shortcodes' ),
					'type' => 'css_editor',
					'heading' => esc_html__( 'CSS box', 'bakery-shortcodes' ),
					'param_name' => 'css'
				)
			)
		)
	);
}
