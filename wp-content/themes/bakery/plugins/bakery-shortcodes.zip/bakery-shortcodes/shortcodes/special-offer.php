<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * Special Offer Shortcode
 *
 * @param string $atts['scheme_color']
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 */

if ( ! function_exists( 'bakery_social_networks_shortcode' ) ) {
	function bakery_special_offer_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'scheme_color' => '',
			'class' => ''
		), $atts, 'vu_special_offer' );

		$special_offer_items = array();

		$content = strip_tags( str_replace( '[vc_container_anchor]', '', $content ) );

		$explode = explode( '[vu_special_offer_item', $content );

		foreach ( $explode as $key => $value ) {
			if ( ! empty( $value ) ) {
				preg_match_all( '/((?:(?!\s|=).)*)\s*?=\s*?["\']?((?:(?<=")(?:(?<=\\\\)"|[^"])*|(?<=\')(?:(?<=\\\\)\'|[^\'])*)|(?:(?!"|\')(?:(?!\/>|>|\s).)+))/', '[vu_special_offer_item' . $value, $atts_matches, PREG_SET_ORDER );

				$_atts = array( '_id' => rand( 10000, 99999 ) );

				foreach ( $atts_matches as $a ) {
					$_atts[ $a[1] ] = $a[2];
				}

				$_atts = bakery_prepare_atts( $_atts );
				
				array_push( $special_offer_items, $_atts );
			}
		}

		ob_start(); ?>
		<div class="vu_special-offer vu_so-scheme-<?php echo esc_attr( $atts['scheme_color'] ); ?> clearfix<?php bakery_extra_class( $atts['class'] ); ?>">
			<div class="vu_so-tabs">
				<?php $num = 1; ?>
				<?php foreach ( $special_offer_items as $special_offer_item ) : ?>
					<div class="vu_so-tab<?php echo ( $num == 1 ) ? ' active' : ''; ?>" data-id="<?php echo esc_attr( $special_offer_item['_id'] ); ?>">
						<?php echo wp_get_attachment_image( $special_offer_item['thumbnail'], 'thumbnail' ); ?>
					</div>
					<?php $num++; ?>
				<?php endforeach; ?>
			</div>

			<div class="vu_so-panes clearfix">
				<?php $num = 1; ?>
				<?php foreach ( $special_offer_items as $special_offer_item ) : ?>
					<div class="vu_so-pane<?php echo ( $num == 1 ) ? ' active' : ''; ?>" data-id="<?php echo esc_attr( $special_offer_item['_id'] ); ?>">
						<div class="vu_so-pane-left">
							<?php if ( ! empty( $special_offer_item['name'] ) ) : ?>
								<div class="vu_so-item-header">
									<h3 class="vu_so-item-name"><?php echo esc_html( $special_offer_item['name'] ); ?></h3>
								</div>
							<?php endif; ?>

							<?php if ( ! empty( $special_offer_item['description'] ) ) : ?>
								<div class="vu_so-item-content">
									<?php echo wpautop( $special_offer_item['description'] ); ?>
								</div>
							<?php endif; ?>

							<?php $button_link = ( function_exists( 'vc_build_link' ) ) ? vc_build_link( $special_offer_item['button_link'] ) : array( 'url' => '', 'title' => '', 'target' => '' ); ?>

							<?php if ( ! empty( $special_offer_item['currency'] ) || ! empty( $special_offer_item['price'] ) || (! empty( $special_offer_item['button_text'] ) && strlen( $special_offer_item['button_link'] ) > 0 && strlen( $button_link['url'] ) > 0 ) ) : ?>
								<div class="vu_so-item-footer">
									<?php if ( ! empty( $special_offer_item['currency'] ) || ! empty( $special_offer_item['price'] ) ) : ?>
										<div class="vu_so-item-price">
											<?php if ( ! empty( $special_offer_item['currency'] ) ) : ?>
												<span><?php echo esc_html( bakery_get_currency_symbol( $special_offer_item['currency'] ) ); ?></span>
											<?php endif; ?>

											<?php if ( ! empty( $special_offer_item['price'] ) ) : ?>
												<span><?php echo esc_html( $special_offer_item['price'] ); ?></span>
											<?php endif; ?>
										</div>
									<?php endif; ?>

									<?php if ( ! empty( $special_offer_item['button_text'] ) && strlen( $special_offer_item['button_link'] ) > 0 && strlen( $button_link['url'] ) > 0 ) : ?>
										<div class="vu_so-item-btn">
											<a href="<?php echo esc_url( $button_link['url'] ); ?>" target="<?php echo ( strlen( $button_link['target'] ) > 0) ? esc_attr( $button_link['target'] ) : '_self'; ?>" class="btn <?php echo ( $atts['scheme_color'] != "dark") ? 'btn-primary' : 'btn-white'; ?> btn-inverse btn-icon">
												<span><?php echo esc_html( $special_offer_item['button_text'] ); ?></span>
												<i class="fa fa-long-arrow-right"></i>
											</a>
										</div>
									<?php endif; ?>
								</div>
							<?php endif; ?>
						</div>

						<?php if ( ! empty( $special_offer_item['label'] ) || ! empty( $special_offer_item['image'] ) ) : ?>
							<div class="vu_so-pane-right">
								<?php if ( ! empty( $special_offer_item['label'] ) ) : ?>
									<div class="vu_so-item-label">
										<span><?php echo esc_html( $special_offer_item['label'] ); ?></span>
									</div>
								<?php endif; ?>

								<?php if ( ! empty( $special_offer_item['image'] ) ) : ?>
									<div class="vu_so-item-image vu_lazy-load" data-img="<?php echo bakery_get_attachment_image_src( absint( $special_offer_item['image'] ), 'full' ); ?>">
										<?php echo wp_get_attachment_image( $special_offer_item['image'], 'bakery_ratio-1:1', false ); ?>
									</div>
								<?php endif; ?>
							</div>
						<?php endif; ?>
					</div>
					<?php $num++; ?>
				<?php endforeach; ?>
			</div>
		</div>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_special_offer', 'bakery_special_offer_shortcode' );

/**
 * Special Offer VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_special_offer' ) && class_exists( 'WPBakeryShortCodesContainer' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_special_offer extends WPBakeryShortCodesContainer {}

	vc_map(
		array(
			'name' => esc_html__( 'Special Offer', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Make specific items featured', 'bakery-shortcodes' ),
			'base' => 'vu_special_offer',
			'class' => 'vc_vu_special-offer',
			'icon' => 'vu_element-icon vu_special-offer-icon',
			'controls' => 'full',
			'as_parent' => array( 'only' => 'vu_special_offer_item' ),
			'js_view' => 'VcColumnView',
			'content_element' => true,
			'is_container' => true,
			'container_not_allowed' => false,
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'default_content' => '[vu_special_offer_item]',
			'params'	=> array(
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Scheme Color', 'bakery-shortcodes' ),
					'param_name' => 'scheme_color',
					'value' => array(
						esc_html__( 'Light', 'bakery-shortcodes' ) => 'light',
						esc_html__( 'Dark', 'bakery-shortcodes' ) => 'dark'
					),
					'std' => 'light',
					'save_always' => true,
					'description' => esc_html__( 'Select special offer scheme color.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				)
			)
		)
	);
}
