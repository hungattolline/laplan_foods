<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * Image Box Shortcode
 *
 * @param string $atts['image']
 * @param string $atts['position']
 * @param string $atts['ratio']
 * @param string $atts['title']
 * @param string $atts['link']
 * @param string $atts['description']
 * @param string $atts['read_more_text']
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 * @param string $atts['css']
 */

if ( ! function_exists( 'bakery_image_box_shortcode' ) ) {
	function bakery_image_box_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'image' => '',
			'position' => '',
			'ratio' => '',
			'title' => '',
			'link' => '',
			'description' => '',
			'read_more_text' => '',
			'class' => '',
			'css' => ''
		), $atts, 'vu_image_box' );

		if ( function_exists( 'vc_shortcode_custom_css_class' ) ) {
			$atts['class'] .= ' ' . vc_shortcode_custom_css_class( $atts['css'] );
		}

		$atts['class'] = trim( $atts['class'] );

		$link = ( function_exists( 'vc_build_link' ) ) ? vc_build_link( $atts['link'] ) : array( 'url' => '', 'title' => '', 'target' => '' );

		ob_start(); ?>
		<div class="vu_ib-image">
			<?php if ( strlen( $atts['link'] ) > 0 && strlen( $link['url'] ) > 0 ) {
				echo '<a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '" target="' . ( strlen( $link['target'] ) > 0 ? esc_attr( $link['target'] ) : '_self' ) . '">' . wp_get_attachment_image( absint( $atts['image'] ), 'bakery_ratio-' . esc_attr( $atts['ratio'] ) ) . '</a>';
			} else { 
				echo wp_get_attachment_image( absint( $atts['image'] ), 'bakery_ratio-' . esc_attr( $atts['ratio'] ) );
			} ?>
		</div>
		<?php $image = ob_get_clean(); ?>

		<?php ob_start(); ?>
		<div class="vu_image-box vu_ib-position-<?php echo esc_attr( $atts['position'] ); ?> clearfix<?php bakery_extra_class( $atts['class'] ); ?>">
			<?php echo ( $atts['position'] == 'top' ) ? $image : ''; ?>
			<div class="vu_ib-content">
				<h4 class="vu_ib-title">
					<?php if ( strlen( $atts['link'] ) > 0 && strlen( $link['url'] ) > 0 ) {
						echo '<a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '" target="' . ( strlen( $link['target'] ) > 0 ? esc_attr( $link['target'] ) : '_self' ) . '">' . esc_html( $atts['title'] ) . '</a>';
					} else { 
						echo esc_html( $atts['title'] );
					} ?>
				</h4>

				<?php echo ! empty( $atts['description'] ) ? '<div class="vu_ib-description">' . wpautop( $atts['description'] ) . '</div>' : ''; ?>

				<?php if ( $atts['read_more_text'] != '' && strlen( $atts['link'] ) > 0 && strlen( $link['url'] ) > 0 ) {
					echo '<div class="clear"></div><a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '" target="' . ( strlen( $link['target'] ) > 0 ? esc_attr( $link['target'] ) : '_self' ) . '" class="vu_ib-read-more vu_link-inverse">' . esc_html( $atts['read_more_text'] ) . '<i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>';
				} ?>
			</div>

			<?php echo ( $atts['position'] == 'bottom' ) ? $image : ''; ?>
		</div>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_image_box', 'bakery_image_box_shortcode' );

/**
 * Image Box VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_image_box' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_image_box extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_image_box', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_image_box', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'Image Box', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Text with image', 'bakery-shortcodes' ),
			'base' => 'vu_image_box',
			'class' => 'vc_vu_image_box',
			'icon' => 'vu_element-icon vu_image-box-icon',
			'controls' => 'full',
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'type' => 'attach_image',
					'heading' => esc_html__( 'Image', 'bakery-shortcodes' ),
					'param_name' => 'image',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select image from media library.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Ratio', 'bakery-shortcodes' ),
					'param_name' => 'ratio',
					'value' => bakery_get_image_ratios(),
					'std' => '2:1',
					'save_always' => true,
					'description' => esc_html__( 'Select image ratio.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Position', 'bakery-shortcodes' ),
					'param_name' => 'position',
					'value' => array(
						esc_html__( 'Top', 'bakery-shortcodes' ) => 'top',
						esc_html__( 'Bottom', 'bakery-shortcodes' ) => 'bottom',
					),
					'std' => 'top',
					'save_always' => true,
					'description' => esc_html__( 'Select image position.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Title', 'bakery-shortcodes' ),
					'param_name' => 'title',
					'admin_label' => true,
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter title.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textarea',
					'heading' => esc_html__( 'Description', 'bakery-shortcodes' ),
					'param_name' => 'description',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter description.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Read more text', 'bakery-shortcodes' ),
					'param_name' => 'read_more_text',
					'admin_label' => true,
					'value' => 'Read More',
					'save_always' => true,
					'description' => esc_html__( 'Enter read more text.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'vc_link',
					'heading' => esc_html__( 'URL (Link)', 'bakery-shortcodes' ),
					'param_name' => 'link',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Add link to image box.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Design Options', 'bakery-shortcodes' ),
					'type' => 'css_editor',
					'heading' => esc_html__( 'CSS box', 'bakery-shortcodes' ),
					'param_name' => 'css'
				)
			)
		)
	);
}
