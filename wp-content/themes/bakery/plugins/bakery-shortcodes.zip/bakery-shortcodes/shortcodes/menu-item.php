<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * Menu Item Shortcode
 *
 * @param string $atts['title']
 * @param string $atts['link']
 * @param string $atts['description']
 * @param string $atts['older_price']
 * @param string $atts['current_price']
 * @param string $atts['custom_colors']
 * @param string $atts['description_color']
 * @param string $atts['older_price_color']
 * @param string $atts['current_price_color']
 * @param string $atts['line_color']
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 * @param string $atts['css']
 */

if ( ! function_exists( 'bakery_menu_item_shortcode' ) ) {
	function bakery_menu_item_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'title' => '',
			'link' => '',
			'description' => '',
			'older_price' => '',
			'current_price' => '',
			'custom_colors' => '',
			'title_color' => '',
			'description_color' => '',
			'older_price_color' => '',
			'current_price_color' => '',
			'line_color' => '',
			'class' => '',
			'css' => ''
		), $atts, 'vu_menu_item' );

		$link = ( function_exists( 'vc_build_link' ) ) ? vc_build_link( $atts['link'] ) : array( 'url' => '', 'title' => '', 'target' => '' );

		if ( $atts['custom_colors'] == '1' ) {
			$custom_class = bakery_custom_class();
			$atts['class'] .= ' ' . $custom_class;
		}

		if ( function_exists( 'vc_shortcode_custom_css_class' ) ) {
			$atts['class'] .= ' ' . vc_shortcode_custom_css_class( $atts['css'] );
		}

		$atts['class'] = trim( $atts['class'] );

		ob_start(); ?>
		<div class="vu_menu-item<?php echo ( ! empty( $atts['older_price'] ) ) ? ' vu_mi-with-older-price' : ''; ?> clearfix<?php bakery_extra_class( $atts['class'] ); ?>">
			<?php if ( $atts['custom_colors'] == '1' ) : ?>
				<style scoped>
					<?php if ( ! empty( $atts['title_color'] ) ) : ?>
						.vu_menu-item.<?php echo esc_attr( $custom_class ); ?> .vu_mi-title { color: <?php echo esc_attr( $atts['title_color'] ); ?> }
					<?php endif; ?>
					<?php if ( ! empty( $atts['description_color'] ) ) : ?>
						.vu_menu-item.<?php echo esc_attr( $custom_class ); ?> .vu_mi-description { color: <?php echo esc_attr( $atts['description_color'] ); ?> }
					<?php endif; ?>
					<?php if ( ! empty( $atts['older_price_color'] ) ) : ?>
						.vu_menu-item.<?php echo esc_attr( $custom_class ); ?> .vu_mi-price { color: <?php echo esc_attr( $atts['older_price_color'] ); ?> }
					<?php endif; ?>
					<?php if ( ! empty( $atts['current_price_color'] ) ) : ?>
						.vu_menu-item.<?php echo esc_attr( $custom_class ); ?> .vu_mi-price { color: <?php echo esc_attr( $atts['current_price_color'] ); ?> }
					<?php endif; ?>
					<?php if ( ! empty( $atts['line_color'] ) ) : ?>
						.vu_menu-item.<?php echo esc_attr( $custom_class ); ?> .vu_mi-line { border-color: <?php echo esc_attr( $atts['line_color'] ); ?> }
					<?php endif; ?>
				</style>
			<?php endif; ?>

			<div class="vu_mi-wrapper">
				<h4 class="vu_mi-title">
					<?php if ( strlen( $atts['link'] ) > 0 && strlen( $link['url'] ) > 0 ) {
						echo '<a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '" target="' . ( strlen( $link['target'] ) > 0 ? esc_attr( $link['target'] ) : '_self' ) . '">' . esc_html( $atts['title'] ) . '</a>';
					} else { 
						echo esc_html( $atts['title'] );
					} ?>
				</h4>

				<div class="vu_mi-line"></div>

				<h4 class="vu_mi-price">
					<?php if ( ! empty( $atts['older_price'] ) ) : ?>
						<span class="vu_mi-older-price"><del><?php echo esc_html( $atts['older_price'] ); ?></del></span>
					<?php endif; ?>

					<span class="vu_mi-current-price"><?php echo esc_html( $atts['current_price'] ); ?></span>
				</h4>
			</div>

			<div class="clear"></div>

			<?php echo ! empty( $atts['description'] ) ? '<div class="vu_mi-description">' . wpautop( $atts['description'] ) . '</div>' : ''; ?>
		</div>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_menu_item', 'bakery_menu_item_shortcode' );

/**
 * Menu Item VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_menu_item' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_menu_item extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_menu_item', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_menu_item', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'Menu Item', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Add menu item', 'bakery-shortcodes' ),
			'base' => 'vu_menu_item',
			'class' => 'vc_vu_menu-item',
			'icon' => 'vu_element-icon vu_menu-item-icon',
			'controls' => 'full',
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Title', 'bakery-shortcodes' ),
					'param_name' => 'title',
					'admin_label' => true,
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter menu item title.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'vc_link',
					'heading' => esc_html__( 'URL (Link)', 'bakery-shortcodes' ),
					'param_name' => 'link',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Add link to menu item.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textarea',
					'heading' => esc_html__( 'Description', 'bakery-shortcodes' ),
					'param_name' => 'description',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter description.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Current Price', 'bakery-shortcodes' ),
					'param_name' => 'current_price',
					'admin_label' => true,
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter current price.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Older Price', 'bakery-shortcodes' ),
					'param_name' => 'older_price',
					'admin_label' => true,
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter price if menu item is on sale.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Colors', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Custom Colors?', 'bakery-shortcodes' ),
					'param_name' => 'custom_colors',
					'value' =>  array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Check to use custom colors.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Colors', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Title Color', 'bakery-shortcodes' ),
					'param_name' => 'title_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-6',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select title text custom color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Colors', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Description Color', 'bakery-shortcodes' ),
					'param_name' => 'description_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-6',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select description text custom color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Colors', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Older Price Color', 'bakery-shortcodes' ),
					'param_name' => 'older_price_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-6',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select price custom color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Colors', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Current Price Color', 'bakery-shortcodes' ),
					'param_name' => 'current_price_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-6',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select price custom color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Colors', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Line Color', 'bakery-shortcodes' ),
					'param_name' => 'line_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select line custom color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Design Options', 'bakery-shortcodes' ),
					'type' => 'css_editor',
					'heading' => esc_html__( 'CSS box', 'bakery-shortcodes' ),
					'param_name' => 'css'
				)
			)
		)
	);
}
