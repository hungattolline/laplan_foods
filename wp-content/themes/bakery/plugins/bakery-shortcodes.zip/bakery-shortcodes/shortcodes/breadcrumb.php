<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * Breadcrumb Shortcode
 *
 * Modified by Milingona
 *
 * @see https://gist.github.com/Dimox/5654092
 */

if ( ! function_exists( 'bakery_breadcrumb_shortcode' ) ) {
    function bakery_breadcrumb_shortcode( $atts = array(), $content = null ) {
        ob_start();

        $text['home'] = esc_html__( 'Home', 'bakery-shortcodes' ); // text for the 'Home' link
        $text['shop'] = esc_html__( 'Shop', 'bakery-shortcodes' ); // text for the 'Shop' link
        $text['category'] = esc_html__( "All posts from '%s' category", 'bakery-shortcodes' ); // text for a category page
        $text['search'] = esc_html__( 'Search Results for "%s" Query', 'bakery-shortcodes' ); // text for a search results page
        $text['tag'] = esc_html__( "All posts tagged with '%s'", 'bakery-shortcodes' ); // text for a tag page
        $text['author'] = esc_html__( 'Posts by %s', 'bakery-shortcodes' ); // text for an author page
        $text['404'] = esc_html__( 'Error 404', 'bakery-shortcodes' ); // text for the 404 page
        $text['page'] = esc_html__( 'Page %s', 'bakery-shortcodes' ); // text 'Page N'
        $text['cpage'] = esc_html__( 'Comment Page %s', 'bakery-shortcodes' ); // text 'Comment Page N'

        $delimiter = '<i class="fa fa-angle-right"></i>'; // delimiter between crumbs
        $delim_before = '<span class="divider">'; // tag before delimiter
        $delim_after = '</span>'; // tag after delimiter
        $show_home_link = 1; // 1 - show the 'Home' link, 0 - don't show
        $show_on_home = 1; // 1 - show breadcrumbs on the homepage, 0 - don't show
        $show_current = 1; // 1 - show current page title, 0 - don't show
        $show_title = 1; // 1 - show the title for the links, 0 - don't show
        $before = '<span class="current">'; // tag before the current crumb
        $after = '</span>'; // tag after the current crumb

        global $post;

        $home_link = esc_url( home_url( '/' ) );
        $shop_link = esc_url( get_permalink( get_option( 'woocommerce_shop_page_id' ) ) );
        $link_before = '<span>';
        $link_after = '</span>';
        $link_attr = '';
        $link_in_before = '<span>';
        $link_in_after  = '</span>';
        $link = $link_before . '<a href="%1$s"' . $link_attr . '>' . $link_in_before . '%2$s' . $link_in_after . '</a>' . $link_after;
        $frontpage_id = get_option( 'page_on_front' );
        $blogpage_id = get_option( 'page_for_posts' );
        $parent_id = ( $post ) ? $post->post_parent : null;
        $delimiter = ' ' . $delim_before . $delimiter . $delim_after . ' ';

        if ( is_home() || is_front_page() ) {
            if ( $show_on_home == 1 ) {
                echo '<div class="breadcrumbs"><a href="' . $home_link . '">' . $text['home'] . '</a>' . ( ( is_home() && $show_current == 1 ) ? ( $delimiter ) . $before . get_the_title( $blogpage_id ) . $after : '' ) . '</div>';
            }
        } else {
            echo '<div class="breadcrumbs">';

            if ( $show_home_link == 1 ) {
                if ( function_exists( 'bakery_is_woocommerce' ) && bakery_is_woocommerce() ) {
                    echo sprintf( $link, $shop_link, $text['shop'] );
                } else {
                    echo sprintf( $link, $home_link, $text['home'] );
                }
            }

            if ( is_category() ) {
                $cat = get_category( get_query_var( 'cat' ), false );

                if ( $cat->parent != 0 ) {
                    $cats = get_category_parents( $cat->parent, true, $delimiter );
                    $cats = preg_replace( "#^(.+)$delimiter$#", "$1", $cats );
                    $cats = preg_replace( '#<a([^>]+)>([^<]+)<\/a>#', $link_before . '<a$1' . $link_attr .'>' . $link_in_before . '$2' . $link_in_after . '</a>' . $link_after, $cats );

                    if ( $show_title == 0 ) {
                        $cats = preg_replace( '/ title="(.*?)"/', '', $cats );
                    }

                    if ( $show_home_link == 1 ) {
                        echo $delimiter;
                    }

                    echo $cats;
                }
                if ( get_query_var( 'paged' ) ) {
                    $cat = $cat->cat_ID;
                    echo $delimiter . sprintf( $link, get_category_link( $cat ), get_cat_name( $cat ) ) . $delimiter . $before . sprintf( $text['page'], get_query_var( 'paged' ) ) . $after;
                } else {
                    if ( $show_current == 1 ) {
                        echo $delimiter . $before . sprintf( $text['category'], single_cat_title( '', false ) ) . $after;
                    }
                }
            } elseif ( is_search() ) {
                if ( $show_home_link == 1 ) {
                    echo $delimiter;
                }

                echo $before . sprintf( $text['search'], get_search_query() ) . $after;

            } elseif ( is_day() ) {
                if ( $show_home_link == 1 ) {
                    echo $delimiter;
                }

                echo sprintf( $link, get_year_link( get_the_time( 'Y' ) ), get_the_time( 'Y' ) ) . $delimiter;
                echo sprintf( $link, get_month_link( get_the_time( 'Y' ), get_the_time( 'm' ) ), get_the_time( 'F' ) ) . $delimiter;
                echo $before . get_the_time( 'd' ) . $after;

            } elseif ( is_month() ) {
                if ( $show_home_link == 1 ) {
                    echo $delimiter;
                }

                echo sprintf( $link, get_year_link( get_the_time( 'Y' ) ), get_the_time( 'Y' ) ) . $delimiter;
                echo $before . get_the_time( 'F' ) . $after ;

            } elseif ( is_year() ) {
                if ( $show_home_link == 1 ) {
                    echo $delimiter;
                };

                echo $before . get_the_time( 'Y' ) . $after;

            } elseif ( is_single() && ! is_attachment() ) {
                if ( $show_home_link == 1 ) {
                    echo $delimiter;
                }

                if ( get_post_type() == 'product' ) {
                    $cats = wp_get_post_terms( $post->ID, 'product_cat' );
                    
                    if ( $cats && ! is_wp_error( $cats ) ) {
                        foreach ( $cats as $cat ) {
                            foreach ( get_ancestors( $cat->term_id, 'product_cat' ) as $ancestor_id ) {
                                $ancestor = get_term( $ancestor_id, 'product_cat' );
                                
                                if ( $ancestor && ! is_wp_error( $ancestor ) ) {
                                    printf( $link, get_term_link( $ancestor->term_id, 'product_cat' ), $ancestor->name );
                                    
                                    echo $delimiter;
                                }
                            }
                            
                            printf( $link, get_term_link( $cat->term_id, 'product_cat' ), $cat->name );
                        }
                    }

                    if ( $show_current == 1 ) {
                        echo $delimiter . $before . get_the_title() . $after;
                    }
                } elseif ( get_post_type() != 'post' ) {
                    $post_type = get_post_type_object( get_post_type() );

                    $slug = $post_type->rewrite;

                    printf( $link, $home_link . $slug['slug'] . '/', $post_type->labels->singular_name );

                    if ( $show_current == 1 ) {
                        echo $delimiter . $before . get_the_title() . $after;
                    }
                } else {
                    $cat = get_the_category();
                    $cat = isset( $cat[0] ) ? $cat[0] : $cat;

                    $cats = get_category_parents( $cat, true, $delimiter );

                    if ( $show_current == 0 || get_query_var( 'cpage' ) ) {
                        $cats = preg_replace( "#^(.+)$delimiter$#", "$1", $cats );
                    }

                    $cats = preg_replace( '#<a([^>]+)>([^<]+)<\/a>#', $link_before . '<a$1' . $link_attr . '>' . $link_in_before . '$2' . $link_in_after . '</a>' . $link_after, $cats );

                    if ( $show_title == 0 ) {
                        $cats = preg_replace( '/ title="(.*?)"/', '', $cats );
                    }

                    echo $cats;

                    if ( get_query_var( 'cpage' ) ) {
                        echo $delimiter . sprintf( $link, get_permalink(), get_the_title() ) . $delimiter . $before . sprintf( $text['cpage'], get_query_var( 'cpage' ) ) . $after;
                    } else {
                        if ( $show_current == 1 ) {
                            echo $before . get_the_title() . $after;
                        }
                    }
                }

            // custom post type
            } elseif ( ! is_single() && ! is_page() && get_post_type() != 'post' && ! is_404() ) {
                $post_type = get_post_type_object( get_post_type() );

                if ( get_query_var( 'paged' ) ) {
                    if ( $post_type->name == 'product' ) {
                        echo $delimiter . $before . sprintf( $text['page'], get_query_var( 'paged' ) ) . $after;
                    } else {
                        echo $delimiter . sprintf( $link, get_post_type_archive_link( $post_type->name ), $post_type->label ) . $delimiter . $before . sprintf( $text['page'], get_query_var( 'paged' ) ) . $after;
                    }
                } else {
                    if ( $show_current == 1 ) {
                        echo $delimiter . $before . $post_type->label . $after;
                    }
                }

            } elseif ( is_attachment() ) {
                if ( $show_home_link == 1 ) {
                    echo $delimiter;
                }

                $parent = get_post( $parent_id );

                $cat = get_the_category( $parent->ID );
                $cat = isset( $cat[0] ) ? $cat[0] : $cat;

                if ( $cat ) {
                    $cats = get_category_parents( $cat, true, $delimiter );
                    $cats = preg_replace( '#<a([^>]+)>([^<]+)<\/a>#', $link_before . '<a$1' . $link_attr . '>' . $link_in_before . '$2' . $link_in_after .'</a>' . $link_after, $cats );

                    if ( $show_title == 0) {
                        $cats = preg_replace( '/ title="(.*?)"/', '', $cats );
                    }

                    echo $cats;
                }

                printf( $link, get_permalink( $parent ), $parent->post_title );

                if ( $show_current == 1 ) {
                    echo $delimiter . $before . get_the_title() . $after;
                }
            } elseif ( is_page() && ! $parent_id ) {
                if ( $show_current == 1 ) {
                    echo $delimiter . $before . get_the_title() . $after;
                }
            } elseif ( is_page() && $parent_id ) {
                if ( $show_home_link == 1 ) {
                    echo $delimiter;
                }

                if ( $parent_id != $frontpage_id ) {
                    $breadcrumbs = array();

                    while ( $parent_id ) {
                        $page = get_page( $parent_id );

                        if ( $parent_id != $frontpage_id ) {
                            $breadcrumbs[] = sprintf( $link, get_permalink( $page->ID ), get_the_title( $page->ID ) );
                        }

                        $parent_id = $page->post_parent;
                    }

                    $breadcrumbs = array_reverse( $breadcrumbs );

                    for ( $i = 0; $i < count( $breadcrumbs ); $i++ ) {
                        echo $breadcrumbs[$i];

                        if ( $i != count( $breadcrumbs ) - 1 ) {
                            echo $delimiter;
                        }
                    }
                }

                if ( $show_current == 1 ) {
                    echo $delimiter . $before . get_the_title() . $after;
                }
            } elseif ( is_tag() ) {
                if ( $show_current == 1 ) {
                    echo $delimiter . $before . sprintf( $text['tag'], single_tag_title( '', false ) ) . $after;
                }
            } elseif ( is_author() ) {
                if ( $show_home_link == 1 ) {
                    echo $delimiter;
                }

                global $author;

                $author = get_userdata( $author );

                echo $before . sprintf( $text['author'], $author->display_name ) . $after;

            } elseif ( is_404() ) {
                if ( $show_home_link == 1 ) {
                    echo $delimiter;
                }

                echo $before . $text['404'] . $after;
            } elseif ( has_post_format() && ! is_singular() ) {
                if ( $show_home_link == 1 ) {
                    echo $delimiter;
                }

                echo get_post_format_string( get_post_format() );
            }

            echo '</div>';
        }

        return ob_get_clean();
    }
}

add_shortcode( 'vu_breadcrumb', 'bakery_breadcrumb_shortcode' );
