<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * Carousel Item Shortcode
 *
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 */

if ( ! function_exists( 'bakery_carousel_item_shortcode' ) ) {
	function bakery_carousel_item_shortcode( $atts = null, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			"class" => '',
			"css" => '',
		), $atts, 'vu_carousel_item' );

		if ( function_exists( 'vc_shortcode_custom_css_class' ) ) {
			$custom_css_class = vc_shortcode_custom_css_class( $atts['css'] );
		}

		ob_start(); ?>
		<div class="vu_carousel-item<?php bakery_extra_class( $atts['class'] ); ?>">
			<?php 
				if ( isset( $custom_css_class ) && ! empty( $custom_css_class ) ) {
					echo '<div class="' . esc_attr( $custom_css_class ) . '">' . do_shortcode( $content ) . '</div>';
				} else {
					echo do_shortcode( $content );
				}
			?>
		</div>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_carousel_item', 'bakery_carousel_item_shortcode' );

/**
 * Carousel Item VC Shortcode
 */

 if ( ! class_exists( 'WPBakeryShortCode_vu_carousel_item' ) && class_exists( 'WPBakeryShortCodesContainer' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_carousel_item extends WPBakeryShortCodesContainer {}

	vc_map(
		array(
			'name' => esc_html__( 'Carousel Item', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Add carousel item', 'bakery-shortcodes' ),
			'base' => 'vu_carousel_item',
			'class' => 'vc_vu_carousel_item',
			'icon' => 'vu_element-icon vu_carousel-item-icon',
			'controls' => 'full',
			'as_child' => array( 'only' => 'vu_carousel' ),
			'js_view' => 'VcColumnView',
			'content_element' => true,
			'is_container' => true,
			'container_not_allowed' => false,
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'default_content' => '',
			'params'	=> array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Design Options', 'bakery-shortcodes' ),
					'type' => 'css_editor',
					'heading' => esc_html__( 'CSS box', 'bakery-shortcodes' ),
					'param_name' => 'css'
				)
			)
		)
	);
}
