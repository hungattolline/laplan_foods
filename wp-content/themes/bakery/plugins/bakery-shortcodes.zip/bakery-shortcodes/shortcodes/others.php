<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * Others Shortcodes
 */

/**
 * Embed Shortcode
 *
 * @param string $src Youtube video embed URL. eg: https://www.youtube.com/embed/{video_id} or https://player.vimeo.com/video/{video_id}
 * @param string $ratio Video ratio that will properly scale on any device. eg: '16by9' or '4by3'. Default: '16by9'
 */

if ( ! function_exists( 'bakery_embed_shortcode' ) ) {
	function bakery_embed_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'src' => '',
			'ratio' => '16by9'
		), $atts, 'vu_embed' );

		return '<div class="embed-responsive embed-responsive-' . esc_attr( $atts['ratio'] ) . '"><iframe class="embed-responsive-item" src="' . esc_url( $atts['src'] ) . '"></iframe></div>';
	}
}

add_shortcode( 'vu_embed', 'bakery_embed_shortcode' );

/**
 * Custom Menu Shortcode
 *
 * @param $atts['menu']
 * @param $atts['container']
 * @param $atts['container_id']
 * @param $atts['container_class']
 * @param $atts['menu_id']
 * @param $atts['menu_class']
 */

if ( ! function_exists( 'bakery_custom_menu_shortcode' ) ) {
	function bakery_custom_menu_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'menu' => '',
			'container' => 'nav',
			'container_id' => '',
			'container_class' => 'vu_custom-menu-container',
			'menu_id' => '',
			'menu_class' => 'vu_custom-menu-list'
		), $atts, 'vu_custom_menu' );

		if ( empty( $atts['menu'] ) ) {
			return '';
		}

		ob_start();

		wp_nav_menu( array(
			'menu' => $atts['menu'],
			'container' => $atts['container'],
			'container_id' => $atts['container_id'],
			'container_class' => $atts['container_class'],
			'menu_id' => $atts['menu_id'],
			'menu_class' => trim( $atts['menu_class'] . ' list-unstyled' )
		) );

		return ob_get_clean();
	}
}

add_shortcode( 'vu_custom_menu', 'bakery_custom_menu_shortcode' );

/**
 * Serach Form Shortcode
 *
 * @param $atts['placeholder']
 * @param $atts['scope']
 * @param $atts['class']
 */

if ( ! function_exists( 'bakery_search_form_shortcode' ) ) {
	function bakery_search_form_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'placeholder' => esc_html__( 'Type and hit enter', 'bakery' ),
			'scope' => 'all',
			'class' => ''
		), $atts, 'vu_search_form' );

		ob_start(); ?>
		<form method="get" class="vu_search-form search-form<?php echo ! empty( $atts['class'] ) ? ' ' . esc_attr( $atts['class'] ) : ''; ?>" action="<?php echo esc_url( home_url('/') ); ?>" role="search" aria-label="Sitewide">
			<div class="vu_sf-wrapper">
				<input type="search" class="vu_sf-input form-control" placeholder="<?php echo esc_attr( $atts['placeholder'] ); ?>" name="s" value="<?php echo esc_attr( get_search_query() ); ?>"/>

				<?php if ( ! empty( $atts['scope'] ) && $atts['scope'] != 'all' ) : ?>
					<input type="hidden" name="post_type" value="<?php echo esc_attr( $atts['scope'] ); ?>">
				<?php endif; ?>

				<button type="submit" class="vu_sf-submit search-submit"><i class="fa fa-search" aria-hidden="true"></i></button>
			</div>
		</form>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_search_form', 'bakery_search_form_shortcode' );

/**
 * Recent Posts Shortcode
 *
 * @param int $atts['numberposts'] The number of posts being displayed. Default: '2'
 * @see https://codex.wordpress.org/Function_Reference/wp_get_recent_posts
 */

if ( ! function_exists( 'bakery_recent_posts_shortcode' ) ) {
	function bakery_recent_posts_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'number_of_posts' => 3,
			'show_author' => '1',
			'author_text' => esc_html__( 'Posted by', 'bakery-shortcodes' ),
			'show_date' => '1',
			'date_format' => 'd M Y',
			'class' => '',
		), $atts, 'vu_recent_posts' );

		$recent_posts = new WP_Query( 'orderby=date&order=DESC&posts_per_page=' . absint( $atts['number_of_posts'] ) ); 
		
		ob_start(); ?>
		<div class="vu_recent-posts clearfix<?php echo ! empty( $atts['class'] ) ? ' ' . esc_attr( $atts['class'] ) : ''; ?>">
			<?php if ( $recent_posts->have_posts() ) :
				while ( $recent_posts->have_posts() ) : $recent_posts->the_post(); ?>
					<article class="vu_rp-item" data-id="<?php the_ID(); ?>">
						<?php if ( has_post_thumbnail( get_the_ID() ) ) : ?>
							<div class="vu_rp-img">
								<a href="<?php the_permalink(); ?>" title="<?php echo esc_attr( get_the_title() ); ?>">
									<?php the_post_thumbnail( 'thumbnail' ); ?>
								</a>
							</div>
						<?php endif; ?>

						<h4 class="vu_rp-title"><a href="<?php the_permalink(); ?>" title="<?php echo esc_attr( get_the_title() ); ?>"><?php the_title(); ?></a></h4>

						<?php if ( $atts['show_author'] == '1' ) : ?>
							<div class="vu_rp-author"><?php echo esc_html( $atts['author_text'] ) . ' ' . get_the_author(); ?></div>
						<?php endif; ?>

						<?php if ( $atts['show_date'] == '1' ) : ?>
							<div class="vu_rp-date"><time><?php echo get_the_date( $atts['date_format'] ); ?></time></div>
						<?php endif; ?>
					</article>
				<?php endwhile;
			endif;
			wp_reset_query(); ?>
		</div>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_recent_posts', 'bakery_recent_posts_shortcode' );

/**
 * Social Network Shortcode
 *
 * @param string $atts['url'] The url of social network. Default: '#'
 * @param string $atts['target'] The target of link. Default: '_self'
 * @param string $atts['icon'] The icon of social network. Please get it from Font Awesome Icons. eg: 'fa fa-facebook'
 */

if ( ! function_exists( 'bakery_social_network_shortcode' ) ) {
	function bakery_social_network_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'url' => '#',
			'target' => '_self',
			'rel' => 'nofollow',
			'icon' => ''
		), $atts, 'vu_social_network' );

		return '<div class="vu_social-icon"><a href="' . esc_url( $atts['url'] ) . '" target="' . esc_attr( $atts['target'] ) . '" rel="' . esc_attr( $atts['rel'] ) . '"><i class="' . esc_attr( $atts['icon'] ) . '"></i></a></div>';
	}
}

add_shortcode( 'vu_social_network', 'bakery_social_network_shortcode' );

/**
 * Highlight Shortcode
 *
 * @param string $atts['bg_color']
 * @param string $atts['text_color']
 * @param string $atts['class']
 */

if ( ! function_exists( 'bakery_social_network_shortcode' ) ) {
	function bakery_highlight_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'bg_color' => '',
			'text_color' => '',
			'class' => ''
		), $atts, 'vu_highlight' );

		$style_attribute = '';

		if ( ! empty( $atts['bg_color'] ) && ! empty( $atts['text_color'] ) ) {
			$style_attribute .= ' style="';

			if ( ! empty( $atts['bg_color'] ) ) {
				$style_attribute .= 'background-color:' . esc_attr( $atts['bg_color'] ) . ';';
			}

			if ( ! empty( $atts['text_color'] ) ) {
				$style_attribute .= 'color:' . esc_attr( $atts['text_color'] ) . ';';
			}

			$style_attribute .= '"';
		}

		return '<span class="vu_highlight' . bakery_extra_class( $atts['class'] ) . '"' . $style_attribute . '>' . $content . '</span>';
	}
}

add_shortcode('vu_highlight', 'bakery_highlight_shortcode');

/**
 * Info Item Shortcode
 *
 * @param string $atts['icon']
 * @param string $atts['title']
 * @param string $atts['desc']
 * @param string $atts['style']
 * @param string $atts['class']
 */

if ( ! function_exists( 'bakery_info_item_shortcode' ) ) {
	function bakery_info_item_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'icon' => '',
			'title' => '',
			'desc' => '',
			'style' => '1',
			'class' => ''
		), $atts, 'vu_info_item' );

		ob_start(); ?>
		<div class="vu_info-item vu_ii-style-<?php echo esc_attr( $atts['style'] ); ?><?php bakery_extra_class( $atts['class'] ); ?>">
			<?php if ( $atts['style'] == '1' || $atts['style'] == '3' ) : ?>
				<div class="vu_ii-icon">
					<i class="<?php echo esc_attr( $atts['icon'] ); ?>"></i>
				</div>
				<div class="vu_ii-details">
					<span class="vu_ii-title"><?php echo esc_html( $atts['title'] ); ?></span>
					<p class="vu_ii-desc"><?php echo esc_html( $atts['desc'] ); ?></p>
				</div>
			<?php else : ?>
				<div class="vu_ii-details">
					<span class="vu_ii-title"><i class="<?php echo esc_attr( $atts['icon'] ); ?>"></i><?php echo esc_html( $atts['title'] ); ?></span>
					<p class="vu_ii-desc"><?php echo esc_html( $atts['desc'] ); ?></p>
				</div>
			<?php endif; ?>
		</div>

		<?php return ob_get_clean();
	}
}

add_shortcode('vu_info_item', 'bakery_info_item_shortcode');

/**
 * Flickr Shortcode
 *
 * @param string $atts['user'] The username of flickr account. eg: 38583880@N00
 * @param string $atts['limit'] The number of images that will be shown. Default: '6'
 */

if ( ! function_exists( 'bakery_flickr_shortcode' ) ) {
	function bakery_flickr_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'user' => '',
			'limit' => 8
		), $atts, 'vu_flickr' );

		wp_enqueue_script( array('flickr-feed') );

		return '<div class="vu_flickr-photos vu_lightbox vu_l-gallery clearfix" data-user="' . esc_attr( $atts['user'] ) . '" data-limit="' . absint( $atts['limit'] ) . '"></div>';
	}
}

add_shortcode('vu_flickr', 'bakery_flickr_shortcode');

/**
 * Latest Tweets Shortcode
 *
 * @param string $atts['user'] The username of twitter account.
 * @param string $atts['count'] The number of tweets that will be shown. Default: '3'
 * @param string $atts['loading_text'] The text that will be shown before loading tweets. Default: 'Loading tweets...'
 */

if ( ! function_exists( 'bakery_latest_tweets_shortcode' ) ) {
	function bakery_latest_tweets_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'user' => '',
			'count' => 3,
			'loading_text' => esc_html__( 'Loading tweets', 'bakery-shortcodes' )
		), $atts, 'vu_latest_tweets' );

		$carousel_options = array(
			"singleItem" => false,
			"items" => 1,
			"navigation" => false,
			"navigationText" => array( '<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>' ),
			"pagination" => true,
			"autoHeight" => true,
			"rewindNav" => true,
			"scrollPerPage" => true,
			"autoPlay" => false,
			"stopOnHover" => false
		);

		return '<div class="vu_latest-tweets clearfix" data-options="' . esc_attr( json_encode( $carousel_options ) ) . '" data-user="' . esc_attr( $atts['user'] ) . '" data-count="' . absint( $atts['count'] ) . '" data-text="' . esc_attr( $atts['loading_text'] ) . '" data-action="vu_latest_tweets"></div>';
	}
}

add_shortcode('vu_latest_tweets', 'bakery_latest_tweets_shortcode');

/**
 * Latest Tweets Shortcode
 */

if ( ! function_exists( 'bakery_latest_tweets_ajax' ) ) {
	function bakery_latest_tweets_ajax() {
		if ( ! empty( $_POST['request'] ) ) {
			$consumer_key = esc_attr( bakery_get_option('twitter-consumer-key' ) );
			$consumer_secret = esc_attr( bakery_get_option('twitter-consumer-secret' ) );
			$user_token = esc_attr( bakery_get_option('twitter-user-token' ) );
			$user_secret = esc_attr( bakery_get_option('twitter-user-secret' ) );

			$ezTweet = new ezTweet( $consumer_key, $consumer_secret, $user_token, $user_secret, $_POST['request'] );
			$ezTweet->fetch();
		}

		exit();
	}
}

add_action("wp_ajax_vu_latest_tweets", "bakery_latest_tweets_ajax");
add_action("wp_ajax_nopriv_vu_latest_tweets", "bakery_latest_tweets_ajax");

/**
 * Google Plus Badge Shortcode
 *
 * @param string $atts['page_id'] The page Id of google plus account. eg: '106192958286631454676'
 * @param int $atts['width'] Width of the google plus badge. Default: '300'
 */

if ( ! function_exists( 'bakery_google_plus_badge_shortcode' ) ) {
	function bakery_google_plus_badge_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'page_id' => '',
			'width' => '300'
		), $atts, 'vu_google_plus_badge' );

		wp_enqueue_script( array( 'google-apis' ) );

		return '<div class="vu_google-plus-badge-container clearfix"><div class="g-page" data-width="' . esc_attr( $atts['width'] ) . '" data-href="https://plus.google.com/' . esc_attr( $atts['page_id'] ) . '" data-layout="landscape" data-rel="publisher"></div></div>';
	}
}

add_shortcode('vu_google_plus_badge', 'bakery_google_plus_badge_shortcode');

/**
 * Facebook Like Box Shortcode
 *
 * @param string $atts['url'] The url of facebook account. eg: http://facebook.com/psdtuts
 * @param int $atts['width'] Width of the box.
 * @param int $atts['height'] Height of the box. Default: '300'
 * @param int $atts['colorscheme'] Color Scheme of the box. eg: 'light' or 'dark'. Default: 'light'
 * @param int $atts['show_face'] Show face of people who like your page. Default: 'true'
 * @param int $atts['show_border'] Show border of the box. Default: 'true'
 * @param int $atts['show_stream'] Show stream of the fun page. Default: 'false'
 * @param int $atts['show_header'] Show header of the box. Default: 'false'
 */

if ( ! function_exists( 'bakery_facebook_like_box_shortcode' ) ) {
	function bakery_facebook_like_box_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'url' => '',
			'width' => '',
			'height' => '300',
			'colorscheme' => 'light',
			'show_face' => 'true',
			'show_border' => 'true',
			'show_stream' => 'false',
			'show_header' => 'false'
		), $atts, 'vu_facebook_like_box' );

		return '<div class="vu_fb-like-box-container clearfix" data-href="' . esc_url( $atts['url'] ) . '" data-width="' . esc_attr( $atts['width'] ) . '" data-height="' . esc_attr( $atts['height'] ) . '" data-colorscheme="' . esc_attr( $atts['colorscheme'] ) . '" data-show-faces="' . esc_attr( $atts['show_face'] ) . '" data-show-border="' . esc_attr( $atts['show_border'] ) . '" data-stream="' . esc_attr( $atts['show_stream'] ) . '" data-header="' . esc_attr( $atts['show_header'] ) . '"></div>';
	}
}

add_shortcode( 'vu_facebook_like_box', 'bakery_facebook_like_box_shortcode' );

/**
 * Gallery Widget Shortcode
 *
 * @param $atts['images']
 * @param $atts['lightbox']
 * @param $atts['class']
 */

if ( ! function_exists( 'bakery_gallery_widget_shortcode' ) ) {
	function bakery_gallery_widget_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			"images" => '',
			"lightbox" => '1',
			"class" => ''
		), $atts, 'vu_gallery_widget' );

		$images = @explode( ',', $atts['images'] );

		ob_start(); ?>
		<div class="vu_gallery-widget<?php echo ( $atts['lightbox'] == '1' ) ? ' vu_lightbox vu_l-gallery' : ''; ?><?php bakery_extra_class( $atts['class'] ); ?>"<?php echo ( $atts['lightbox'] == '1' ) ? ' data-delegate="a.vu_gw-image"' : ''; ?>>
			<?php if ( is_array( $images ) && ! empty( $images ) ) : ?>
				<?php foreach ( $images as $image ) { ?>
					<div class="vu_gw-item">
						<?php if ( $atts['lightbox'] == '1' ) : ?>
							<a href="<?php echo bakery_get_attachment_image_src( absint( $image ), 'full' ); ?>" class="vu_gw-image">
						<?php else : ?>
							<span class="vu_gw-image">
						<?php endif; ?>

						<?php echo wp_get_attachment_image( absint( $image ), 'thumbnail' ); ?>

						<?php if ( $atts['lightbox'] == '1' ) : ?>
							</a>
						<?php else : ?>
							</span>
						<?php endif; ?>
					</div>
				<?php } ?>
			<?php endif; ?>
		</div>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_gallery_widget', 'bakery_gallery_widget_shortcode' );

/**
 * Font Awesome Icons Shortcode
 *
 * @link https://wordpress.org/plugins/font-awesome-shortcodes/
 */

if ( ! function_exists( 'bakery_font_awesome_shortcode' ) ) {
	function bakery_font_awesome_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			"type" => '',
			"size" => false,
			"pull" => false,
			"border" => false,
			"spin" => false,
			"list_item" => false,
			"fixed_width" => false,
			"rotate" => false,
			"flip" => false,
			"stack_size" => false,
			"inverse" => false,
			"xclass" => false
		), $atts, 'vu_fa' );

		$class  = 'fa';
		$class .= ( $atts['type'] ) ? 'fa-' . $atts['type'] : '';
		$class .= ( $atts['size'] ) ? 'fa-' . $atts['size'] : '';
		$class .= ( $atts['pull'] ) ? ' pull-' . $atts['pull'] : '';
		$class .= ( $atts['border'] ) ? 'fa-border' : '';
		$class .= ( $atts['spin'] ) ? 'fa-spin' : '';
		$class .= ( $atts['list_item'] ) ? 'fa-li' : '';
		$class .= ( $atts['fixed_width'] ) ? 'fa-fw' : '';
		$class .= ( $atts['rotate'] ) ? 'fa-rotate-' . $atts['rotate'] : '';
		$class .= ( $atts['flip'] ) ? 'fa-flip-' . $atts['flip'] : '';
		$class .= ( $atts['stack_size'] ) ? 'fa-stack-' . $atts['stack_size'] : '';
		$class .= ( $atts['inverse'] ) ? 'fa-inverse' : '';
		$class .= ( $atts['xclass'] ) ? $atts['xclass'] : '';
			
		return sprintf( '<i class="%s"></i>', esc_attr( trim( $class ) ) );
	}
}

add_shortcode( 'vu_fa', 'bakery_font_awesome_shortcode' );
