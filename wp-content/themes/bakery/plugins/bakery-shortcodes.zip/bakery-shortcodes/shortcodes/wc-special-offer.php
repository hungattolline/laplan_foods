<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * WC Special Offer Shortcode
 *
 * @param string $atts['scheme_color']
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 */

if ( ! function_exists( 'bakery_wc_special_offer_item_shortcode' ) ) {
	function bakery_wc_special_offer_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			"scheme_color" => '',
			"class" => ''
		), $atts, 'vu_wc_special_offer' );

		$wc_special_offer_items = array();

		$content = strip_tags( str_replace( '[vc_container_anchor]', '', $content ) );

		$explode = explode( '[vu_wc_special_offer_item', $content );

		foreach ( $explode as $key => $value ) {
			if ( ! empty( $value ) ) {
				preg_match_all( '/((?:(?!\s|=).)*)\s*?=\s*?["\']?((?:(?<=")(?:(?<=\\\\)"|[^"])*|(?<=\')(?:(?<=\\\\)\'|[^\'])*)|(?:(?!"|\')(?:(?!\/>|>|\s).)+))/', '[vu_wc_special_offer_item' . $value, $atts_matches, PREG_SET_ORDER );

				$_atts = array( '_id' => rand( 10000, 99999 ) );

				foreach ( $atts_matches as $a ) {
					$_atts[ $a[1] ] = $a[2];
				}

				$_atts = bakery_prepare_atts( $_atts );
				
				array_push( $wc_special_offer_items, $_atts );
			}
		}

		ob_start(); ?>
		<div class="vu_special-offer vu_wc-special-offer vu_so-scheme-<?php echo esc_attr( $atts['scheme_color'] ); ?> clearfix<?php bakery_extra_class( $atts['class'] ); ?>">
			<div class="vu_so-tabs">
				<?php $num = 1; ?>
				<?php foreach ( $wc_special_offer_items as $wc_special_offer_item ) : ?>
					<div class="vu_so-tab<?php echo ( $num == 1) ? ' active' : ''; ?>" data-id="<?php echo esc_attr( $wc_special_offer_item['_id'] ); ?>">
						<?php echo wp_get_attachment_image( get_post_thumbnail_id( $wc_special_offer_item['product'] ), 'thumbnail' ); ?>
					</div>
					<?php $num++; ?>
				<?php endforeach; ?>
			</div>

			<div class="vu_so-panes clearfix">
				<?php $num = 1; ?>
				<?php foreach ( $wc_special_offer_items as $wc_special_offer_item ) : ?>
					<?php 
						$product = wc_setup_product_data( absint( $wc_special_offer_item['product'] ) );
						if ( empty( $product ) ) { continue; }
					?>
					<div class="vu_so-pane<?php echo ( $num == 1) ? ' active' : ''; ?>" data-id="<?php echo esc_attr( $wc_special_offer_item['_id'] ); ?>">
						<div class="vu_so-pane-left">
							<?php if ( $wc_special_offer_item['show_name'] == '1' ) : ?>
								<div class="vu_so-item-header">
									<h3 class="vu_so-item-name"><?php echo $product->get_title(); ?></h3>
								</div>
							<?php endif; ?>

							<?php if ( ! empty( $wc_special_offer_item['show_content'] ) ) : ?>
								<div class="vu_so-item-content">
									<?php echo wpautop( $product->get_description() ); ?>
								</div>
							<?php endif; ?>

							<?php if ( $wc_special_offer_item['show_price'] == '1' || $wc_special_offer_item['show_button'] == '1' ) : ?>
								<div class="vu_so-item-footer">
									<?php if ( $wc_special_offer_item['show_price'] == '1' ) : ?>
										<div class="vu_so-item-price">
											<span><?php echo esc_html( get_woocommerce_currency_symbol() ); ?></span>
											<span><?php echo bakery_wc_product_format_price( $product->get_price() ); ?></span>
										</div>
									<?php endif; ?>

									<?php if ( $wc_special_offer_item['show_button'] && ! empty( $wc_special_offer_item['button_text'] ) ) : ?>
										<div class="vu_so-item-btn">
											<?php if ( $wc_special_offer_item['button_type'] == 'product_link' ) : ?>
												<a href="<?php echo esc_url( $product->get_permalink() ); ?>" class="btn <?php echo ( $atts['scheme_color'] != "dark") ? 'btn-primary' : 'btn-white'; ?> btn-inverse btn-icon">
													<span><?php echo esc_html( $wc_special_offer_item['button_text'] ); ?></span>
													<i class="fa fa-long-arrow-right"></i>
												</a>
											<?php elseif ( $wc_special_offer_item['button_type'] == 'add_to_cart' && function_exists( 'bakery_wc_ywctm_check_hide_add_cart_loop' ) && !bakery_wc_ywctm_check_hide_add_cart_loop() ) : ?>
												<?php woocommerce_template_loop_add_to_cart( array( 'class' => 'btn btn-primary btn-inverse btn-icon' . implode( ' ', array_filter( array( 'button', 'product_type_' . $product->get_type(), $product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '', $product->supports( 'ajax_add_to_cart' ) ? 'ajax_add_to_cart' : '' ) ) ), 'text' => '<span>' . esc_html( $wc_special_offer_item['button_text'] ) . '</span><i class="fa fa-shopping-cart"></i><i class="fa fa-check"></i><i class="fa fa-list-alt"></i><i class="fa fa-spinner fa-spin"></i>' ) ); ?>
											<?php else : ?>
												<?php $button_link = ( function_exists( 'vc_build_link' ) ) ? vc_build_link( $wc_special_offer_item['button_link'] ) : array( 'url' => '', 'title' => '', 'target' => '' ); ?>

												<?php if ( strlen( $wc_special_offer_item['button_link'] ) > 0 && strlen( $button_link['url'] ) > 0 ) : ?>
													<a href="<?php echo esc_url( $button_link['url'] ); ?>" target="<?php echo ( strlen( $button_link['target'] ) > 0) ? esc_attr( $button_link['target'] ) : '_self'; ?>" class="btn <?php echo ( $atts['scheme_color'] != "dark") ? 'btn-primary' : 'btn-white'; ?> btn-inverse btn-icon">
														<span><?php echo esc_html( $wc_special_offer_item['button_text'] ); ?></span>
														<i class="fa fa-long-arrow-right"></i>
													</a>
												<?php endif; ?>
											<?php endif; ?>
										</div>
									<?php endif; ?>
								</div>
							<?php endif; ?>
						</div>

						<?php if ( ! empty( $wc_special_offer_item['label'] ) || has_post_thumbnail( $product->get_id() ) ) : ?>
							<div class="vu_so-pane-right">
								<?php if ( ! empty( $wc_special_offer_item['label'] ) ) : ?>
									<div class="vu_so-item-label">
										<span><?php echo esc_html( $wc_special_offer_item['label'] ); ?></span>
									</div>
								<?php endif; ?>

								<?php if ( has_post_thumbnail( $product->get_id() ) ) : ?>
									<div class="vu_so-item-image vu_lazy-load" data-img="<?php echo bakery_get_attachment_image_src( get_post_thumbnail_id( $wc_special_offer_item['product'] ), 'full' ); ?>">
										<?php echo wp_get_attachment_image( get_post_thumbnail_id( $wc_special_offer_item['product'] ), 'bakery_ratio-1:1', false ); ?>
									</div>
								<?php endif; ?>
							</div>
						<?php endif; ?>
					</div>
					<?php $num++; ?>
				<?php endforeach; ?>
			</div>
		</div>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_wc_special_offer', 'bakery_wc_special_offer_shortcode' );

/**
 * WC Special Offer VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_wc_special_offer' ) && class_exists( 'WPBakeryShortCodesContainer' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_wc_special_offer extends WPBakeryShortCodesContainer {}

	vc_map(
		array(
			'name' => esc_html__( 'WC Special Offer', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Make specific items featured', 'bakery-shortcodes' ),
			'base' => 'vu_wc_special_offer',
			'class' => 'vc_vu_wc-special-offer',
			'icon' => 'vu_element-icon vu_wc-special-offer-icon',
			'controls' => 'full',
			'as_parent' => array( 'only' => 'vu_wc_special_offer_item' ),
			'js_view' => 'VcColumnView',
			'content_element' => true,
			'is_container' => true,
			'container_not_allowed' => false,
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'default_content' => '[vu_wc_special_offer_item]',
			'params'	=> array(
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Scheme Color', 'bakery-shortcodes' ),
					'param_name' => 'scheme_color',
					'value' => array(
						esc_html__( 'Light', 'bakery-shortcodes' ) => 'light',
						esc_html__( 'Dark', 'bakery-shortcodes' ) => 'dark'
					),
					'std' => 'light',
					'save_always' => true,
					'description' => esc_html__( 'Select special offer scheme color.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				)
			)
		)
	);
}
