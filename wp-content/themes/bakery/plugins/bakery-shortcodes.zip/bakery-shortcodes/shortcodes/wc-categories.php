<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * WC Categories Shortcode
 *
 * @param string $atts['categories']
 * @param string $atts['orderby']
 * @param string $atts['order']
 * @param string $atts['type']
 * @param string $atts['layout']
 * @param string $atts['show_counts']
 * @param string $atts['c_show_navigation']
 * @param string $atts['c_show_pagination']
 * @param string $atts['c_autoplay']
 * @param string $atts['c_stop_on_hover']
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 * @param string $atts['css']
 */

if ( ! function_exists( 'bakery_wc_categories_shortcode' ) ) {
	function bakery_wc_categories_shortcode( $atts = null, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'categories' => '',
			'orderby' => '',
			'order' => '',
			'type' => '',
			'layout' => '',
			'show_counts' => '',
			'class' => '',
			'c_show_navigation' => '',
			'c_show_pagination' => '',
			'c_autoplay' => '',
			'c_stop_on_hover' => '',
			'css' => ''
		), $atts, 'vu_wc_categories' );

		if ( function_exists( 'vc_shortcode_custom_css_class' ) ) {
			$atts['class'] .= ' ' . vc_shortcode_custom_css_class( $atts['css'] );
		}

		$atts['class'] = trim( $atts['class'] );

		$args = array(
			'taxonomy' => 'product_cat',
			'hide_empty' => true,
			'orderby' => $atts['orderby'],
			'order' => $atts['order'],
			'fields' => 'all',
			'hierarchical' => false
		);

		if ( ! empty( $atts['categories'] ) ) {
			$args['include'] = explode( ',', $atts['categories'] );
		}

		$wc_categories = get_terms( $args );

		ob_start(); ?>
		<div class="vu_wc-categories vu_c-type-<?php echo esc_attr( $atts['type'] ); ?> vu_c-layout-<?php echo esc_attr( $atts['layout'] ); ?> clearfix<?php bakery_extra_class( $atts['class'] ); ?>">
			<?php if ( $atts['type'] == 'carousel' ) : 
				$carousel_options = array(
					"singleItem" => false,
					"items" => absint( $atts['layout'] ),
					"itemsDesktop" => array(1199, absint( $atts['layout'] ) ),
					"itemsDesktopSmall" => array(980, 2),
					"itemsTablet" => array(768, 2),
					"itemsMobile" => array(479, 1),
					"navigation" => ( $atts['c_show_navigation'] == '1' ) ? true : false,
					"navigationText" => array( '<i class="fa fa-arrow-left" aria-hidden="true"></i>', '<i class="fa fa-arrow-right" aria-hidden="true"></i>' ),
					"pagination" => ( $atts['c_show_pagination'] == '1' ) ? true : false,
					"autoHeight" => true,
					"rewindNav" => true,
					"scrollPerPage" => true,
					"autoPlay" => ( $atts['c_autoplay'] == '' || $atts['c_autoplay'] == '0' ) ? false : absint( $atts['c_autoplay'] ),
					"stopOnHover" => ( $atts['c_stop_on_hover'] == '1' ) ? true : false
				);
			?>
				<div class="vu_c-carousel vu_carousel" data-options="<?php echo esc_attr( json_encode( $carousel_options ) ); ?>">
			<?php else : ?>
				<div class="row">
			<?php endif; ?>
				<?php if ( $wc_categories && ! is_wp_error( $wc_categories ) ) :
					foreach ( $wc_categories as $wc_category ) : ?>
					<?php if ( $atts['type'] != 'carousel' ) : ?>
						<div class="vu_c-item-container col-md-<?php echo ( 12 / absint( $atts['layout'] ) ); ?> col-sm-6 col-xs-12">
					<?php endif; ?>
						<div class="vu_wc-category<?php echo bakery_extra_class( $atts['class'] ); ?>">
							<a href="<?php echo get_term_link( $wc_category ); ?>">
								<section class="vu_c-container">
									<?php $thumbnail_id = get_term_meta( $wc_category->term_id, 'thumbnail_id', true ); ?>
									<div class="vu_c-image vu_lazy-load" data-img="<?php echo bakery_get_attachment_image_src( $thumbnail_id, 'full' ); ?>">
										<?php 
											echo wp_get_attachment_image( $thumbnail_id, 'bakery_ratio-1:1' );
										?>
									</div>

									<div class="vu_c-content">
										<h3 class="vu_c-name"><?php echo $wc_category->name ?></h3>
										<?php if ( $atts['show_counts'] == '1' ) : ?>
											<mark class="vu_c-count">(<?php echo $wc_category->count ?>)</mark>
										<?php endif; ?>
									</div>
								</section>
							</a>
						</div>
					<?php if ( $atts['type'] != 'carousel' ) : ?>
						</div>
					<?php endif; ?>
				<?php endforeach; endif; ?>
			</div>
		</div>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_wc_categories', 'bakery_wc_categories_shortcode' );

/**
 * WC Categories VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_wc_categories' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_wc_categories extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_wc_categories', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_wc_categories', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'WC Categories', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Add WC categories', 'bakery-shortcodes' ),
			'base' => 'vu_wc_categories',
			'icon' => 'vu_wc-categories-icon',
			'controls' => 'full',
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'select2',
					'heading' => esc_html__( 'Categories', 'bakery-shortcodes' ),
					'param_name' => 'categories',
					'admin_label' => true,
					'options' => array(
						'source' => admin_url( 'admin-ajax.php?action=bakery_get_wc_categories' ),
						'tags' => true,
						'multiple' => true,
						'sortable' => true
					),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select product categories. If empty all product categories will be shown.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'dropdown',
					'heading' => esc_html__( 'Order By', 'bakery-shortcodes' ),
					'param_name' => 'orderby',
					'admin_label' => true,
					'value' =>  array(
						esc_html__( 'None', 'bakery-shortcodes' ) => 'none',
						esc_html__( 'ID', 'bakery-shortcodes' ) => 'ID',
						esc_html__( 'Name', 'bakery-shortcodes' ) => 'name',
						esc_html__( 'Slug', 'bakery-shortcodes' ) => 'slug',
						esc_html__( 'Count', 'bakery-shortcodes' ) => 'count'
					),
					'std' => 'none',
					'save_always' => true,
					'description' => esc_html__( 'Order by.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'dropdown',
					'heading' => esc_html__( 'Sort Order', 'bakery-shortcodes' ),
					'param_name' => 'order',
					'admin_label' => true,
					'value' =>  array(
						esc_html__( 'Descending', 'bakery-shortcodes' ) => 'DESC',
						esc_html__( 'Ascending', 'bakery-shortcodes' ) => 'ASC'
					),
					'std' => 'DESC',
					'save_always' => true,
					'description' => esc_html__( 'Select order type.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'dropdown',
					'heading' => esc_html__( 'Type', 'bakery-shortcodes' ),
					'param_name' => 'type',
					'admin_label' => true,
					'value' =>  array(
						esc_html__( 'Grid', 'bakery-shortcodes' ) => 'grid',
						esc_html__( 'Carousel', 'bakery-shortcodes' ) => 'carousel'
					),
					'save_always' => true,
					'description' => esc_html__( 'Select display type.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'dropdown',
					'heading' => esc_html__( 'Layout', 'bakery-shortcodes' ),
					'param_name' => 'layout',
					'admin_label' => true,
					'value' => array(
						esc_html__( '1 Column', 'bakery-shortcodes' ) => '1',
						esc_html__( '2 Columns', 'bakery-shortcodes' ) => '2',
						esc_html__( '3 Columns', 'bakery-shortcodes' ) => '3',
						esc_html__( '4 Columns', 'bakery-shortcodes' ) => '4'
					),
					'std' => '4',
					'save_always' => true,
					'description' => esc_html__( 'Select display layout.', 'bakery-shortcodes' ),
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Show Counts', 'bakery-shortcodes' ),
					'param_name' => 'show_counts',
					'value' =>  array( 'Yes, please!' => '1' ),
					'std' => '1',
					'save_always' => true,
					'description' => esc_html__( 'Check to show product counts', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Carousel Options', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Show navigation', 'bakery-shortcodes' ),
					'param_name' => 'c_show_navigation',
					'dependency' => array( 'element' => 'type', 'value' => 'carousel' ),
					'value' =>  array( 'Yes, please!' => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Check to show carousel navigation.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Carousel Options', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Show pagination', 'bakery-shortcodes' ),
					'param_name' => 'c_show_pagination',
					'dependency' => array( 'element' => 'type', 'value' => 'carousel' ),
					'value' =>  array( 'Yes, please!' => '1' ),
					'std' => '1',
					'save_always' => true,
					'description' => esc_html__( 'Check to show carousel pagination.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Carousel Options', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Auto play', 'bakery-shortcodes' ),
					'param_name' => 'c_autoplay',
					'dependency' => array( 'element' => 'type', 'value' => 'carousel' ),
					'value' => '',
					'save_always' => true,
					'description' => wp_kses( __( 'Change to any integrer for example <b>5000</b> to play every <b>5</b> seconds. Leave blank to disable autoplay.', 'bakery-shortcodes' ), array( 'b' => array() ) )
				),
				array(
					'group' => esc_html__( 'Carousel Options', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Stop autoplay on mouse hover', 'bakery-shortcodes' ),
					'param_name' => 'c_stop_on_hover',
					'dependency' => array( 'element' => 'c_autoplay', 'not_empty' => true ),
					'value' =>  array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'save_always' => true,
					'description' => esc_html__( 'Check to stop carousel on hover.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Design Options', 'bakery-shortcodes' ),
					'type' => 'css_editor',
					'heading' => esc_html__( 'CSS box', 'bakery-shortcodes' ),
					'param_name' => 'css'
				)
			)
		)
	);
}
