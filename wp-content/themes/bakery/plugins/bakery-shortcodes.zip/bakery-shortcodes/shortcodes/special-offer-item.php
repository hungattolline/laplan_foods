<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * Special Offer Item Shortcode
 */

if ( ! function_exists( 'bakery_social_networks_shortcode' ) ) {
	function bakery_special_offer_item_shortcode( $atts = null, $content = null ) {
		return '';
	}
}

add_shortcode( 'vu_special_offer_item', 'bakery_special_offer_item_shortcode' );

/**
 * Special Offer Item VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_special_offer_item' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_special_offer_item extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_special_offer_item', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_special_offer_item', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'Special Offer Item', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Add special offer item', 'bakery-shortcodes' ),
			'base' => 'vu_special_offer_item',
			'icon' => 'vu_special-offer-item-icon',
			'controls' => 'full',
			'as_child' => array( 'only' => 'vu_special_offer' ),
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'type' => 'attach_image',
					'heading' => esc_html__( 'Thumbnail', 'bakery-shortcodes' ),
					'param_name' => 'thumbnail',
					'edit_field_class' => 'vc_col-xs-6',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select thumbnail from media library.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'attach_image',
					'heading' => esc_html__( 'Image', 'bakery-shortcodes' ),
					'param_name' => 'image',
					'edit_field_class' => 'vc_col-xs-6 vu_p-t-0',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select image from media library.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Label', 'bakery-shortcodes' ),
					'param_name' => 'label',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter product label. Leave blank if no label is needed.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Name', 'bakery-shortcodes' ),
					'param_name' => 'name',
					'admin_label' => true,
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter product name.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textarea',
					'heading' => esc_html__( 'Description', 'bakery-shortcodes' ),
					'param_name' => 'description',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter product description.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Price', 'bakery-shortcodes' ),
					'param_name' => 'price',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter product price [eg. 35]', 'bakery-shortcodes' )
				),
				array(
					'type' => 'select2',
					'heading' => esc_html__( 'Currency', 'bakery-shortcodes' ),
					'param_name' => 'currency',
					'options' => array(
						'placeholder' => '',
						'allowClear' => true,
						'tags' => false
					),
					'value' => array_merge( array( '' => '' ), bakery_get_currencies() ),
					'save_always' => true,
					'description' => esc_html__( 'Select product currency.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Button Text', 'bakery-shortcodes' ),
					'param_name' => 'button_text',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter button text.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'vc_link',
					'heading' => esc_html__( 'URL (Link)', 'bakery-shortcodes' ),
					'param_name' => 'button_link',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Add link to button.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				)
			)
		)
	);
}
