<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * Progress Bar Shortcode
 *
 * @param string $atts['label']
 * @param string $atts['value']
 * @param string $atts['text_color']
 * @param string $atts['bar_color']
 * @param string $atts['bar_bg_color']
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 */

if ( ! function_exists( 'bakery_progress_bar_shortcode' ) ) {
	function bakery_progress_bar_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'label' => '',
			'value' => '',
			'custom_color' => '',
			'text_color' => '',
			'bar_color' => '',
			'bar_bg_color' => '',
			'class' => ''
		), $atts, 'vu_progress_bar' );

		ob_start(); ?>
		<div class="vu_progress-bar<?php bakery_extra_class( $atts['class'] ); ?>"<?php echo ( $atts['custom_color'] == "1" && ! empty( $atts['text_color'] ) ) ? ' style="color:' . esc_attr( $atts['text_color'] ) . ';"' : ''; ?> data-value="<?php echo absint( $atts['value'] ); ?>">
			<span class="vu_pb-label"><?php echo esc_attr( $atts['label'] ); ?></span>
			<span class="vu_pb-count"><?php echo esc_attr( $atts['value'] ); ?>%</span>
			<div class="clear"></div>
			<div class="vu_pb-container"<?php echo ( $atts['custom_color'] == "1" && ! empty( $atts['bar_bg_color'] ) ) ? ' style="background-color:' . esc_attr( $atts['bar_bg_color'] ) . ';"' : ''; ?>>
				<div class="vu_pb-bar"<?php echo ( $atts['custom_color'] == "1" && ! empty( $atts['bar_color'] ) ) ? ' style="background-color:' . esc_attr( $atts['bar_color'] ) . ';"' : ''; ?>>
				</div>
			</div>
		</div>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_progress_bar', 'bakery_progress_bar_shortcode' );

/**
 * Progress Bar VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_progress_bar' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_progress_bar extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_progress_bar', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_progress_bar', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'Progress Bar', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Add progress bar', 'bakery-shortcodes' ),
			'base' => 'vu_progress_bar',
			'class' => 'vc_vu_progress_bar',
			'icon' => 'vu_element-icon vu_progress-bar-icon',
			'controls' => 'full',
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Label', 'bakery-shortcodes' ),
					'param_name' => 'label',
					'admin_label' => true,
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter bar title.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Value', 'bakery-shortcodes' ),
					'param_name' => 'value',
					'admin_label' => true,
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter bar value from 0 to 100.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__( 'Use Custom Color', 'bakery-shortcodes' ),
					'param_name' => 'custom_color',
					'value' =>  array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Check this to use custom colors.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Text Color', 'bakery-shortcodes' ),
					'param_name' => 'text_color',
					'dependency' => array( 'element' => 'custom_color', 'value' => '1' ),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select custom bar text color.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Bar Color', 'bakery-shortcodes' ),
					'param_name' => 'bar_color',
					'dependency' => array( 'element' => 'custom_color', 'value' => '1' ),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select custom bar color.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Bar Background Color', 'bakery-shortcodes' ),
					'param_name' => 'bar_bg_color',
					'dependency' => array( 'element' => 'custom_color', 'value' => '1' ),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select custom bar background color.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				)
			)
		)
	);
}
