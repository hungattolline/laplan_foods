<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * WC Product Shortcode
 *
 * @param string $atts['style']
 * @param string $atts['product']
 * @param string $atts['image_display']
 * @param string $atts['content_display']
 * @param string $atts['label']
 * @param string $atts['show_zoom_icon']
 * @param string $atts['show_link_icon']
 * @param string $atts['show_cart_icon']
 * @param string $atts['show_title']
 * @param string $atts['show_description']
 * @param string $atts['show_categories']
 * @param string $atts['show_quantity']
 * @param string $atts['show_price']
 * @param string $atts['disable_link']
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 */

if ( ! function_exists( 'bakery_wc_product_shortcode' ) ) {
	function bakery_wc_product_shortcode( $atts = null, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'style' => '',
			'product' => '',
			'image_display' => '',
			'content_display' => '',
			'label' => '',
			'show_zoom_icon' => '',
			'show_link_icon' => '',
			'show_cart_icon' => '',
			'show_title' => '',
			'show_description' => '',
			'show_categories' => '',
			'show_quantity' => '',
			'show_price' => '',
			'disable_link' => '',
			'class' => ''
		), $atts, 'vu_wc_product' );

		$product = wc_setup_product_data( absint( $atts['product'] ) );

		if ( empty( $product ) ) {
			return;
		}

		ob_start(); ?>
		<article class="vu_wc-product vu_p-style-<?php echo esc_attr( $atts['style'] ); ?> clearfix <?php echo implode( ' ', get_post_class( bakery_extra_class( $atts['class'] ), $product->get_id() ) ); ?>" data-id="<?php echo $product->get_id(); ?>">
			<?php if ( has_post_thumbnail( $product->get_id() ) ) : ?>
				<?php if ( ! empty( $atts['label'] ) ) : ?>
					<div class="vu_p-label">
						<span><?php echo esc_html( $atts['label'] ); ?></span>
					</div>
				<?php endif; ?>

				<?php if ( $atts['style'] == "1" || $atts['style'] == "2" ) : ?>
					<div class="vu_p-image vu_p-img-<?php echo esc_attr( $atts['image_display'] ); ?> vu_lazy-load" data-img="<?php echo bakery_get_attachment_image_src( get_post_thumbnail_id( $product->get_id() ), 'full' ); ?>">
						<?php if ( $atts['disable_link'] != '1' ) : ?>
							<a href="<?php echo $product->get_permalink(); ?>">
								<?php echo get_the_post_thumbnail( $product->get_id(), 'bakery_ratio-1:1' ); ?>
							</a>
						<?php else : ?>
							<span><?php echo get_the_post_thumbnail( $product->get_id(), 'bakery_ratio-1:1' ); ?></span>
						<?php endif; ?>
					</div>
				<?php else : ?>
					<div class="vu_p-image vu_lazy-load" data-img="<?php echo bakery_get_attachment_image_src( get_post_thumbnail_id( $product->get_id() ), 'full' ); ?>">
						<span><?php echo get_the_post_thumbnail( $product->get_id(), 'bakery_ratio-1:1' ); ?></span>
					</div>
				<?php endif; ?>
			<?php endif; ?>

			<div class="vu_p-content<?php echo ( $atts['style'] == "1" || $atts['style'] == "2") ? ' vu_p-content-' . esc_attr( $atts['content_display'] ) : ''; ?>">
				<?php if ( $atts['show_zoom_icon'] == '1' || $atts['show_link_icon'] == '1' || $atts['show_cart_icon'] == '1' ) : ?>
					<div class="vu_p-icons">
						<?php if ( $atts['show_zoom_icon'] == '1' ) : ?>
							<a href="<?php echo esc_url( bakery_get_attachment_image_src( get_post_thumbnail_id( $product->get_id() ), 'full' ) ); ?>" title="<?php echo $product->get_title(); ?>" class="vu_p-icon vu_p-i-zoom vu_lightbox"><i class="fa fa-search" aria-hidden="true"></i></a>
						<?php endif; ?>

						<?php if ( $atts['show_link_icon'] == '1' ) : ?>
							<a href="<?php echo $product->get_permalink(); ?>" title="<?php echo $product->get_title(); ?>" class="vu_p-icon vu_p-i-link"><i class="fa fa-link" aria-hidden="true"></i></a>
						<?php endif; ?>

						<?php if ( $atts['show_cart_icon'] == '1' && function_exists( 'bakery_wc_ywctm_check_hide_add_cart_loop' ) && ! bakery_wc_ywctm_check_hide_add_cart_loop() ) : ?>
							<?php woocommerce_template_loop_add_to_cart(); ?>
						<?php endif; ?>
					</div>
				<?php endif; ?>

				<?php if ( $atts['show_title'] == '1' ) : ?>
					<h3 class="vu_p-name">
						<?php if ( $atts['disable_link'] != '1' ) : ?>
							<a href="<?php echo $product->get_permalink(); ?>"><?php echo $product->get_title(); ?></a>
						<?php else : ?>
							<?php echo $product->get_title(); ?>
						<?php endif; ?>
					</h3>
				<?php endif; ?>

				<?php if ( $atts['show_description'] == '1' ) :
					$bakery_product_description = $product->get_short_description();
					if ( ! empty( $bakery_product_description ) ) : ?>
						<div class="vu_p-description">
							<?php echo wpautop( $bakery_product_description ); ?>
						</div>
					<?php endif; ?>
				<?php endif; ?>

				<?php if ( $atts['show_categories'] == '1' ) :
					$bakery_product_categories = bakery_wc_product_terms( $product->get_id(), false, ', ', false, 'product_cat' );
					if ( ! empty( $bakery_product_categories ) ) : ?>
						<div class="vu_p-categories">
							<p><?php echo esc_html( $bakery_product_categories ); ?></p>
						</div>
					<?php endif; ?>
				<?php endif; ?>

				<?php if ( $atts['show_quantity'] == '1' ) : ?>
					<div class="vu_p-quantity">
						<?php woocommerce_quantity_input( array(), $product, true ); ?>
					</div>
				<?php endif; ?>

				<?php if ( $atts['show_price'] == '1' ) : ?>
					<?php woocommerce_template_loop_price(); ?>
				<?php endif; ?>
			</div>
		</article>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_wc_product', 'bakery_wc_product_shortcode' );

/**
 * WC Product VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_wc_product' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_wc_product extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_wc_product', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_wc_product', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'WC Product', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Single WC product item', 'bakery-shortcodes' ),
			'base' => 'vu_wc_product',
			'icon' => 'vu_wc-product-icon',
			'controls' => 'full',
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'type' => 'image_select',
					'heading' => esc_html__( 'Style', 'bakery-shortcodes' ),
					'param_name' => 'style',
					'value' => array(
						'1' => array(
							'title' => esc_html__( '#1', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/wc-product-styles/1.jpg'
						),
						'2' => array(
							'title' => esc_html__( '#2', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/wc-product-styles/2.jpg'
						),
						'3' => array(
							'title' => esc_html__( '#3', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/wc-product-styles/3.jpg'
						),
						'4' => array(
							'title' => esc_html__( '#4', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/wc-product-styles/4.jpg'
						)
					),
					'width' => 'calc(25% - 10px)',
					'height' => 'auto',
					'std' => '1',
					'save_always' => true,
					'description' => esc_html__( 'Select product style.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'select2',
					'heading' => esc_html__( 'Product', 'bakery-shortcodes' ),
					'param_name' => 'product',
					'alias' => '_product',
					'options' => array(
						'source' => admin_url( 'admin-ajax.php?action=bakery_get_wc_products' ),
						'tags' => false
					),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select product.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'admin_label',
					'heading' => esc_html__( 'Product', 'bakery-shortcodes' ),
					'param_name' => '_product',
					'admin_label' => true,
					'save_always' => true
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Shape', 'bakery-shortcodes' ),
					'param_name' => 'image_display',
					'dependency' => array( 'element' => 'style', 'value' => array( '1', '2' ) ),
					'value' => array(
						esc_html__( 'Portrait', 'bakery-shortcodes' ) => 'portrait',
						esc_html__( 'Landscape', 'bakery-shortcodes' ) => 'landscape',
						esc_html__( 'Square', 'bakery-shortcodes' ) => 'square'
					),
					'save_always' => true,
					'description' => esc_html__( 'Select product shape.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Content', 'bakery-shortcodes' ),
					'param_name' => 'content_display',
					'dependency' => array( 'element' => 'style', 'value' => array( '1', '2' ) ),
					'value' => array(
						esc_html__( 'Only on hover', 'bakery-shortcodes' ) => 'hover',
						esc_html__( 'Always', 'bakery-shortcodes' ) => 'always'
					),
					'std' => 'hover',
					'save_always' => true,
					'description' => esc_html__( 'Select when to show product content.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Label', 'bakery-shortcodes' ),
					'param_name' => 'label',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter product label. Leave blank if no label is needed.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column',
					'heading' => esc_html__( 'Others Options', 'bakery-shortcodes' ),
					'param_name' => 'show_zoom_icon',
					'value' => array( esc_html__( 'Show Zoom Icon', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true
				),
				array(
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-5',
					'param_name' => 'show_link_icon',
					'value' => array( esc_html__( 'Show Link Icon', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true
				),
				array(
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-5',
					'param_name' => 'show_cart_icon',
					'value' => array( esc_html__( 'Show Add to Cart Icon', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true
				),
				array(
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-5',
					'param_name' => 'show_title',
					'value' => array( esc_html__( 'Show Title', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true
				),
				array(
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-5',
					'param_name' => 'show_description',
					'value' => array( esc_html__( 'Show Description', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true
				),
				array(
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-5',
					'param_name' => 'show_categories',
					'value' => array( esc_html__( 'Show Categories', 'bakery-shortcodes' ) => '1' ),
					'std' => '0',
					'save_always' => true
				),
				array(
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-5',
					'param_name' => 'quantity',
					'value' => array( esc_html__( 'Show Quantity', 'bakery-shortcodes' ) => '1' ),
					'std' => '0',
					'save_always' => true
				),
				array(
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-5',
					'param_name' => 'show_price',
					'value' => array( esc_html__( 'Show Price', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true
				),
				array(
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-5',
					'param_name' => 'disable_link',
					'value' => array( esc_html__( 'Disable Link', 'bakery-shortcodes' ) => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Select other options you want to apply on product item.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				)
			)
		)
	);
}
