<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * WC Products Shortcode
 *
 * @param string $atts['query']
 * @param string $atts['type']
 * @param string $atts['layout']
 * @param string $atts['style']
 * @param string $atts['image_display']
 * @param string $atts['content_display']
 * @param string $atts['show_zoom_icon']
 * @param string $atts['show_link_icon']
 * @param string $atts['show_cart_icon']
 * @param string $atts['show_title']
 * @param string $atts['show_categories']
 * @param string $atts['show_quantity']
 * @param string $atts['show_price']
 * @param string $atts['disable_link']
 * @param string $atts['show_pagination']
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 * @param string $atts['c_show_navigation']
 * @param string $atts['c_show_pagination']
 * @param string $atts['c_autoplay']
 * @param string $atts['c_stop_on_hover']
 * @param string $atts['css']
 */

if ( ! function_exists( 'bakery_wc_products_shortcode' ) ) {
	function bakery_wc_products_shortcode( $atts = null, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'query' => '',
			'type' => '',
			'layout' => '',
			'style' => '',
			'image_display' => '',
			'content_display' => '',
			'show_zoom_icon' => '',
			'show_link_icon' => '',
			'show_cart_icon' => '',
			'show_title' => '',
			'show_categories' => '',
			'show_quantity' => '',
			'show_price' => '',
			'disable_link' => '',
			'show_pagination' => '',
			'class' => '',
			'c_show_navigation' => '',
			'c_show_pagination' => '',
			'c_autoplay' => '',
			'c_stop_on_hover' => '',
			'css' => ''
		), $atts, 'vu_wc_products' );

		if ( stripos( $atts['query'], 'post_type:product' ) === false ) {
			$atts['query'] .= '|post_type:product';
		}

		if ( $atts['type'] == 'grid' && $atts['show_pagination'] == '1' ) {
			$atts['query'] .= '|paged:' . get_query_var( 'paged' );
		}

		$BakeryVcLoopQueryBuilder = new BakeryVcLoopQueryBuilder( esc_attr( $atts['query'] ) );
		$products_query = $BakeryVcLoopQueryBuilder->build();

		if ( function_exists( 'vc_shortcode_custom_css_class' ) ) {
			$atts['class'] .= ' ' . vc_shortcode_custom_css_class( $atts['css'] );
		}

		$atts['class'] = trim( $atts['class'] );

		ob_start(); ?>
		<div class="vu_wc-products vu_p-type-<?php echo esc_attr( $atts['type'] ); ?> vu_p-layout-<?php echo esc_attr( $atts['layout'] ); ?> clearfix<?php bakery_extra_class( $atts['class'] ); ?>">
			<?php if ( $atts['type'] == 'carousel' ) : 
				$carousel_options = array(
					"singleItem" => false,
					"items" => absint( $atts['layout'] ),
					"itemsDesktop" => array(1199, absint( $atts['layout'] ) ),
					"itemsDesktopSmall" => array(980, 2),
					"itemsTablet" => array(768, 2),
					"itemsMobile" => array(479, 1),
					"navigation" => ( $atts['c_show_navigation'] == '1' ) ? true : false,
					"navigationText" => array( '<i class="fa fa-arrow-left" aria-hidden="true"></i>', '<i class="fa fa-arrow-right" aria-hidden="true"></i>' ),
					"pagination" => ( $atts['c_show_pagination'] == '1' ) ? true : false,
					"autoHeight" => true,
					"rewindNav" => true,
					"scrollPerPage" => true,
					"autoPlay" => ( $atts['c_autoplay'] == '' || $atts['c_autoplay'] == '0' ) ? false : absint( $atts['c_autoplay'] ),
					"stopOnHover" => ( $atts['c_stop_on_hover'] == '1' ) ? true : false
				);
			?>
				<div class="vu_p-carousel vu_carousel" data-options="<?php echo esc_attr( json_encode( $carousel_options ) ); ?>">
			<?php else : ?>
				<div class="row">
			<?php endif; ?>

				<?php if ( $products_query->have_posts() ) : while( $products_query->have_posts() ): $products_query->the_post(); ?>
					<?php if ( $atts['type'] != 'carousel' ) : ?>
						<div class="vu_p-item-container col-md-<?php echo (12 / absint( $atts['layout'] ) ); ?> col-sm-6 col-xs-12">
					<?php endif; ?>
						<article class="vu_wc-product vu_p-style-<?php echo esc_attr( $atts['style'] ); ?> clearfix <?php echo implode( ' ', get_post_class( bakery_extra_class( $atts['class'] ), get_the_ID() ) ); ?>" data-id="<?php the_ID(); ?>">
							<?php if ( has_post_thumbnail() ) : ?>
								<?php woocommerce_show_product_loop_sale_flash(); ?>

								<?php if ( $atts['style'] == '1' || $atts['style'] == '2' ) : ?>
									<div class="vu_p-image vu_p-img-<?php echo esc_attr( $atts['image_display'] ); ?> vu_lazy-load" data-img="<?php echo bakery_get_attachment_image_src( get_post_thumbnail_id(), 'full' ); ?>">
										<?php if ( $atts['disable_link'] != '1' ) : ?>
											<a href="<?php the_permalink(); ?>">
												<?php the_post_thumbnail( 'bakery_ratio-1:1' ); ?>
											</a>
										<?php else : ?>
											<span><?php the_post_thumbnail( 'bakery_ratio-1:1' ); ?></span>
										<?php endif; ?>
									</div>
								<?php else : ?>
									<div class="vu_p-image vu_lazy-load" data-img="<?php echo bakery_get_attachment_image_src( get_post_thumbnail_id(), 'full' ); ?>">
										<span><?php the_post_thumbnail( 'bakery_ratio-1:1' ); ?></span>
									</div>
								<?php endif; ?>
							<?php endif; ?>

							<div class="vu_p-content<?php echo ( $atts['style'] == '1' || $atts['style'] == '2' ) ? ' vu_p-content-' . esc_attr( $atts['content_display'] ) : ''; ?>">
								<?php if ( $atts['show_zoom_icon'] == '1' || $atts['show_link_icon'] == '1' || $atts['show_cart_icon'] == '1' ) : ?>
									<div class="vu_p-icons">
										<?php if ( $atts['show_zoom_icon'] == '1' ) : ?>
											<a href="<?php echo esc_url( bakery_get_attachment_image_src( get_post_thumbnail_id(), 'full' ) ); ?>" title="<?php the_title(); ?>" class="vu_p-icon vu_p-i-zoom vu_lightbox"><i class="fa fa-search" aria-hidden="true"></i></a>
										<?php endif; ?>

										<?php if ( $atts['show_link_icon'] == '1' ) : ?>
											<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="vu_p-icon vu_p-i-link"><i class="fa fa-link" aria-hidden="true"></i></a>
										<?php endif; ?>

										<?php if ( $atts['show_cart_icon'] == '1' && function_exists( 'bakery_wc_ywctm_check_hide_add_cart_loop' ) && ! bakery_wc_ywctm_check_hide_add_cart_loop() ) : ?>
											<?php woocommerce_template_loop_add_to_cart(); ?>
										<?php endif; ?>
									</div>
								<?php endif; ?>

								<?php if ( $atts['show_title'] == '1' ) : ?>
									<h3 class="vu_p-name">
										<?php if ( $atts['disable_link'] != '1' ) : ?>
											<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
										<?php else : ?>
											<?php the_title(); ?>
										<?php endif; ?>
									</h3>
								<?php endif; ?>

								<?php if ( $atts['show_categories'] == '1' ) :
									$bakery_product_categories = bakery_wc_product_terms( get_the_ID(), false, ', ', false, 'product_cat' );

									if ( ! empty( $bakery_product_categories ) ) : ?>
										<div class="vu_p-categories">
											<p><?php echo esc_html( $bakery_product_categories ); ?></p>
										</div>
									<?php endif; ?>
								<?php endif; ?>

								<?php if ( $atts['show_quantity'] == '1' ) : ?>
									<div class="vu_p-quantity">
										<?php woocommerce_quantity_input(); ?>
									</div>
								<?php endif; ?>

								<?php if ( $atts['show_price'] == '1' ) : ?>
									<?php woocommerce_template_loop_price(); ?>
								<?php endif; ?>
							</div>
						</article>
					<?php if ( $atts['type'] != 'carousel' ) : ?>
						</div>
					<?php endif; ?>
				<?php endwhile; endif; ?>
				<?php if ( $atts['type'] == 'grid' && $atts['show_pagination'] == '1' ) { bakery_pagination( $products_query ); } ?>
				<?php wp_reset_query(); ?>
			</div>
		</div>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_wc_products', 'bakery_wc_products_shortcode' );

/**
 * WC Products VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_wc_products' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_wc_products extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_wc_products', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_wc_products', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'WC Products', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Add WC products', 'bakery-shortcodes' ),
			'base' => 'vu_wc_products',
			'icon' => 'vu_wc-products-icon',
			'controls' => 'full',
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'loop',
					'heading' => esc_html__( 'Products Query', 'bakery-shortcodes' ),
					'param_name' => 'query',
					'settings' => array(
						'size' => array( 'hidden' => false, 'value' => 'All' ),
						'order_by' => array( 'value' => 'date' ),
						'categories' => array( 'hidden' => true ),
						'tags' => array( 'hidden' => true ),
						'tax_query' => array( 'hidden' => false ),
						'authors' => array( 'hidden' => true ),
						'post_type' => array( 'hidden' => false, 'value' => 'product' )
					),
					'value' => 'size:All|order_by:date|post_type:product',
					'save_always' => true,
					'description' => esc_html__( 'Create WordPress loop, to show products from your site.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'dropdown',
					'heading' => esc_html__( 'Type', 'bakery-shortcodes' ),
					'param_name' => 'type',
					'admin_label' => true,
					'value' =>  array(
						esc_html__( 'Grid', 'bakery-shortcodes' ) => 'grid',
						esc_html__( 'Carousel', 'bakery-shortcodes' ) => 'carousel'
					),
					'save_always' => true,
					'description' => esc_html__( 'Select products type.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'dropdown',
					'heading' => esc_html__( 'Layout', 'bakery-shortcodes' ),
					'param_name' => 'layout',
					'admin_label' => true,
					'value' => array(
						esc_html__( '1 Column', 'bakery-shortcodes' ) => '1',
						esc_html__( '2 Columns', 'bakery-shortcodes' ) => '2',
						esc_html__( '3 Columns', 'bakery-shortcodes' ) => '3',
						esc_html__( '4 Columns', 'bakery-shortcodes' ) => '4'
					),
					'std' => '4',
					'save_always' => true,
					'description' => esc_html__( 'Select products layout.', 'bakery-shortcodes' ),
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'image_select',
					'heading' => esc_html__( 'Style', 'bakery-shortcodes' ),
					'param_name' => 'style',
					'value' => array(
						'1' => array(
							'title' => esc_html__( '#1', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/wc-product-styles/1.jpg'
						),
						'2' => array(
							'title' => esc_html__( '#2', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/wc-product-styles/2.jpg'
						),
						'3' => array(
							'title' => esc_html__( '#3', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/wc-product-styles/3.jpg'
						),
						'4' => array(
							'title' => esc_html__( '#4', 'bakery-shortcodes' ),
							'image' => Bakery_Shortcodes::$_url . 'assets/img/wc-product-styles/4.jpg'
						)
					),
					'width' => 'calc(25% - 10px)',
					'height' => 'auto',
					'std' => '1',
					'save_always' => true,
					'description' => esc_html__( 'Select product style.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'dropdown',
					'heading' => esc_html__( 'Shape', 'bakery-shortcodes' ),
					'param_name' => 'image_display',
					'dependency' => array( 'element' => 'style', 'value' => array( '1', '2' ) ),
					'value' => array(
						esc_html__( 'Portrait', 'bakery-shortcodes' ) => 'portrait',
						esc_html__( 'Landscape', 'bakery-shortcodes' ) => 'landscape',
						esc_html__( 'Square', 'bakery-shortcodes' ) => 'square'
					),
					'save_always' => true,
					'description' => esc_html__( 'Select product shape.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'dropdown',
					'heading' => esc_html__( 'Content', 'bakery-shortcodes' ),
					'param_name' => 'content_display',
					'dependency' => array( 'element' => 'style', 'value' => array( '1', '2' ) ),
					'value' => array(
						esc_html__( 'Only on hover', 'bakery-shortcodes' ) => 'hover',
						esc_html__( 'Always', 'bakery-shortcodes' ) => 'always'
					),
					'std' => 'hover',
					'save_always' => true,
					'description' => esc_html__( 'Select when to show product content.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column',
					'heading' => esc_html__( 'Others Options', 'bakery-shortcodes' ),
					'param_name' => 'show_zoom_icon',
					'value' => array( esc_html__( 'Show Zoom Icon', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-5',
					'param_name' => 'show_link_icon',
					'value' => array( esc_html__( 'Show Link Icon', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-5',
					'param_name' => 'show_cart_icon',
					'value' => array( esc_html__( 'Show Add to Cart Icon', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-5',
					'param_name' => 'show_title',
					'value' => array( esc_html__( 'Show Title', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-5',
					'param_name' => 'show_categories',
					'value' => array( esc_html__( 'Show Categories', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-5',
					'param_name' => 'show_quantity',
					'value' => array( esc_html__( 'Show Quantity', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-5',
					'param_name' => 'show_price',
					'value' => array( esc_html__( 'Show Price', 'bakery-shortcodes' ) => '1' ),
					'std' => '1',
					'save_always' => true
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'edit_field_class' => 'vc_col-sm-12 vc_column vu_p-t-5',
					'param_name' => 'disable_link',
					'value' => array( esc_html__( 'Disable Link', 'bakery-shortcodes' ) => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Select other options you want to apply on product item.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Show pagination', 'bakery-shortcodes' ),
					'param_name' => 'show_pagination',
					'dependency' => array( 'element' => 'type', 'value' => 'grid' ),
					'value' =>  array( 'Yes, please!' => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Check to show products pagination.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Carousel Options', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Show navigation', 'bakery-shortcodes' ),
					'param_name' => 'c_show_navigation',
					'dependency' => array( 'element' => 'type', 'value' => 'carousel' ),
					'value' =>  array( 'Yes, please!' => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Check to show carousel navigation.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Carousel Options', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Show pagination', 'bakery-shortcodes' ),
					'param_name' => 'c_show_pagination',
					'dependency' => array( 'element' => 'type', 'value' => 'carousel' ),
					'value' =>  array( 'Yes, please!' => '1' ),
					'std' => '1',
					'save_always' => true,
					'description' => esc_html__( 'Check to show carousel pagination.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Carousel Options', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Auto play', 'bakery-shortcodes' ),
					'param_name' => 'c_autoplay',
					'dependency' => array( 'element' => 'type', 'value' => 'carousel' ),
					'value' => '',
					'save_always' => true,
					'description' => wp_kses( __( 'Change to any integrer for example <b>5000</b> to play every <b>5</b> seconds. Leave blank to disable autoplay.', 'bakery-shortcodes' ), array( 'b' => array() ) )
				),
				array(
					'group' => esc_html__( 'Carousel Options', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Stop autoplay on mouse hover', 'bakery-shortcodes' ),
					'param_name' => 'c_stop_on_hover',
					'dependency' => array( 'element' => 'c_autoplay', 'not_empty' => true ),
					'value' =>  array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'save_always' => true,
					'description' => esc_html__( 'Check to stop carousel on hover.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Design Options', 'bakery-shortcodes' ),
					'type' => 'css_editor',
					'heading' => esc_html__( 'CSS box', 'bakery-shortcodes' ),
					'param_name' => 'css'
				)
			)
		)
	);
}
