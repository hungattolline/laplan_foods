<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * Pricing Table Shortcode
 *
 * @param string $atts['title']
 * @param string $atts['amount']
 * @param string $atts['currency']
 * @param string $atts['period']
 * @param string $atts['bg_color']
 * @param string $atts['content']
 * @param string $atts['show_button']
 * @param string $atts['button_text']
 * @param string $atts['button_link']
 * @param string $atts['active']
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 */

if ( ! function_exists( 'bakery_pricing_table_shortcode' ) ) {
	function bakery_pricing_table_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'title' => '',
			'amount' => '',
			'currency' => '',
			'period' => '',
			'show_button' => '',
			'button_text' => '',
			'button_link' => '',
			'active' => '',
			'class' => ''
		), $atts, 'vu_pricing_table' );

		$button_link = ( function_exists( 'vc_build_link' ) ) ? vc_build_link( $atts['button_link'] ) : array( 'url' => '', 'title' => '', 'target' => '' );

		$amount = @explode( '.', $atts['amount'] );

		ob_start(); ?>
		<div class="vu_pricing-table<?php echo ( $atts['active'] == '1' ) ? ' vu_pt-active' : ''; ?><?php bakery_extra_class( $atts['class'] ); ?>">
			<div class="vu_pt-header">
				<div class="vu_pt-price">
					<span class="vu_pt-currency"><?php echo esc_html( $atts['currency'] ); ?></span>
					<span class="vu_pt-amount"><?php echo isset( $amount[0] ) ? esc_html( $amount[0] ) : esc_html( $atts['amount'] ); ?><?php echo ( isset( $amount[1] ) && ! empty( $amount[1] ) ) ? '<sup>' . esc_html( $amount[1] ) . '</sup>' : ''; ?></span>
					<span class="vu_pt-period"><?php echo esc_html( $atts['period'] ); ?></span>
				</div>

				<h4 class="vu_pt-title"><?php echo esc_html( $atts['title'] ); ?></h4>
			</div>

			<div class="vu_pt-content">
				<?php echo bakery_remove_wpautop( $content, true ); ?>
			</div>
			
			<?php if ( $atts['show_button'] == '1' ) { ?>
				<div class="vu_pt-button">
					<?php echo '<a href="' . esc_url( $button_link['url'] ) . '" title="' . esc_attr( $button_link['title'] ) . '" target="' . ( strlen( $button_link['target'] ) > 0 ? esc_attr( $button_link['target'] ) : '_self' ) . '">' . esc_attr( $atts['button_text'] ) . '</a>'; ?>
				</div>
			<?php } ?>
		</div>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_pricing_table', 'bakery_pricing_table_shortcode' );

/**
 * Pricing Table VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_pricing_table' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_pricing_table extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_pricing_table', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_pricing_table', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'Pricing Table', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Add pricing table item', 'bakery-shortcodes' ),
			'base' => 'vu_pricing_table',
			'class' => 'vc_vu_pricing-table',
			'icon' => 'vu_element-icon vu_pricing-table-icon',
			'controls' => 'full',
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'group' => esc_html__( 'Header', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Title', 'bakery-shortcodes' ),
					'param_name' => 'title',
					'admin_label' => true,
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter table title [eg. Basic Pack].', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Header', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Amount', 'bakery-shortcodes' ),
					'param_name' => 'amount',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter amount/price [eg. 35]', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Header', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Currency', 'bakery-shortcodes' ),
					'param_name' => 'currency',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter table currency [eg. $]', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Header', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Period', 'bakery-shortcodes' ),
					'param_name' => 'period',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter price period [eg. per month, year]', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Header', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Active', 'bakery-shortcodes' ),
					'param_name' => 'active',
					'value' =>  array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Check to make pricing table active.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Header', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Content', 'bakery-shortcodes' ),
					'type' => 'textarea_html',
					'heading' => esc_html__( 'Content', 'bakery-shortcodes' ),
					'param_name' => 'content',
					'value' => '<ul><li>item</li><li>item</li><li>item</li><li>item</li><li>item</li></ul>',
					'save_always' => true,
					'description' => esc_html__( 'Write pricing table content.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Button', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Show Button', 'bakery-shortcodes' ),
					'param_name' => 'show_button',
					'value' =>  array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Check this to show button.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Button', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Text', 'bakery-shortcodes' ),
					'param_name' => 'button_text',
					'dependency' => array( 'element' => 'show_button', 'value' => '1' ),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter button text. [eg. get now, see more].', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Button', 'bakery-shortcodes' ),
					'type' => 'vc_link',
					'heading' => esc_html__( 'URL (Link)', 'bakery-shortcodes' ),
					'param_name' => 'button_link',
					'dependency' => array( 'element' => 'show_button', 'value' => '1' ),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Add link to button.', 'bakery-shortcodes' )
				)
			)
		)
	);
}
