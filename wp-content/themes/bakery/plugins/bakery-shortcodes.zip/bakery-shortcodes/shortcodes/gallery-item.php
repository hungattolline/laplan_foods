<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * Gallery Item Shortcode
 *
 * @param string $atts['image']
 * @param string $atts['ratio']
 * @param string $atts['title']
 * @param string $atts['subtitle']
 * @param string $atts['category']
 * @param string $atts['link_type']
 * @param string $atts['link']
 * @param string $atts['show_icon']
 * @param string $atts['icon_fontawesome']
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 */

if ( ! function_exists( 'bakery_gallery_item_shortcode' ) ) {
	function bakery_gallery_item_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'image' => '',
			'ratio' => '',
			'size' => '',
			'title' => '',
			'subtitle' => '',
			'category' => '',
			'link_type' => '',
			'link' => '',
			'show_icon' => '',
			'icon_fontawesome' => '',
			'class' => '',
			'type' => '',
			'layout' => ''
		), $atts, 'vu_gallery_item' );

		if ( $atts['type'] == 'masonry' ) {
			$categories = @explode( ',', $atts['category'] );

			if ( is_array( $categories ) ) {
				foreach ( $categories as $key => $value ) {
					$categories[ $key ] = md5( sanitize_title( $value ) );
				}
			} else {
				$categories = md5( sanitize_title( $categories ) );
			}
		}

		ob_start(); ?>
		<?php if ( $atts['type'] == 'standard' ) : ?>
			<div class="vu_g-item<?php echo ( $atts['layout'] != 5 ) ? ' col-md-' . ( 12 / absint( $atts['layout'] ) ) : ''; ?> col-sm-6 col-xs-6 col-tn-12">
		<?php elseif ( $atts['type'] == 'masonry' ) : ?>
			<div class="vu_g-item <?php echo esc_attr( @implode( ' ', $categories ) ); ?>" data-size="<?php echo esc_attr( $atts['size'] ); ?>">
		<?php endif; ?>
			<div class="vu_gallery-item<?php bakery_extra_class( $atts['class'] ); ?>">
				<?php if ( ! empty( $atts['image'] ) ) : ?>
					<div class="vu_gi-image<?php echo ( $atts['type'] == 'masonry' ) ? ' vu_lazy-load' : ''; ?>"<?php echo ( $atts['type'] == 'masonry' ) ? ' data-img="' . bakery_get_attachment_image_src( $atts['image'], 'full' ) . '"' : ''; ?>>
						<?php 
							if ( $atts['type'] == 'masonry' ) {
								echo wp_get_attachment_image( $atts['image'], 'bakery_ratio-' . esc_attr( str_replace( 'x', ':', $atts['size'] ) ) );
							} else {
								echo wp_get_attachment_image( $atts['image'], 'bakery_ratio-' . esc_attr( $atts['ratio'] ) );
							}
						?>
					</div>
				<?php endif; ?>
				<div class="vu_gi-details-container<?php echo ( empty( $atts['title'] ) && empty( $atts['subtitle'] ) && $atts['show_icon'] != '1' ) ? ' vu_gi-empty' : ''; ?>">
					<div class="vu_gi-details">
						<?php if ( $atts['link_type'] == 'lightbox' ) { ?>
							<a href="<?php echo bakery_get_attachment_image_src( $atts['image'], 'full' ); ?>" title="<?php echo esc_attr( $atts['title'] ); ?>" class="vu_gi-lightbox vu_gi-content-container">
						<?php } else if ( $atts['link_type'] == 'url' ) { ?>
							<?php $link = ( function_exists( 'vc_build_link' ) ) ? vc_build_link( $atts['link'] ) : array( 'url' => '', 'title' => '', 'target' => '' ); ?>
							<a href="<?php echo esc_url( $link['url'] ); ?>" title="<?php echo esc_attr( $link['title'] ); ?>" class="vu_gi-content-container" target="<?php echo ( strlen( $link['target'] ) > 0 ? esc_attr( $link['target'] ) : '_self' ); ?>">
						<?php } else { ?>
							<div class="vu_gi-content-container">
						<?php } ?>
								<span class="vu_gi-content">
									<?php if ( $atts['show_icon'] == '1' ) : ?>
										<span class="vu_gi-icon"><i class="<?php echo esc_attr( $atts['icon_fontawesome'] ); ?>"></i></span>
									<?php endif; ?>

									<?php if ( ! empty( $atts['title'] ) ) : ?>
										<h5 class="vu_gi-title"><?php echo esc_html( $atts['title'] ); ?></h5>
									<?php endif; ?>

									<?php if ( ! empty( $atts['subtitle'] ) ) : ?>
										<span class="vu_gi-subtitle"><?php echo esc_html( $atts['subtitle'] ); ?></span>
									<?php endif; ?>
								</span>
						<?php if ( $atts['link_type'] == 'none' ) { ?>
							</div>
						<?php } else { ?>
							</a>
						<?php } ?>
					</div>
				</div>
			</div>

		<?php echo ( $atts['type'] == 'standard' || $atts['type'] == 'masonry' ) ? '</div>' : '';
		
		return ob_get_clean();
	}
}

add_shortcode( 'vu_gallery_item', 'bakery_gallery_item_shortcode' );

/**
 * Gallery VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_gallery_item' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_gallery_item extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_gallery_item', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_gallery_item', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'Gallery Item', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Add gallery item', 'bakery-shortcodes' ),
			'base' => 'vu_gallery_item',
			'icon' => 'vu_gallery-item-icon',
			'custom_markup' => '<input type="hidden" class="wpb_vc_param_value image attach_image" name="image" value="1"><h4 class="wpb_element_title">' . esc_html__( 'Gallery Item', 'bakery-shortcodes' ) . ' <img width="150" height="150" src="' . vc_asset_url( 'vc/blank.gif' ) . '" class="attachment-thumbnail vc_element-icon vu_element-icon" data-name="image" alt="" title="" style="display: none;"><span class="no_image_image vc_element-icon vu_element-icon vu_gallery-item-icon"></span></h4><span class="vc_admin_label admin_label_title hidden-label"><label>Title</label>: </span><span class="vc_admin_label admin_label_category hidden-label"><label>Category</label>: </span>',
			'controls' => 'full',
			'as_child' => array( 'only' => 'vu_gallery' ),
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'type' => 'attach_image',
					'heading' => esc_html__( 'Image', 'bakery-shortcodes' ),
					'param_name' => 'image',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select image from media library.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Ratio', 'bakery-shortcodes' ),
					'param_name' => 'ratio',
					'admin_label' => true,
					'value' => bakery_get_image_ratios(),
					'std' => '4:3',
					'save_always' => true,
					'description' => esc_html__( 'Select image ratio.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Size', 'bakery-shortcodes' ),
					'param_name' => 'size',
					'admin_label' => true,
					'value' => array(
						'1x1' => '1x1',
						'1x2' => '1x2',
						'2x1' => '2x1',
						'2x2' => '2x2'
					),
					'std' => '1x1',
					'save_always' => true,
					'description' => esc_html__( 'Select image size.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Title', 'bakery-shortcodes' ),
					'param_name' => 'title',
					'admin_label' => true,
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter gallery item title.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Subtitle', 'bakery-shortcodes' ),
					'param_name' => 'subtitle',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter gallery item subtitle.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Category', 'bakery-shortcodes' ),
					'param_name' => 'category',
					'admin_label' => true,
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter gallery item category.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Link Type', 'bakery-shortcodes' ),
					'param_name' => 'link_type',
					'value' => array(
						esc_html__( 'No Link', 'bakery-shortcodes' ) => 'none',
						esc_html__( 'Lightbox', 'bakery-shortcodes' ) => 'lightbox',
						esc_html__( 'Link to URL', 'bakery-shortcodes' ) => 'url'
					),
					'std' => 'lightbox',
					'save_always' => true,
					'description' => esc_html__( 'Select gallery item link type.', 'bakery-shortcodes' ),
				),
				array(
					'type' => 'vc_link',
					'heading' => esc_html__( 'URL (Link)', 'bakery-shortcodes' ),
					'param_name' => 'link',
					'dependency' => array( 'element' => 'link_type', 'value' => 'url' ),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Add link to gallery item.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__( 'Show Icon', 'bakery-shortcodes' ),
					'param_name' => 'show_icon',
					'dependency' => array( 'element' => 'link_type', 'value_not_equal_to' => 'none' ),
					'value' =>  array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'save_always' => true,
					'description' => esc_html__( 'Check to show icon.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'iconpicker',
					'heading' => esc_html__( 'Icon', 'bakery-shortcodes' ),
					'param_name' => 'icon_fontawesome',
					'dependency' => array( 'element' => 'show_icon', 'value' => '1' ),
					'settings' => array(
						'emptyIcon' => false,
						'iconsPerPage' => 100
					),
					'value' => 'fa fa-search',
					'save_always' => true,
					'description' => esc_html__( 'Pick an icon from the library.', 'bakery-shortcodes' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				)
			)
		)
	);
}
