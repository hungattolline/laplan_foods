<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * Icon Box Shortcode
 *
 * @param string $atts['icon_library']
 * @param string $atts['icon_bakery']
 * @param string $atts['icon_milingona']
 * @param string $atts['icon_fontawesome']
 * @param string $atts['size']
 * @param string $atts['position']
 * @param string $atts['style']
 * @param string $atts['title']
 * @param string $atts['description']
 * @param string $atts['read_more_text']
 * @param string $atts['link']
 * @param string $atts['clickable']
 * @param string $atts['class'] Add a class name and then refer to it in your css file.
 * @param string $atts['custom_colors']
 * @param string $atts['icon_normal_color']
 * @param string $atts['icon_normal_border_color']
 * @param string $atts['icon_normal_bg_color']
 * @param string $atts['icon_hover_color']
 * @param string $atts['icon_hover_border_color']
 * @param string $atts['icon_hover_bg_color']
 * @param string $atts['title_normal_color']
 * @param string $atts['title_hover_color']
 * @param string $atts['description_color']
 * @param string $atts['css']
 */

if ( ! function_exists( 'bakery_icon_box_shortcode' ) ) {
	function bakery_icon_box_shortcode( $atts, $content = null ) {
		$atts = bakery_shortcode_atts( array(
			'icon_library' => '',
			'icon_bakery' => '',
			'icon_milingona' => '',
			'icon_fontawesome' => '',
			'size' => '',
			'position' => '',
			'style' => '',
			'color' => '',
			'title' => '',
			'description' => '',
			'read_more_text' => '',
			'link' => '',
			'clickable' => '',
			'class' => '',
			'custom_colors' => '',
			'icon_normal_color' => '',
			'icon_normal_border_color' => '',
			'icon_normal_bg_color' => '',
			'icon_hover_color' => '',
			'icon_hover_border_color' => '',
			'icon_hover_bg_color' => '',
			'title_normal_color' => '',
			'title_hover_color' => '',
			'description_color' => '',
			'css' => ''
		), $atts, 'vu_icon_box' );

		if ( $atts['custom_colors'] == '1' ) {
			$custom_class = bakery_custom_class();
			$atts['class'] .= ' ' . $custom_class;
		}

		if ( function_exists( 'vc_shortcode_custom_css_class' ) ) {
			$atts['class'] .= ' ' . vc_shortcode_custom_css_class( $atts['css'] );
		}

		$atts['class'] = trim( $atts['class'] );

		$link = ( function_exists( 'vc_build_link' ) ) ? vc_build_link( $atts['link'] ) : array( 'url' => '', 'title' => '', 'target' => '' );

		$has_link = ( strlen( $atts['link'] ) > 0 && strlen( $link['url'] ) > 0 ) ? true : false;
		
		ob_start(); ?>
		<div class="vu_icon-box vu_ib-size-<?php echo esc_attr( $atts['size'] ); ?> vu_ib-position-<?php echo esc_attr( $atts['position'] ); ?> vu_ib-style-<?php echo esc_attr( $atts['style'] ); ?> vu_ib-color-<?php echo esc_attr( $atts['color'] ); ?> clearfix <?php bakery_extra_class( $atts['class'] ); ?>">
			<?php if ( $atts['custom_colors'] == '1' ) : ?>
				<style scoped>
					<?php if ( ! empty( $atts['icon_normal_color'] ) ) : ?>
						.vu_icon-box.<?php echo esc_attr( $custom_class ); ?> .vu_ib-icon { color: <?php echo esc_attr( $atts['icon_normal_color'] ); ?> !important; }
					<?php endif; ?>
					<?php if ( ! empty( $atts['icon_normal_border_color'] ) ) : ?>
						.vu_icon-box.<?php echo esc_attr( $custom_class ); ?> .vu_ib-icon { border-color: <?php echo esc_attr( $atts['icon_normal_border_color'] ); ?> !important; }
					<?php endif; ?>
					<?php if ( ! empty( $atts['icon_normal_bg_color'] ) ) : ?>
						.vu_icon-box.<?php echo esc_attr( $custom_class ); ?> .vu_ib-icon { background-color: <?php echo esc_attr( $atts['icon_normal_bg_color'] ); ?> !important; }
					<?php endif; ?>
					<?php if ( ! empty( $atts['icon_hover_color'] ) ) : ?>
						.vu_icon-box.<?php echo esc_attr( $custom_class ); ?>:hover .vu_ib-icon { color: <?php echo esc_attr( $atts['icon_hover_color'] ); ?> !important; }
					<?php endif; ?>
					<?php if ( ! empty( $atts['icon_hover_border_color'] ) ) : ?>
						.vu_icon-box.<?php echo esc_attr( $custom_class ); ?>:hover .vu_ib-icon { border-color: <?php echo esc_attr( $atts['icon_hover_border_color'] ); ?> !important; }
					<?php endif; ?>
					<?php if ( ! empty( $atts['icon_hover_bg_color'] ) ) : ?>
						.vu_icon-box.<?php echo esc_attr( $custom_class ); ?>:hover .vu_ib-icon { background-color: <?php echo esc_attr( $atts['icon_hover_bg_color'] ); ?> !important; }
					<?php endif; ?>
					<?php if ( ! empty( $atts['title_normal_color'] ) ) : ?>
						.vu_icon-box.<?php echo esc_attr( $custom_class ); ?> .vu_ib-title { color: <?php echo esc_attr( $atts['title_normal_color'] ); ?> !important; }
					<?php endif; ?>
					<?php if ( ! empty( $atts['title_hover_color'] ) ) : ?>
						.vu_icon-box.<?php echo esc_attr( $custom_class ); ?> .vu_ib-title:hover { color: <?php echo esc_attr( $atts['title_hover_color'] ); ?> !important; }
					<?php endif; ?>
					<?php if ( ! empty( $atts['description_color'] ) ) : ?>
						.vu_icon-box.<?php echo esc_attr( $custom_class ); ?> .vu_ib-description p { color: <?php echo esc_attr( $atts['description_color'] ); ?> !important; }
					<?php endif; ?>
				</style>
			<?php endif; ?>

			<?php 
				if ( $atts['clickable'] == '1' && $has_link == true ) {
					echo '<a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '" target="' . ( strlen( $link['target'] ) > 0 ? esc_attr( $link['target'] ) : '_self' ) . '"><section class="vu_ib-container">';
				}
			?>

			<span class="vu_ib-icon"><i class="<?php echo esc_attr( $atts['icon_' . esc_attr( $atts['icon_library'] ) ] ); ?>"></i></span>

			<?php if ( ! empty( $atts['title'] ) || ! empty( $atts['description'] ) ) : ?>
				<div class="vu_ib-content">
					<?php 
						if ( ! empty( $atts['title'] ) ) {
							if ( $atts['clickable'] != '1' && $has_link == true ) {
								echo '<h5 class="vu_ib-title"><a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '" target="' . ( strlen( $link['target'] ) > 0 ? esc_attr( $link['target'] ) : '_self' ) . '">' . esc_html( $atts['title'] ) . '</a></h5>';
							} else {
								echo '<h5 class="vu_ib-title">' . esc_html( $atts['title'] ) . '</h5>';
							}
						} 
					?>
					<?php if ( ! empty( $atts['description'] ) ) { echo '<div class="vu_ib-description">' . wpautop( $atts['description'] ) . '</div>'; } ?>

					<?php 
						if ( ! empty( $atts['read_more_text'] ) && $has_link == true ) {
							if ( $atts['clickable'] != '1' ) {
								echo '<div class="clear"></div><a href="' . esc_url( $link['url'] ) . '" title="' . esc_attr( $link['title'] ) . '" target="' . ( strlen( $link['target'] ) > 0 ? esc_attr( $link['target'] ) : '_self' ) . '" class="vu_ib-read-more vu_link-inverse">' . esc_html( $atts['read_more_text'] ) . '</a>';
							} else {
								echo '<div class="clear"></div><span class="vu_ib-read-more vu_link-inverse">' . esc_html( $atts['read_more_text'] ) . '</span>';
							}
						}
					?>
				</div>
			<?php endif; ?>

			<?php 
				if ( $atts['clickable'] == '1' && $has_link == true ) {
					echo '</section></a>';
				}
			?>
		</div>
		<?php return ob_get_clean();
	}
}

add_shortcode( 'vu_icon_box', 'bakery_icon_box_shortcode' );

/**
 * Icon Box VC Shortcode
 */

if ( ! class_exists( 'WPBakeryShortCode_vu_icon_box' ) && class_exists( 'WPBakeryShortCode' ) && function_exists( 'vc_map' ) ) {
	class WPBakeryShortCode_vu_icon_box extends WPBakeryShortCode {
		public function content( $atts, $content = null ) {
			$atts = vc_map_get_attributes( 'vu_icon_box', $atts );

			return do_shortcode( bakery_generate_shortcode( 'vu_icon_box', $atts, $content ) );
		}
	}

	vc_map(
		array(
			'name' => esc_html__( 'Icon Box', 'bakery-shortcodes' ),
			'description' => esc_html__( 'Add icon box', 'bakery-shortcodes' ),
			'base' => 'vu_icon_box',
			'class' => 'vc_vu_icon_box',
			'icon' => 'vu_element-icon vu_icon-box-icon',
			'controls' => 'full',
			'category' => esc_html__( 'Bakery', 'bakery-shortcodes' ),
			'params' => array(
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'dropdown',
					'heading' => esc_html__( 'Icon Library', 'bakery-shortcodes' ),
					'param_name' => 'icon_library',
					'value' => array(
						esc_html__( 'Bakery', 'bakery-shortcodes' ) => 'bakery',
						esc_html__( 'Milingona', 'bakery-shortcodes' ) => 'milingona',
						esc_html__( 'FontAwesome', 'bakery-shortcodes' ) => 'fontawesome'
					),
					'save_always' => true,
					'description' => esc_html__( 'Select icon library.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'iconpicker',
					'heading' => esc_html__( 'Icon', 'bakery-shortcodes' ),
					'param_name' => 'icon_bakery',
					'dependency' => array( 'element' => 'icon_library', 'value' => 'bakery' ),
					'settings' => array(
						'emptyIcon' => false,
						'type' => 'bakery',
						'iconsPerPage' => 100
					),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Pick an icon from the library.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'iconpicker',
					'heading' => esc_html__( 'Icon', 'bakery-shortcodes' ),
					'param_name' => 'icon_milingona',
					'dependency' => array( 'element' => 'icon_library', 'value' => 'milingona' ),
					'settings' => array(
						'emptyIcon' => false,
						'type' => 'milingona',
						'iconsPerPage' => 100
					),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Pick an icon from the library.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'iconpicker',
					'heading' => esc_html__( 'Icon', 'bakery-shortcodes' ),
					'param_name' => 'icon_fontawesome',
					'dependency' => array( 'element' => 'icon_library', 'value' => 'fontawesome' ),
					'settings' => array(
						'emptyIcon' => false,
						'type' => 'fontawesome',
						'iconsPerPage' => 100
					),
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Pick an icon from the library.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'dropdown',
					'heading' => esc_html__( 'Size', 'bakery-shortcodes' ),
					'param_name' => 'size',
					'value' => array(
						esc_html__( 'Large', 'bakery-shortcodes' ) => 'large',
						esc_html__( 'Medium', 'bakery-shortcodes' ) => 'medium',
						esc_html__( 'Small', 'bakery-shortcodes' ) => 'small'
					),
					'save_always' => true,
					'description' => esc_html__( 'Select icon size.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'dropdown',
					'heading' => esc_html__( 'Position', 'bakery-shortcodes' ),
					'param_name' => 'position',
					'value' => array(
						esc_html__( 'Left', 'bakery-shortcodes' ) => 'left',
						esc_html__( 'Top', 'bakery-shortcodes' ) => 'top',
						esc_html__( 'Right', 'bakery-shortcodes' ) => 'right'
					),
					'save_always' => true,
					'description' => esc_html__( 'Select icon position.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'dropdown',
					'heading' => esc_html__( 'Style', 'bakery-shortcodes' ),
					'param_name' => 'style',
					'value' => array(
						esc_html__( 'None', 'bakery-shortcodes' ) => 'none',
						esc_html__( 'Circle Fill', 'bakery-shortcodes' ) => 'circle-fill',
						esc_html__( 'Circle Outline', 'bakery-shortcodes' ) => 'circle-outline',
						esc_html__( 'Square Fill', 'bakery-shortcodes' ) => 'square-fill',
						esc_html__( 'Square Outline', 'bakery-shortcodes' ) => 'square-outline',
						esc_html__( 'Rounded Fill', 'bakery-shortcodes' ) => 'rounded-fill',
						esc_html__( 'Rounded Outline', 'bakery-shortcodes' ) => 'rounded-outline',
						esc_html__( 'Rhombus Fill', 'bakery-shortcodes' ) => 'rhombus-fill',
						esc_html__( 'Rhombus Outline', 'bakery-shortcodes' ) => 'rhombus-outline',
						esc_html__( 'Octagon Fill', 'bakery-shortcodes' ) => 'octagon-fill',
						esc_html__( 'Octagon Outline', 'bakery-shortcodes' ) => 'octagon-outline'
					),
					'save_always' => true,
					'description' => esc_html__( 'Select icon style.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'dropdown',
					'heading' => esc_html__( 'Color', 'bakery-shortcodes' ),
					'param_name' => 'color',
					'value' => array(
						esc_html__( 'Primary', 'bakery-shortcodes' ) => 'primary',
						esc_html__( 'Secondary', 'bakery-shortcodes' ) => 'secondary',
						esc_html__( 'Black', 'bakery-shortcodes' ) => 'black',
						esc_html__( 'Gray', 'bakery-shortcodes' ) => 'gray',
						esc_html__( 'White', 'bakery-shortcodes' ) => 'white'
					),
					'std' => 'primary',
					'save_always' => true,
					'description' => esc_html__( 'Select icon box color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Title', 'bakery-shortcodes' ),
					'param_name' => 'title',
					'admin_label' => true,
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter title.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'textarea',
					'heading' => esc_html__( 'Description', 'bakery-shortcodes' ),
					'param_name' => 'description',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Enter description.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Read more text', 'dentalpress-shortcodes' ),
					'param_name' => 'read_more_text',
					'value' => esc_html__( 'Read More', 'bakery-shortcodes' ),
					'save_always' => true,
					'description' => esc_html__( 'Enter read more text.', 'dentalpress-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'vc_link',
					'heading' => esc_html__( 'URL (Link)', 'bakery-shortcodes' ),
					'param_name' => 'link',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Add link to icon box.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Make whole icon box with link?', 'bakery-shortcodes' ),
					'param_name' => 'clickable',
					'value' =>  array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'std' => '0',
					'save_always' => true
				),
				array(
					'group' => esc_html__( 'General', 'bakery-shortcodes' ),
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'bakery-shortcodes' ),
					'param_name' => 'class',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Colors', 'bakery-shortcodes' ),
					'type' => 'checkbox',
					'heading' => esc_html__( 'Custom Colors?', 'bakery-shortcodes' ),
					'param_name' => 'custom_colors',
					'value' =>  array( esc_html__( 'Yes, please!', 'bakery-shortcodes' ) => '1' ),
					'std' => '0',
					'save_always' => true,
					'description' => esc_html__( 'Check to use custom colors.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Colors', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Icon Normal Color', 'bakery-shortcodes' ),
					'param_name' => 'icon_normal_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-4',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select icon normal color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Colors', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Icon Normal Border Color', 'bakery-shortcodes' ),
					'param_name' => 'icon_normal_border_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-4',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select icon normal border color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Colors', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Icon Normal BG Color', 'bakery-shortcodes' ),
					'param_name' => 'icon_normal_bg_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-4',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select icon normal background color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Colors', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Icon Hover Color', 'bakery-shortcodes' ),
					'param_name' => 'icon_hover_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-4',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select icon hover color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Colors', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Icon Hover Border Color', 'bakery-shortcodes' ),
					'param_name' => 'icon_hover_border_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-4',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select icon hover border color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Colors', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Icon Hover BG Color', 'bakery-shortcodes' ),
					'param_name' => 'icon_hover_bg_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-4',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select icon hover background color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Colors', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Title Normal Color', 'bakery-shortcodes' ),
					'param_name' => 'title_normal_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-4',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select title normal color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Colors', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Title Hover Color', 'bakery-shortcodes' ),
					'param_name' => 'title_hover_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-4',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select title hover color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Colors', 'bakery-shortcodes' ),
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Description Color', 'bakery-shortcodes' ),
					'param_name' => 'description_color',
					'dependency' => array( 'element' => 'custom_colors', 'value' => '1' ),
					'edit_field_class' => 'vc_col-xs-4',
					'value' => '',
					'save_always' => true,
					'description' => esc_html__( 'Select description color.', 'bakery-shortcodes' )
				),
				array(
					'group' => esc_html__( 'Design Options', 'bakery-shortcodes' ),
					'type' => 'css_editor',
					'heading' => esc_html__( 'CSS box', 'bakery-shortcodes' ),
					'param_name' => 'css'
				)
			)
		)
	);
}
