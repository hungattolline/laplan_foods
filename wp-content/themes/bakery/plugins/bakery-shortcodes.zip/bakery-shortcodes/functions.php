<?php if ( ! defined( 'ABSPATH' ) ) exit();

// Get Contact Forms 7
if ( ! function_exists( 'bakery_get_cf7' ) ) {
	function bakery_get_cf7() {
		$cf7 = get_posts( 'post_type="wpcf7_contact_form"&numberposts=-1' );

		$contact_forms = array();
		if ( $cf7 ) {
			foreach ( $cf7 as $form ) {
				$contact_forms[ $form->post_title ] = $form->ID;
			}
		} else {
			$contact_forms[ esc_html__( 'No contact forms found', 'bakery-shortcodes' ) ] = 0;
		}

		return $contact_forms;
	}
}

// Get MailChimp Forms
if ( ! function_exists( 'bakery_get_mc4wp' ) ) {
	function bakery_get_mc4wp() {
		$mc4wp = get_posts( 'post_type="mc4wp-form"&numberposts=-1' );

		$mc4wp_forms = array();
		if ( $mc4wp ) {
			foreach ( $mc4wp as $form ) {
				$mc4wp_forms[ $form->post_title ] = $form->ID;
			}
		} else {
			$mc4wp_forms[ esc_html__( 'No mailchimp forms found', 'bakery-shortcodes' ) ] = 0;
		}

		return $mc4wp_forms;
	}
}

// Get Youtube Video ID
if ( ! function_exists( 'bakery_get_youtube_video_id' ) ) {
	function bakery_get_youtube_video_id($url) {
		if ( preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $url, $match ) ) {
			return $match[1];
		} else {
			return false;
		}
	}
}

// Get Vimeo Video ID
if ( ! function_exists( 'bakery_get_vimeo_video_id' ) ) {
	function bakery_get_vimeo_video_id( $url ) {
		if ( preg_match("/(https?:\\/\\/)?(www.)?(player.)?vimeo.com\\/([a-z]*\\/)*([0-9]{6,11})[?]?.*/", $url, $match ) ) {
			return $match[5];
		} else {
			return false;
		}
	}
}

// Get full list of currency codes.
if ( ! function_exists( 'bakery_get_currencies' ) ) {
	function bakery_get_currencies() {
		//https://woocommerce.github.io/code-reference/files/woocommerce-includes-wc-core-functions.html#source-view.475
		return array_unique(
			array(
				esc_html__( 'None', 'bakery-shortcodes' ) => '',
				esc_html__( 'United Arab Emirates dirham', 'bakery-shortcodes' ) => 'AED',
				esc_html__( 'Afghan afghani', 'bakery-shortcodes' ) => 'AFN',
				esc_html__( 'Albanian lek', 'bakery-shortcodes' ) => 'ALL',
				esc_html__( 'Armenian dram', 'bakery-shortcodes' ) => 'AMD',
				esc_html__( 'Netherlands Antillean guilder', 'bakery-shortcodes' ) => 'ANG',
				esc_html__( 'Angolan kwanza', 'bakery-shortcodes' ) => 'AOA',
				esc_html__( 'Argentine peso', 'bakery-shortcodes' ) => 'ARS',
				esc_html__( 'Australian dollar', 'bakery-shortcodes' ) => 'AUD',
				esc_html__( 'Aruban florin', 'bakery-shortcodes' ) => 'AWG',
				esc_html__( 'Azerbaijani manat', 'bakery-shortcodes' ) => 'AZN',
				esc_html__( 'Bosnia and Herzegovina convertible mark', 'bakery-shortcodes' ) => 'BAM',
				esc_html__( 'Barbadian dollar', 'bakery-shortcodes' ) => 'BBD',
				esc_html__( 'Bangladeshi taka', 'bakery-shortcodes' ) => 'BDT',
				esc_html__( 'Bulgarian lev', 'bakery-shortcodes' ) => 'BGN',
				esc_html__( 'Bahraini dinar', 'bakery-shortcodes' ) => 'BHD',
				esc_html__( 'Burundian franc', 'bakery-shortcodes' ) => 'BIF',
				esc_html__( 'Bermudian dollar', 'bakery-shortcodes' ) => 'BMD',
				esc_html__( 'Brunei dollar', 'bakery-shortcodes' ) => 'BND',
				esc_html__( 'Bolivian boliviano', 'bakery-shortcodes' ) => 'BOB',
				esc_html__( 'Brazilian real', 'bakery-shortcodes' ) => 'BRL',
				esc_html__( 'Bahamian dollar', 'bakery-shortcodes' ) => 'BSD',
				esc_html__( 'Bitcoin', 'bakery-shortcodes' ) => 'BTC',
				esc_html__( 'Bhutanese ngultrum', 'bakery-shortcodes' ) => 'BTN',
				esc_html__( 'Botswana pula', 'bakery-shortcodes' ) => 'BWP',
				esc_html__( 'Belarusian ruble (old)', 'bakery-shortcodes' ) => 'BYR',
				esc_html__( 'Belarusian ruble', 'bakery-shortcodes' ) => 'BYN',
				esc_html__( 'Belize dollar', 'bakery-shortcodes' ) => 'BZD',
				esc_html__( 'Canadian dollar', 'bakery-shortcodes' ) => 'CAD',
				esc_html__( 'Congolese franc', 'bakery-shortcodes' ) => 'CDF',
				esc_html__( 'Swiss franc', 'bakery-shortcodes' ) => 'CHF',
				esc_html__( 'Chilean peso', 'bakery-shortcodes' ) => 'CLP',
				esc_html__( 'Chinese yuan', 'bakery-shortcodes' ) => 'CNY',
				esc_html__( 'Colombian peso', 'bakery-shortcodes' ) => 'COP',
				esc_html__( 'Costa Rican col&oacute;n', 'bakery-shortcodes' ) => 'CRC',
				esc_html__( 'Cuban convertible peso', 'bakery-shortcodes' ) => 'CUC',
				esc_html__( 'Cuban peso', 'bakery-shortcodes' ) => 'CUP',
				esc_html__( 'Cape Verdean escudo', 'bakery-shortcodes' ) => 'CVE',
				esc_html__( 'Czech koruna', 'bakery-shortcodes' ) => 'CZK',
				esc_html__( 'Djiboutian franc', 'bakery-shortcodes' ) => 'DJF',
				esc_html__( 'Danish krone', 'bakery-shortcodes' ) => 'DKK',
				esc_html__( 'Dominican peso', 'bakery-shortcodes' ) => 'DOP',
				esc_html__( 'Algerian dinar', 'bakery-shortcodes' ) => 'DZD',
				esc_html__( 'Egyptian pound', 'bakery-shortcodes' ) => 'EGP',
				esc_html__( 'Eritrean nakfa', 'bakery-shortcodes' ) => 'ERN',
				esc_html__( 'Ethiopian birr', 'bakery-shortcodes' ) => 'ETB',
				esc_html__( 'Euro', 'bakery-shortcodes' ) => 'EUR',
				esc_html__( 'Fijian dollar', 'bakery-shortcodes' ) => 'FJD',
				esc_html__( 'Falkland Islands pound', 'bakery-shortcodes' ) => 'FKP',
				esc_html__( 'Pound sterling', 'bakery-shortcodes' ) => 'GBP',
				esc_html__( 'Georgian lari', 'bakery-shortcodes' ) => 'GEL',
				esc_html__( 'Guernsey pound', 'bakery-shortcodes' ) => 'GGP',
				esc_html__( 'Ghana cedi', 'bakery-shortcodes' ) => 'GHS',
				esc_html__( 'Gibraltar pound', 'bakery-shortcodes' ) => 'GIP',
				esc_html__( 'Gambian dalasi', 'bakery-shortcodes' ) => 'GMD',
				esc_html__( 'Guinean franc', 'bakery-shortcodes' ) => 'GNF',
				esc_html__( 'Guatemalan quetzal', 'bakery-shortcodes' ) => 'GTQ',
				esc_html__( 'Guyanese dollar', 'bakery-shortcodes' ) => 'GYD',
				esc_html__( 'Hong Kong dollar', 'bakery-shortcodes' ) => 'HKD',
				esc_html__( 'Honduran lempira', 'bakery-shortcodes' ) => 'HNL',
				esc_html__( 'Croatian kuna', 'bakery-shortcodes' ) => 'HRK',
				esc_html__( 'Haitian gourde', 'bakery-shortcodes' ) => 'HTG',
				esc_html__( 'Hungarian forint', 'bakery-shortcodes' ) => 'HUF',
				esc_html__( 'Indonesian rupiah', 'bakery-shortcodes' ) => 'IDR',
				esc_html__( 'Israeli new shekel', 'bakery-shortcodes' ) => 'ILS',
				esc_html__( 'Manx pound', 'bakery-shortcodes' ) => 'IMP',
				esc_html__( 'Indian rupee', 'bakery-shortcodes' ) => 'INR',
				esc_html__( 'Iraqi dinar', 'bakery-shortcodes' ) => 'IQD',
				esc_html__( 'Iranian rial', 'bakery-shortcodes' ) => 'IRR',
				esc_html__( 'Iranian toman', 'bakery-shortcodes' ) => 'IRT',
				esc_html__( 'Icelandic kr&oacute;na', 'bakery-shortcodes' ) => 'ISK',
				esc_html__( 'Jersey pound', 'bakery-shortcodes' ) => 'JEP',
				esc_html__( 'Jamaican dollar', 'bakery-shortcodes' ) => 'JMD',
				esc_html__( 'Jordanian dinar', 'bakery-shortcodes' ) => 'JOD',
				esc_html__( 'Japanese yen', 'bakery-shortcodes' ) => 'JPY',
				esc_html__( 'Kenyan shilling', 'bakery-shortcodes' ) => 'KES',
				esc_html__( 'Kyrgyzstani som', 'bakery-shortcodes' ) => 'KGS',
				esc_html__( 'Cambodian riel', 'bakery-shortcodes' ) => 'KHR',
				esc_html__( 'Comorian franc', 'bakery-shortcodes' ) => 'KMF',
				esc_html__( 'North Korean won', 'bakery-shortcodes' ) => 'KPW',
				esc_html__( 'South Korean won', 'bakery-shortcodes' ) => 'KRW',
				esc_html__( 'Kuwaiti dinar', 'bakery-shortcodes' ) => 'KWD',
				esc_html__( 'Cayman Islands dollar', 'bakery-shortcodes' ) => 'KYD',
				esc_html__( 'Kazakhstani tenge', 'bakery-shortcodes' ) => 'KZT',
				esc_html__( 'Lao kip', 'bakery-shortcodes' ) => 'LAK',
				esc_html__( 'Lebanese pound', 'bakery-shortcodes' ) => 'LBP',
				esc_html__( 'Sri Lankan rupee', 'bakery-shortcodes' ) => 'LKR',
				esc_html__( 'Liberian dollar', 'bakery-shortcodes' ) => 'LRD',
				esc_html__( 'Lesotho loti', 'bakery-shortcodes' ) => 'LSL',
				esc_html__( 'Libyan dinar', 'bakery-shortcodes' ) => 'LYD',
				esc_html__( 'Moroccan dirham', 'bakery-shortcodes' ) => 'MAD',
				esc_html__( 'Moldovan leu', 'bakery-shortcodes' ) => 'MDL',
				esc_html__( 'Malagasy ariary', 'bakery-shortcodes' ) => 'MGA',
				esc_html__( 'Macedonian denar', 'bakery-shortcodes' ) => 'MKD',
				esc_html__( 'Burmese kyat', 'bakery-shortcodes' ) => 'MMK',
				esc_html__( 'Mongolian t&ouml;gr&ouml;g', 'bakery-shortcodes' ) => 'MNT',
				esc_html__( 'Macanese pataca', 'bakery-shortcodes' ) => 'MOP',
				esc_html__( 'Mauritanian ouguiya', 'bakery-shortcodes' ) => 'MRU',
				esc_html__( 'Mauritian rupee', 'bakery-shortcodes' ) => 'MUR',
				esc_html__( 'Maldivian rufiyaa', 'bakery-shortcodes' ) => 'MVR',
				esc_html__( 'Malawian kwacha', 'bakery-shortcodes' ) => 'MWK',
				esc_html__( 'Mexican peso', 'bakery-shortcodes' ) => 'MXN',
				esc_html__( 'Malaysian ringgit', 'bakery-shortcodes' ) => 'MYR',
				esc_html__( 'Mozambican metical', 'bakery-shortcodes' ) => 'MZN',
				esc_html__( 'Namibian dollar', 'bakery-shortcodes' ) => 'NAD',
				esc_html__( 'Nigerian naira', 'bakery-shortcodes' ) => 'NGN',
				esc_html__( 'Nicaraguan c&oacute;rdoba', 'bakery-shortcodes' ) => 'NIO',
				esc_html__( 'Norwegian krone', 'bakery-shortcodes' ) => 'NOK',
				esc_html__( 'Nepalese rupee', 'bakery-shortcodes' ) => 'NPR',
				esc_html__( 'New Zealand dollar', 'bakery-shortcodes' ) => 'NZD',
				esc_html__( 'Omani rial', 'bakery-shortcodes' ) => 'OMR',
				esc_html__( 'Panamanian balboa', 'bakery-shortcodes' ) => 'PAB',
				esc_html__( 'Sol', 'bakery-shortcodes' ) => 'PEN',
				esc_html__( 'Papua New Guinean kina', 'bakery-shortcodes' ) => 'PGK',
				esc_html__( 'Philippine peso', 'bakery-shortcodes' ) => 'PHP',
				esc_html__( 'Pakistani rupee', 'bakery-shortcodes' ) => 'PKR',
				esc_html__( 'Polish z&#x142;oty', 'bakery-shortcodes' ) => 'PLN',
				esc_html__( 'Transnistrian ruble', 'bakery-shortcodes' ) => 'PRB',
				esc_html__( 'Paraguayan guaran&iacute;', 'bakery-shortcodes' ) => 'PYG',
				esc_html__( 'Qatari riyal', 'bakery-shortcodes' ) => 'QAR',
				esc_html__( 'Romanian leu', 'bakery-shortcodes' ) => 'RON',
				esc_html__( 'Serbian dinar', 'bakery-shortcodes' ) => 'RSD',
				esc_html__( 'Russian ruble', 'bakery-shortcodes' ) => 'RUB',
				esc_html__( 'Rwandan franc', 'bakery-shortcodes' ) => 'RWF',
				esc_html__( 'Saudi riyal', 'bakery-shortcodes' ) => 'SAR',
				esc_html__( 'Solomon Islands dollar', 'bakery-shortcodes' ) => 'SBD',
				esc_html__( 'Seychellois rupee', 'bakery-shortcodes' ) => 'SCR',
				esc_html__( 'Sudanese pound', 'bakery-shortcodes' ) => 'SDG',
				esc_html__( 'Swedish krona', 'bakery-shortcodes' ) => 'SEK',
				esc_html__( 'Singapore dollar', 'bakery-shortcodes' ) => 'SGD',
				esc_html__( 'Saint Helena pound', 'bakery-shortcodes' ) => 'SHP',
				esc_html__( 'Sierra Leonean leone', 'bakery-shortcodes' ) => 'SLL',
				esc_html__( 'Somali shilling', 'bakery-shortcodes' ) => 'SOS',
				esc_html__( 'Surinamese dollar', 'bakery-shortcodes' ) => 'SRD',
				esc_html__( 'South Sudanese pound', 'bakery-shortcodes' ) => 'SSP',
				esc_html__( 'S&atilde;o Tom&eacute; and Pr&iacute;ncipe dobra', 'bakery-shortcodes' ) => 'STN',
				esc_html__( 'Syrian pound', 'bakery-shortcodes' ) => 'SYP',
				esc_html__( 'Swazi lilangeni', 'bakery-shortcodes' ) => 'SZL',
				esc_html__( 'Thai baht', 'bakery-shortcodes' ) => 'THB',
				esc_html__( 'Tajikistani somoni', 'bakery-shortcodes' ) => 'TJS',
				esc_html__( 'Turkmenistan manat', 'bakery-shortcodes' ) => 'TMT',
				esc_html__( 'Tunisian dinar', 'bakery-shortcodes' ) => 'TND',
				esc_html__( 'Tongan pa&#x2bb;anga', 'bakery-shortcodes' ) => 'TOP',
				esc_html__( 'Turkish lira', 'bakery-shortcodes' ) => 'TRY',
				esc_html__( 'Trinidad and Tobago dollar', 'bakery-shortcodes' ) => 'TTD',
				esc_html__( 'New Taiwan dollar', 'bakery-shortcodes' ) => 'TWD',
				esc_html__( 'Tanzanian shilling', 'bakery-shortcodes' ) => 'TZS',
				esc_html__( 'Ukrainian hryvnia', 'bakery-shortcodes' ) => 'UAH',
				esc_html__( 'Ugandan shilling', 'bakery-shortcodes' ) => 'UGX',
				esc_html__( 'United States (US) dollar', 'bakery-shortcodes' ) => 'USD',
				esc_html__( 'Uruguayan peso', 'bakery-shortcodes' ) => 'UYU',
				esc_html__( 'Uzbekistani som', 'bakery-shortcodes' ) => 'UZS',
				esc_html__( 'Venezuelan bol&iacute;var (2008–2018)', 'bakery-shortcodes' ) => 'VEF',
				esc_html__( 'Venezuelan bol&iacute;var', 'bakery-shortcodes' ) => 'VES',
				esc_html__( 'Vietnamese &#x111;&#x1ed3;ng', 'bakery-shortcodes' ) => 'VND',
				esc_html__( 'Vanuatu vatu', 'bakery-shortcodes' ) => 'VUV',
				esc_html__( 'Samoan t&#x101;l&#x101;', 'bakery-shortcodes' ) => 'WST',
				esc_html__( 'Central African CFA franc', 'bakery-shortcodes' ) => 'XAF',
				esc_html__( 'East Caribbean dollar', 'bakery-shortcodes' ) => 'XCD',
				esc_html__( 'West African CFA franc', 'bakery-shortcodes' ) => 'XOF',
				esc_html__( 'CFP franc', 'bakery-shortcodes' ) => 'XPF',
				esc_html__( 'Yemeni rial', 'bakery-shortcodes' ) => 'YER',
				esc_html__( 'South African rand', 'bakery-shortcodes' ) => 'ZAR',
				esc_html__( 'Zambian kwacha', 'bakery-shortcodes' ) => 'ZMW'
			)
		);
	}
}

// Get currency symbol
if ( ! function_exists( 'bakery_get_currency_symbol' ) ) {
	function bakery_get_currency_symbol( $currency ) {
		//https://woocommerce.github.io/code-reference/files/woocommerce-includes-wc-core-functions.html#source-view.662
		$currency_symbols = array( 'AED' => '&#x62f;.&#x625;', 'AFN' => '&#x60b;', 'ALL' => 'L', 'AMD' => 'AMD', 'ANG' => '&fnof;', 'AOA' => 'Kz', 'ARS' => '&#36;', 'AUD' => '&#36;', 'AWG' => 'Afl.', 'AZN' => '&#8380;', 'BAM' => 'KM', 'BBD' => '&#36;', 'BDT' => '&#2547;&nbsp;', 'BGN' => '&#1083;&#1074;.', 'BHD' => '.&#x62f;.&#x628;', 'BIF' => 'Fr', 'BMD' => '&#36;', 'BND' => '&#36;', 'BOB' => 'Bs.', 'BRL' => '&#82;&#36;', 'BSD' => '&#36;', 'BTC' => '&#3647;', 'BTN' => 'Nu.', 'BWP' => 'P', 'BYR' => 'Br', 'BYN' => 'Br', 'BZD' => '&#36;', 'CAD' => '&#36;', 'CDF' => 'Fr', 'CHF' => '&#67;&#72;&#70;', 'CLP' => '&#36;', 'CNY' => '&yen;', 'COP' => '&#36;', 'CRC' => '&#x20a1;', 'CUC' => '&#36;', 'CUP' => '&#36;', 'CVE' => '&#36;', 'CZK' => '&#75;&#269;', 'DJF' => 'Fr', 'DKK' => 'kr.', 'DOP' => 'RD&#36;', 'DZD' => '&#x62f;.&#x62c;', 'EGP' => 'EGP', 'ERN' => 'Nfk', 'ETB' => 'Br', 'EUR' => '&euro;', 'FJD' => '&#36;', 'FKP' => '&pound;', 'GBP' => '&pound;', 'GEL' => '&#x20be;', 'GGP' => '&pound;', 'GHS' => '&#x20b5;', 'GIP' => '&pound;', 'GMD' => 'D', 'GNF' => 'Fr', 'GTQ' => 'Q', 'GYD' => '&#36;', 'HKD' => '&#36;', 'HNL' => 'L', 'HRK' => 'kn', 'HTG' => 'G', 'HUF' => '&#70;&#116;', 'IDR' => 'Rp', 'ILS' => '&#8362;', 'IMP' => '&pound;', 'INR' => '&#8377;', 'IQD' => '&#x62f;.&#x639;', 'IRR' => '&#xfdfc;', 'IRT' => '&#x062A;&#x0648;&#x0645;&#x0627;&#x0646;', 'ISK' => 'kr.', 'JEP' => '&pound;', 'JMD' => '&#36;', 'JOD' => '&#x62f;.&#x627;', 'JPY' => '&yen;', 'KES' => 'KSh', 'KGS' => '&#x441;&#x43e;&#x43c;', 'KHR' => '&#x17db;', 'KMF' => 'Fr', 'KPW' => '&#x20a9;', 'KRW' => '&#8361;', 'KWD' => '&#x62f;.&#x643;', 'KYD' => '&#36;', 'KZT' => '&#8376;', 'LAK' => '&#8365;', 'LBP' => '&#x644;.&#x644;', 'LKR' => '&#xdbb;&#xdd4;', 'LRD' => '&#36;', 'LSL' => 'L', 'LYD' => '&#x62f;.&#x644;', 'MAD' => '&#x62f;.&#x645;.', 'MDL' => 'MDL', 'MGA' => 'Ar', 'MKD' => '&#x434;&#x435;&#x43d;', 'MMK' => 'Ks', 'MNT' => '&#x20ae;', 'MOP' => 'P', 'MRU' => 'UM', 'MUR' => '&#x20a8;', 'MVR' => '.&#x783;', 'MWK' => 'MK', 'MXN' => '&#36;', 'MYR' => '&#82;&#77;', 'MZN' => 'MT', 'NAD' => 'N&#36;', 'NGN' => '&#8358;', 'NIO' => 'C&#36;', 'NOK' => '&#107;&#114;', 'NPR' => '&#8360;', 'NZD' => '&#36;', 'OMR' => '&#x631;.&#x639;.', 'PAB' => 'B/.', 'PEN' => 'S/', 'PGK' => 'K', 'PHP' => '&#8369;', 'PKR' => '&#8360;', 'PLN' => '&#122;&#322;', 'PRB' => '&#x440;.', 'PYG' => '&#8370;', 'QAR' => '&#x631;.&#x642;', 'RMB' => '&yen;', 'RON' => 'lei', 'RSD' => '&#1088;&#1089;&#1076;', 'RUB' => '&#8381;', 'RWF' => 'Fr', 'SAR' => '&#x631;.&#x633;', 'SBD' => '&#36;', 'SCR' => '&#x20a8;', 'SDG' => '&#x62c;.&#x633;.', 'SEK' => '&#107;&#114;', 'SGD' => '&#36;', 'SHP' => '&pound;', 'SLL' => 'Le', 'SOS' => 'Sh', 'SRD' => '&#36;', 'SSP' => '&pound;', 'STN' => 'Db', 'SYP' => '&#x644;.&#x633;', 'SZL' => 'E', 'THB' => '&#3647;', 'TJS' => '&#x405;&#x41c;', 'TMT' => 'm', 'TND' => '&#x62f;.&#x62a;', 'TOP' => 'T&#36;', 'TRY' => '&#8378;', 'TTD' => '&#36;', 'TWD' => '&#78;&#84;&#36;', 'TZS' => 'Sh', 'UAH' => '&#8372;', 'UGX' => 'UGX', 'USD' => '&#36;', 'UYU' => '&#36;', 'UZS' => 'UZS', 'VEF' => 'Bs F', 'VES' => 'Bs.', 'VND' => '&#8363;', 'VUV' => 'Vt', 'WST' => 'T', 'XAF' => 'CFA', 'XCD' => '&#36;', 'XOF' => 'CFA', 'XPF' => 'XPF', 'YER' => '&#xfdfc;', 'ZAR' => '&#82;', 'ZMW' => 'ZK' );

		return ( isset( $currency_symbols[ $currency ] ) ) ? $currency_symbols[ $currency ] : null;
	}
}

// Get Booked Calendars
if ( ! function_exists( 'bakery_get_booked_calendars' ) ) {
	function bakery_get_booked_calendars() {
		$calendars = get_terms( 'booked_custom_calendars', 'orderby=slug&hide_empty=0' );

		$return = array(
			esc_html__( 'Default Calendar', 'bakery-shortcodes' ) => false
		);

		if ( ! empty( $calendars) && ! is_wp_error( $calendars ) ) {
			foreach ( $calendars as $calendar ) {
				$return[ $calendar->name ] = $calendar->term_id;
			}
		}

		return $return;
	}
}
