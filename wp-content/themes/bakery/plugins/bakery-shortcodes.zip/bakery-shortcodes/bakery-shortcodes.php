<?php 
/*
	Plugin Name: Bakery Shortcodes
	Plugin URI: http://milingona.co/
	Author: Milingona
	Author URI: http://themeforest.net/user/milingona_
	Description: This plugin is required in order for the theme to work properly. It includes various shortcodes that have been developed exclusively for this theme.
	Version: 2.8.1
	Text Domain: bakery-shortcodes
	Domain Path: /languages
	License: GNU General Public License v2.0
	License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/

if ( ! defined( 'ABSPATH' ) ) exit();

// Check if purchase code is valid or current theme is 'bakery'
$bakery_purchase_code = get_option( 'envato_purchase_code_11112118', '' );
$bakery_purchase_code = $bakery_purchase_code ?? get_option( '_bakery_theme_license', '' );
$bakery_theme_info = json_decode( get_option( '_bakery_theme_info', '', true ), true );

if ( empty( $bakery_purchase_code ) || strlen( $bakery_purchase_code ) != 36 || ( ! isset( $bakery_theme_info['name'] ) && $bakery_theme_info['name'] != 'bakery' ) ) {
	return;
}

if ( ! class_exists( 'Bakery_Shortcodes' ) ) {
	class Bakery_Shortcodes {
		public static $_version = '2.8.1';
		public static $_dir;
		public static $_url;
		
		public function __construct() {
			// Variables
			self::$_dir = plugin_dir_path( __FILE__ );
			self::$_url = plugin_dir_url( __FILE__ );

			// Functions
			require_once( self::$_dir . 'helpers.php' );
			require_once( self::$_dir . 'functions.php' );

			// Library Files
			require_once( self::$_dir . 'lib/twitter/ezTweet.php' );
			require_once( self::$_dir . 'lib/BakeryVcLoopQueryBuilder.php' );

			// Actions
			add_action( 'init', array( $this, 'load_plugin_textdomain' ) );
			add_action( 'plugins_loaded', array( $this, 'shortcodes' ) );

			add_action( 'wpcf7_init', array( $this, 'wpcf7_init' ) );

			add_action( 'wp_ajax_bakery_get_cf7', array( $this, 'get_cf7' ) );
			add_action( 'wp_ajax_bakery_get_mc4wp', array( $this, 'get_mc4wp' ) );

			add_action( 'wp_ajax_bakery_get_wc_products', array( $this, 'get_wc_products' ) );
			add_action( 'wp_ajax_bakery_get_wc_categories', array( $this, 'get_wc_categories' ) );

			// Filters
			add_filter( 'wpcf7_mail_components', array( $this, 'wpcf7_mail_components' ) );
		}

		// Plugin Textdomain
		public function load_plugin_textdomain() {
			load_plugin_textdomain( 'bakery-shortcodes', false, self::$_dir . 'languages/' );
		}

		// Shortcodes
		public function shortcodes() {
			require_once( self::$_dir . 'shortcodes/heading.php' );
			require_once( self::$_dir . 'shortcodes/special-offer.php' );
			require_once( self::$_dir . 'shortcodes/special-offer-item.php' );
			require_once( self::$_dir . 'shortcodes/product.php' );
			require_once( self::$_dir . 'shortcodes/icon-box.php' );
			require_once( self::$_dir . 'shortcodes/image-box.php' );
			require_once( self::$_dir . 'shortcodes/before-after.php' );
			require_once( self::$_dir . 'shortcodes/animated-svg.php' );
			require_once( self::$_dir . 'shortcodes/pie-chart.php' );
			require_once( self::$_dir . 'shortcodes/blog.php' );
			require_once( self::$_dir . 'shortcodes/counter.php' );
			require_once( self::$_dir . 'shortcodes/filterable.php' );
			require_once( self::$_dir . 'shortcodes/filterable-item.php' );
			require_once( self::$_dir . 'shortcodes/gallery.php' );
			require_once( self::$_dir . 'shortcodes/gallery-item.php' );
			require_once( self::$_dir . 'shortcodes/social-networks.php' );
			require_once( self::$_dir . 'shortcodes/video-section.php' );
			require_once( self::$_dir . 'shortcodes/map.php' );
			require_once( self::$_dir . 'shortcodes/mailchimp-form.php' );
			require_once( self::$_dir . 'shortcodes/contact-form-7.php' );
			require_once( self::$_dir . 'shortcodes/order-form.php' );
			require_once( self::$_dir . 'shortcodes/team-member.php' );
			require_once( self::$_dir . 'shortcodes/testimonial.php' );
			require_once( self::$_dir . 'shortcodes/timeline.php' );
			require_once( self::$_dir . 'shortcodes/countdown.php' );
			require_once( self::$_dir . 'shortcodes/progress-bar.php' );
			require_once( self::$_dir . 'shortcodes/client.php' );
			require_once( self::$_dir . 'shortcodes/pricing-table.php' );
			require_once( self::$_dir . 'shortcodes/menu-item.php' );
			require_once( self::$_dir . 'shortcodes/call-to-action.php' );
			require_once( self::$_dir . 'shortcodes/separator.php' );
			require_once( self::$_dir . 'shortcodes/image-slider.php' );
			require_once( self::$_dir . 'shortcodes/carousel.php' );
			require_once( self::$_dir . 'shortcodes/carousel-item.php' );
			require_once( self::$_dir . 'shortcodes/button.php' );
			require_once( self::$_dir . 'shortcodes/share-buttons.php' );
			require_once( self::$_dir . 'shortcodes/breadcrumb.php' );
			require_once( self::$_dir . 'shortcodes/others.php' );

			// WC Shortcodes
			if ( class_exists('WooCommerce') ) {
				require_once( self::$_dir . 'shortcodes/wc-categories.php' );
				require_once( self::$_dir . 'shortcodes/wc-products.php' );
				require_once( self::$_dir . 'shortcodes/wc-product.php' );
				require_once( self::$_dir . 'shortcodes/wc-special-offer.php' );
				require_once( self::$_dir . 'shortcodes/wc-special-offer-item.php' );
			}
		}

		// CF7 Init
		public function wpcf7_init() {
			remove_action( 'wpcf7_swv_create_schema', 'wpcf7_swv_add_select_enum_rules', 20, 2 );
		}

		// Get Contact Forms 7
		public function get_cf7() {
			$resposne = array();

			if ( ! empty( $_REQUEST['selected'] ) ) {
				$selected = @explode( ',', $_REQUEST['selected'] );
			} else {
				$selected = array();
			}

			$args = array(
				'post_type' => 'wpcf7_contact_form',
				'post_status' => 'publish',
				'posts_per_page' => -1
			);

			$cf7_loop = new WP_Query( $args );

			if ( $cf7_loop->have_posts() ) {
				while ( $cf7_loop->have_posts() ) : $cf7_loop->the_post();
					array_push( $resposne, array( 'id' => get_the_ID(), 'text' => get_the_title(), 'selected' => ( ( array_search( get_the_ID(), $selected ) !== false ) ? true : false ) ) );
				endwhile;
			}

			wp_reset_postdata();

			echo json_encode( $resposne ); exit();
		}

		// Get MailChimp Forms
		public function get_mc4wp() {
			$resposne = array();

			if ( ! empty( $_REQUEST['selected'] ) ) {
				$selected = @explode( ',', $_REQUEST['selected'] );
			} else {
				$selected = array();
			}

			$args = array(
				'post_type' => 'mc4wp-form',
				'post_status' => 'publish',
				'posts_per_page' => -1
			);

			$mc4wp_loop = new WP_Query( $args );

			if ( $mc4wp_loop->have_posts() ) {
				while ( $mc4wp_loop->have_posts() ) : $mc4wp_loop->the_post();
					array_push( $resposne, array( 'id' => get_the_ID(), 'text' => get_the_title(), 'selected' => ( ( array_search( get_the_ID(), $selected ) !== false ) ? true : false ) ) );
				endwhile;
			}

			wp_reset_postdata();

			echo json_encode( $resposne ); exit();
		}

		// Order Form
		public function wpcf7_mail_components( $components ) {
			if ( isset( $_POST['vu_of-products-selected'] ) && ! empty( $_POST['vu_of-products-selected'] ) && isset( $_POST['vu_of-products-json'] ) && ! empty( $_POST['vu_of-products-json'] ) ) {
				$selected = @explode( ',', $_POST['vu_of-products-selected'] );

				if ( is_array( $selected ) && ! empty( $selected ) ) {
					$products_text = '';
					$currency = '';
					$total = 0;
					$products = @json_decode( stripslashes( $_POST['vu_of-products-json'] ), true );

					if ( is_array( $products ) && ! empty( $products ) ) {
						foreach ( $products as $key => $product ) {
							if ( in_array( $product['id'], $selected ) ) {
								if ( empty( $product['quantity'] ) ) {
									$product['quantity'] = 1;
								}

								$amount = $product['price'] * $product['quantity'];
								$currency = $product['currency'];

								$products_text .= $product['name'] . ' : ' . $product['currency'] . $product['price'] . ' x ' . $product['quantity'] . ' = ' . $product['currency'] . number_format( $amount, 2 ) . "\n";

								$total += $amount;
							}
						}
					}

					$products_text .= "--------------------------------\n";
					$products_text .= 'Total: ' . $currency . number_format( $total, 2 ) . "\n";

					$components['body'] = str_replace( '[vu_of_products]', $products_text, $components['body'] );
				}
			}

			return $components;
		}

		// Get WC Categories
		public function get_wc_categories() {
			$resposne = array();

			if ( ! empty( $_REQUEST['selected'] ) ) {
				$selected = @explode( ',', $_REQUEST['selected'] );
			} else {
				$selected = array();
			}

			$args = array(
				'taxonomy' => 'product_cat',
				'hide_empty' => true,
				'orderby' => 'none',
				'fields' => 'all',
				'hierarchical' => false
			);

			$wc_categories = get_terms( $args );

			if ( $wc_categories && ! is_wp_error( $wc_categories ) ) {
				foreach ( $wc_categories as $wc_category ) {
					array_push( $resposne, array( 'id' => $wc_category->term_id, 'text' => $wc_category->name, 'selected' => ( ( array_search( $wc_category->term_id, $selected ) !== false ) ? true : false ) ) );
				}
			}

			echo json_encode( $resposne ); exit();
		}

		// Get WC Products
		public function get_wc_products() {
			$resposne = array();

			if ( ! empty( $_REQUEST['selected'] ) ) {
				$selected = @explode( ',', $_REQUEST['selected'] );
			} else {
				$selected = array();
			}

			$args = array(
				'post_type' => 'product',
				'post_status' => 'publish',
				'posts_per_page' => -1
			);

			$wc_products_loop = new WP_Query( $args );

			if ( $wc_products_loop->have_posts() ) {
				while ( $wc_products_loop->have_posts() ) : $wc_products_loop->the_post();
					array_push( $resposne, array( 'id' => get_the_ID(), 'text' => get_the_title(), 'selected' => ( ( array_search( get_the_ID(), $selected ) !== false ) ? true : false ) ) );
				endwhile;
			}

			wp_reset_postdata();

			echo json_encode( $resposne ); exit();
		}
	}
}

$Bakery_Shortcodes = new Bakery_Shortcodes();
