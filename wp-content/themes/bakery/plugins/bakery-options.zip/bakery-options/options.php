<?php if ( ! defined( 'ABSPATH' ) ) exit();

if ( ! class_exists( 'Redux_Framework_Bakery_Options' ) ) {
	class Redux_Framework_Bakery_Options {
		public $args = array();
		public $sections = array();
		public $theme;
		public $ReduxFramework;

		public function __construct() {
			if ( ! class_exists( 'ReduxFramework' ) ) {
				return;
			}

			if ( true == Redux_Helpers::is_theme( __FILE__ ) ) {
				$this->init_settings();
			} else {
				add_action( 'plugins_loaded', array( $this, 'init_settings' ), 10 );
			}
		}

		private function check_theme_license() {
			$bakery_purchase_code = get_option( 'envato_purchase_code_11112118', '', true );
			$bakery_purchase_code = $bakery_purchase_code ?? get_option( '_bakery_theme_license', '', true );

			if ( ! empty( $bakery_purchase_code ) && strlen( $bakery_purchase_code ) == 36 ) {
				return true;
			}

			return false;
		}

		public function init_settings() {
			$this->theme = wp_get_theme();

			$this->set_arguments();

			$this->set_sections();

			if ( ! isset( $this->args['opt_name'] ) ) {
				return;
			}

			$this->ReduxFramework = new ReduxFramework( $this->sections, $this->args );
		}

		public function set_sections() {
			ob_start(); ?>

			<div>
				<p class="item-uri">
					<strong><?php echo esc_html__( 'Theme URL', 'bakery-options' ); ?>: </strong>
					<a href="<?php echo esc_url( $this->theme->get( 'ThemeURI' ) ); ?>" target="_blank"><?php echo $this->theme->get( 'Name' ); ?></a>
				</p>

				<p class="item-author">
					<strong><?php echo esc_html__( 'Author', 'bakery-options' ); ?>: </strong>
					<a href="<?php echo esc_url( $this->theme->get( 'AuthorURI' ) ); ?>" target="_blank"><?php echo $this->theme->get( 'Author' ); ?></a>
				</p>

				<p class="item-version">
					<strong><?php echo esc_html__( 'Version', 'bakery-options' ); ?>: <?php echo $this->theme->get( 'Version' ); ?></strong>
				</p>

				<p class="item-tags">
					<strong><?php echo esc_html__( 'Tags', 'bakery-options' ); ?>: </strong>
					<?php echo @implode( ', ', $this->theme->get( 'Tags' ) ); ?>
				</p>

				<div style="margin-top: 30px;">
					<h3><?php echo esc_html__( 'Documentation', 'bakery-options' ); ?></h3>
				</div>
				
				<div class="redux-section-desc">
					<p>Please refer to documentation file found in main theme folder for more instructions on how to use the theme.</p><br>
				</div>

				<div style="margin-top: 30px;">
					<h3><?php echo esc_html__( 'Support', 'bakery-options' ); ?></h3>
				</div>
				
				<div class="redux-section-desc">
					<p>If you have any questions that are beyond the scope of the documentation, please don't hesitate to submit a ticket to <a href="https://milingona.ticksy.com" target="_blank">support center</a>.</p><br>
				</div>

				<div style="margin-top: 30px;">
					<h3><?php echo esc_html__( 'Thank you!', 'bakery-options' ); ?></h3>
				</div>
				
				<div class="redux-section-desc">
					<p>Last but not least, thank you very much for choosing Bakery! We've done our best to make it fast, flexible and powerful, while keeping it incredibly easy and slick to use. If you like this theme, please support us by <a href="https://d.pr/KaOuM0" target="_blank">leaving a 5 star rating</a> on Themeforest.</p><br>
				</div>
			</div>

			<?php 
			$theme_info = ob_get_clean();

			//General
			$this->sections[] = array(
				'title'  => esc_html__( 'General', 'bakery-options' ),
				'icon'   => 'fa-solid fa-rectangle-list',
				'fields' => array(
					array(
						'id'       => 'logo-dark',
						'type'     => 'media',
						'title'    => esc_html__( 'Logo', 'bakery-options' ),
						'desc'     => esc_html__( 'Add a custom logo for your site.', 'bakery-options' ),
						'url'      => false,
						'default'  => array(
							'url' => get_template_directory_uri() .'/assets/img/bakery-logo-dark.png',
							'width' => '1000',
							'height' => '1000'
						)
					),
					array(
						'id'       => 'logo-light',
						'type'     => 'media',
						'title'    => esc_html__( 'Inverted Logo', 'bakery-options' ),
						'desc'     => esc_html__( 'Add a logo version for use on dark backgrounds.', 'bakery-options' ),
						'url'      => false,
						'default'  => array(
							'url' => get_template_directory_uri() .'/assets/img/bakery-logo-light.png',
							'width' => '1000',
							'height' => '1000'
						)
					),
					array(
						'id'       => 'logo-width',
						'type'     => 'slider',
						'title'    => esc_html__( 'Logo Container Width', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter logo container width in pixels.', 'bakery-options' ),
						'min'      => 50,
						'max'      => 500,
						'step'      => 1,
						'default'  => 130
					),
					array(
						'id'       => 'gutenberg-editor',
						'type'     => 'switch',
						'title'    => esc_html__( 'Gutenberg Editor', 'bakery-options' ),
						'desc'     => esc_html__( 'Turn on to disable Gutenberg Editor.', 'bakery-options' ),
						'on'       => esc_html__( 'On', 'bakery-options' ),
						'off'      => esc_html__( 'Off', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'preloader',
						'type'     => 'switch',
						'title'    => esc_html__( 'Preloader', 'bakery-options' ),
						'desc'     => esc_html__( 'Show preloader while page content is loading.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'preloader-image',
						'type'     => 'media',
						'required' => array( 'preloader', '=', true ),
						'title'    => esc_html__( 'Preloader image', 'bakery-options' ),
						'desc'     => esc_html__( 'Add a custom loading image.', 'bakery-options' ),
						'url'      => false,
						'default'  => array(
							'url' => get_template_directory_uri() .'/assets/img/preloader.svg'
						)
					),
					array(
						'id'       => 'site-mode',
						'type'     => 'button_set',
						'title'    => esc_html__( 'Site Mode', 'bakery-options' ),
						'desc'     => esc_html__( 'When site is \'Under Construction\', only logged in users will be able to see the site content.', 'bakery-options' ),
						'options'  => array(
							'normal' => esc_html__( 'Normal', 'bakery-options'),
							'under_construction' => esc_html__( 'Under Construction', 'bakery-options')
						),
						'default'  => 'normal'
					),
					array(
						'id'       => 'site-mode-page',
						'type'     => 'select',
						'required' => array( 'site-mode', '=', 'under_construction' ),
						'data'     => 'pages',
						'title'    => esc_html__( 'Maintenance or Coming Soon Page', 'bakery-options' ),
						'desc'     => esc_html__( 'Select maintenance or coming soon page.', 'bakery-options' ),
						'default'  => ''
					)
				)
			);
			
			//Styling
			$this->sections[] = array(
				'title'  => esc_html__( 'Styling', 'bakery-options' ),
				'icon'   => 'fa-solid fa-palette',
				'fields' => array(
					array(
						'id'       => 'primary-color',
						'type'     => 'color',
						'title'    => esc_html__( 'Primary Color', 'bakery-options' ),
						'desc'     => esc_html__( 'Select primary color of your site.', 'bakery-options' ),
						'transparent' => false,
						'validate' => 'color',
						'default'  => '#fdb822',
					),
					array(
						'id'       => 'secondary-color',
						'type'     => 'color',
						'title'    => esc_html__( 'Secondary Color', 'bakery-options' ),
						'desc'     => esc_html__( 'Select secondary color of your site.', 'bakery-options' ),
						'transparent' => false,
						'validate' => 'color',
						'default'  => '#684f40',
					),
					array(
						'id'       => 'tertiary-color',
						'type'     => 'color',
						'title'    => esc_html__( 'Tertiary Color', 'bakery-options' ),
						'desc'     => esc_html__( 'Select tertiary color of your site.', 'bakery-options' ),
						'transparent' => false,
						'validate' => 'color',
						'default'  => '#ff4800',
					),
					array(
						'id'       => 'boxed-layout',
						'type'     => 'switch',
						'title'    => esc_html__( 'Boxed Layout', 'bakery-options' ),
						'desc'     => esc_html__( 'Make your site layout boxed. If enabled you can use an image as backgroud.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'body-background',
						'type'     => 'background',
						'title'    => esc_html__( 'Background', 'bakery-options' ),
						'desc'     => esc_html__( 'Upload a large and beatiful background image for your site. This will override the background color and background pattern.', 'bakery-options' ),
						'output'   => array('body'),
						'default'  => array(
							'background-color' => '#fff'
						)
					)
				)
			);
			
			//Typography
			$this->sections[] = array(
				'title'  => esc_html__( 'Typography', 'bakery-options' ),
				'icon'   => 'fa-solid fa-font',
				'fields' => array(
					array(
						'id'          => 'body-typography',
						'type'        => 'typography', 
						'title'       => esc_html__( 'Body', 'bakery-options' ),
						'google'      => true,
						'text-align'  => false,
						'text-transform' => true,
						'all_styles'  => true,
						'units'       => 'px',
						'output'      => array('body'),
						'default'     => array(
							'font-family' => 'Open Sans',
							'font-style' => '400',
							'font-size' => '14px',
							'line-height' => '24px',
							'text-transform' => 'none',
							'color' => '#696969',
							'subsets' => 'latin'
						)
					),
					array(
						'id'          => 'nav-typography',
						'type'        => 'typography', 
						'title'       => esc_html__( 'Navigation', 'bakery-options' ),
						'google'      => true,
						'text-align'  => false,
						'text-transform' => true,
						'units'       => 'px',
						'output'      => array('.vu_main-menu > ul > li > a'),
						'default'     => array(
							'font-family' => 'Montserrat',
							'font-style' => '700',
							'font-size' => '14px',
							'line-height' => '24px',
							'text-transform' => 'uppercase',
							'color' => '#684f40',
							'subsets' => 'latin'
						)
					),
					array(
						'id'          => 'nav-submenu-typography',
						'type'        => 'typography', 
						'title'       => esc_html__( 'Navigation Submenu', 'bakery-options' ),
						'google'      => true,
						'text-align'  => false,
						'text-transform' => true,
						'units'       => 'px',
						'output'      => array('.vu_main-menu ul li ul.sub-menu li a'),
						'default'     => array(
							'font-family' => 'Montserrat',
							'font-style' => '600',
							'font-size' => '14px',
							'line-height' => '20px',
							'text-transform' => 'none',
							'color' => '#684f40',
							'subsets' => 'latin'
						)
					),
					array(
						'id'          => 'h1-typography',
						'type'        => 'typography', 
						'title'       => esc_html__( 'H1', 'bakery-options' ),
						'google'      => true,
						'text-align'  => false,
						'text-transform' => true,
						'units'       => 'px',
						'output'      => array('h1', '.h1'),
						'default'     => array(
							'font-family' => 'Montserrat',
							'font-style' => '700',
							'font-size' => '28px',
							'line-height' => '38px',
							'text-transform' => 'none',
							'color' => '#684f40',
							'subsets' => 'latin'
						)
					),
					array(
						'id'          => 'h2-typography',
						'type'        => 'typography', 
						'title'       => esc_html__( 'H2', 'bakery-options' ),
						'google'      => true,
						'text-align'  => false,
						'text-transform' => true,
						'units'       => 'px',
						'output'      => array('h2', '.h2'),
						'default'     => array(
							'font-family' => 'Montserrat',
							'font-style' => '700',
							'font-size' => '24px',
							'line-height' => '34px',
							'text-transform' => 'none',
							'color' => '#684f40',
							'subsets' => 'latin'
						)
					),
					array(
						'id'          => 'h3-typography',
						'type'        => 'typography', 
						'title'       => esc_html__( 'H3', 'bakery-options' ),
						'google'      => true,
						'text-align'  => false,
						'text-transform' => true,
						'units'       => 'px',
						'output'      => array('h3', '.h3'),
						'default'     => array(
							'font-family' => 'Montserrat',
							'font-style' => '700',
							'font-size' => '20px',
							'line-height' => '30px',
							'text-transform' => 'none',
							'color' => '#684f40',
							'subsets' => 'latin'
						)
					),
					array(
						'id'          => 'h4-typography',
						'type'        => 'typography', 
						'title'       => esc_html__( 'H4', 'bakery-options' ),
						'google'      => true,
						'text-align'  => false,
						'text-transform' => true,
						'units'       => 'px',
						'output'      => array('h4', '.h4'),
						'default'     => array(
							'font-family' => 'Montserrat',
							'font-style' => '700',
							'font-size' => '17px',
							'line-height' => '27px',
							'text-transform' => 'none',
							'color' => '#684f40',
							'subsets' => 'latin'
						)
					),
					array(
						'id'          => 'h5-typography',
						'type'        => 'typography', 
						'title'       => esc_html__( 'H5', 'bakery-options' ),
						'google'      => true,
						'text-align'  => false,
						'text-transform' => true,
						'units'       => 'px',
						'output'      => array('h5'),
						'default'     => array(
							'font-family' => 'Montserrat',
							'font-style' => '700',
							'font-size' => '16px',
							'line-height' => '26px',
							'text-transform' => 'none',
							'color' => '#684f40',
							'subsets' => 'latin'
						)
					),
					array(
						'id'          => 'h6-typography',
						'type'        => 'typography', 
						'title'       => esc_html__( 'H6', 'bakery-options' ),
						'google'      => true,
						'text-align'  => false,
						'text-transform' => true,
						'units'       => 'px',
						'output'      => array('h6'),
						'default'     => array(
							'font-family' => 'Montserrat',
							'font-style' => '700',
							'font-size' => '14px',
							'line-height' => '24px',
							'text-transform' => 'none',
							'color' => '#684f40',
							'subsets' => 'latin'
						)
					),
					array(
						'id'          => 'others-typography',
						'type'        => 'typography', 
						'title'       => esc_html__( 'Others', 'bakery-options' ),
						'google'      => true,
						'font-style' => false,
						'font-weight' => false,
						'font-size' => false,
						'text-align' => false,
						'line-height' => false,
						'all_styles'  => true,
						'color' => false,
						'units'       => 'px',
						'output'      => array('.vu_tabs .vu_t-nav li a', '.vu_tour .vu_t-wrapper .vu_t-nav a', '.vu_product.vu_p-style-2 .vu_p-label', '.vu_product.vu_p-style-3 .vu_p-label', '.vu_product.vu_p-style-4 .vu_p-label', '.vu_product.vu_p-style-5 .vu_p-label', '.vu_special-offer .vu_so-item-price', '.vu_special-offer .vu_so-item-label', '.vu_pricing-table .vu_pt-title', '.btn', '.vu_counter .vu_c-holder', '.vu_error-page .vu_ep-404', '.woocommerce input.button', '.woocommerce button.button', '.woocommerce a.button', '.woocommerce div.product p.price', '.woocommerce div.product span.price', '.woocommerce table.shop_table th', '.woocommerce-cart .cart-collaterals .cart_totals table th', '.woocommerce table.order_details thead th', '.woocommerce table.woocommerce-checkout-review-order-table thead th', '.vu_wc-product .vu_p-label', '.vu_wc-product-label'),
						'default'     => array(
							'font-family' => 'Montserrat',
							'font-style' => '700',
							'subsets' => 'latin'
						)
					)
				)
			);

			//Top Bar
			$this->sections[] = array(
				'title'  => esc_html__( 'Top Bar', 'bakery-options' ),
				'icon'   => 'fa-solid fa-window-maximize',
				'fields' => array(
					array(
						'id'       => 'top-bar-show',
						'type'     => 'switch',
						'title'    => esc_html__( 'Show Top Bar?', 'bakery-options' ),
						'desc'     => esc_html__( 'Select yes to show top bar.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => true,
					),
					array(
						'id'       => 'top-bar-layout',
						'type'     => 'button_set',
						'required' => array( 'top-bar-show', '=', true ),
						'title'    => esc_html__( 'Layout', 'bakery-options' ),
						'desc'     => esc_html__( 'Select top bar layout.', 'bakery-options' ),
						'options'  => array(
							'boxed' => esc_html__( 'Boxed', 'bakery-options'),
							'fullwidth' => esc_html__( 'Full Width', 'bakery-options')
						),
						'default'  => 'boxed'
					),
					array(
						'id'       => 'top-bar-columns',
						'type'     => 'select',
						'required' => array( 'top-bar-show', '=', true ),
						'title'    => esc_html__( 'Columns', 'bakery-options' ),
						'desc'     => esc_html__( 'Select column size for left and right content.', 'bakery-options' ),
						'select2'  => array('allowClear' => false),
						'options'  => array(
							'6-6' => esc_html__('1/2 + 1/2', 'bakery-options'),
							'8-4' => esc_html__('2/3 + 1/3', 'bakery-options'),
							'4-8' => esc_html__('1/3 + 2/3', 'bakery-options'),
							'9-3' => esc_html__('3/4 + 1/4', 'bakery-options'),
							'3-9' => esc_html__('1/4 + 3/4', 'bakery-options'),
							'7-5' => esc_html__('7/12 + 5/12', 'bakery-options'),
							'5-7' => esc_html__('5/12 + 7/12', 'bakery-options')
						),
						'default'  => '7-5'
					),
					array(
						'id'       => 'top-bar-bg-color',
						'type'     => 'background',
						'required' => array( 'top-bar-show', '=', true ),
						'title'    => esc_html__( 'Background Color', 'bakery-options' ),
						'desc'     => esc_html__( 'Select top bar background color.', 'bakery-options' ),
						'background-repeat' => false,
						'background-attachment' => false,
						'background-position' => false,
						'background-image' => false,
						'background-size' => false,
						'preview' => false,
						'transparent' => false,
						'output'   => '.vu_top-bar',
						'default'  => array(
							'background-color' => '#343434'
						)
					),
					array(
						'id'       => 'top-bar-text-color',
						'type'     => 'color',
						'required' => array( 'top-bar-show', '=', true ),
						'title'    => esc_html__( 'Text Color', 'bakery-options' ),
						'desc'     => esc_html__( 'Select top bar text color.', 'bakery-options' ),
						'transparent' => false,
						'output'   => '.vu_top-bar',
						'default'  => '#ffffff'
					),
					array(
						'id'       => 'top-bar-left-content',
						'type'     => 'textarea',
						'required' => array( 'top-bar-show', '=', true ),
						'title'    => esc_html__( 'Left Content', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter top bar left side content. HTML code is allowed!', 'bakery-options' ),
						'default'  => '<span><i class="fa fa-phone-square"></i>+1 0123 456 789</span>|<span><i class="fa fa-clock-o"></i>Mon - Sat: 7:00 - 17:00</span>|<span><i class="fa fa-envelope-o"></i> info@yourdomain.com</span>',
					),
					array(
						'id'       => 'top-bar-right-content',
						'type'     => 'textarea',
						'required' => array( 'top-bar-show', '=', true ),
						'title'    => esc_html__( 'Right Content', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter top bar right side content. HTML code is allowed!', 'bakery-options' ),
						'default'  => '<div class="vu_social-icon"><a href="#" target="_self"><i class="fa fa-facebook"></i></a></div><div class="vu_social-icon"><a href="#" target="_self"><i class="fa fa-twitter"></i></a></div><div class="vu_social-icon"><a href="#" target="_self"><i class="fa fa-youtube"></i></a></div><div class="vu_social-icon m-r-0"><a href="#" target="_self"><i class="fa fa-instagram"></i></a></div>',
					)
				)
			);

			//Header
			$this->sections[] = array(
				'title'  => esc_html__( 'Header', 'bakery-options' ),
				'icon'   => 'fa-regular fa-window-maximize',
				'fields' => array(
					array(
						'id'       => 'header-type',
						'type'     => 'image_select',
						'title'    => esc_html__( 'Header Type', 'bakery-options' ),
						'desc'     => esc_html__( 'Select header type.', 'bakery-options' ),
						'options'  => array(
							'1' => array(
								'alt' => 'Type 1',
								'img' => ReduxFramework::$_url .'assets/img/header-type-1.jpg'
							),
							'2' => array(
								'alt' => 'Type 2',
								'img' => ReduxFramework::$_url .'assets/img/header-type-2.jpg'
							),
							'3' => array(
								'alt' => 'Type 3',
								'img' => ReduxFramework::$_url .'assets/img/header-type-3.jpg'
							)
						),
						'default'  => '2'
					),
					array(
						'id'       => 'header-layout',
						'type'     => 'button_set',
						'title'    => esc_html__( 'Header Layout', 'bakery-options' ),
						'desc'     => esc_html__( 'Select header layout.', 'bakery-options' ),
						'options'  => array(
							'boxed' => esc_html__( 'Boxed', 'bakery-options'),
							'fullwidth' => esc_html__( 'Full Width', 'bakery-options')
						),
						'default'  => 'boxed'
					),
					array(
						'id'       => 'header-padding',
						'type'     => 'spacing',
						'title'    => esc_html__( 'Header Padding', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter header top and bottom padding.', 'bakery-options' ),
						'left'      => false,
						'right'      => false,
						'output'   => array('.vu_main-menu-container'),
						'units'    => array('px'),
						'default'  => array(
							'padding-top'     => '25', 
							'padding-right'   => '0', 
							'padding-bottom'  => '25', 
							'padding-left'    => '0',
							'units'          => 'px', 
						)
					),
					array(
						'id'       => 'header-transparent',
						'type'     => 'switch',
						'title'    => esc_html__( 'Header Transparent?', 'bakery-options' ),
						'desc'     => esc_html__( 'Make header area transparent.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false,
					),
					array(
						'id'       => 'header-show-search-icon',
						'type'     => 'switch',
						'title'    => esc_html__( 'Show Search Icon', 'bakery-options' ),
						'desc'     => esc_html__( 'Show search icon in main menu.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false,
					),
					array(
						'id'       => 'header-search-scope',
						'type'     => 'select',
						'required' => array( 'header-show-search-icon', '=', true ),
						'title'    => esc_html__( 'Search Scope', 'bakery-options' ),
						'desc'     => esc_html__( 'Select search scope.', 'bakery-options' ),
						'select2'  => array('allowClear' => false),
						'options'  => array(
							'all' => esc_html__('All', 'bakery-options'),
							'post' => esc_html__('Post', 'bakery-options'),
							'page' => esc_html__('Page', 'bakery-options'),
							'product' => esc_html__('Product', 'bakery-options')
						),
						'default'  => 'all'
					),
					array(
						'id'       => 'header-nav-submenu-width',
						'type'     => 'text',
						'title'    => esc_html__( 'Navigation Submenu Width', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter navigation submenu width in pixels.', 'bakery-options' ),
						'validate' => 'numeric',
						'default' => 200
					),
					array(
						'id'       => 'header-nav-submenu-bg-color',
						'type'     => 'background',
						'title'    => esc_html__( 'Navigation Submenu Bg Color', 'bakery-options' ),
						'desc'     => esc_html__( 'Select navigation submenu background color.', 'bakery-options' ),
						'background-repeat' => false,
						'background-attachment' => false,
						'background-position' => false,
						'background-image' => false,
						'background-size' => false,
						'preview' => false,
						'transparent' => false,
						'output'   => array('.vu_main-menu ul li ul.sub-menu li a', '.vu_main-menu .vu_mega-menu > ul.sub-menu'),
						'default'  => array(
							'background-color' => '#efefef'
						)
					),
					array(
						'id'       => 'header-hamburger-menu',
						'type'     => 'text',
						'title'    => esc_html__( 'Hamburger Menu', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter width in pixels by which hamburger menu will be shown.', 'bakery-options' ),
						'validate' => 'numeric',
						'default' => 1000
					),
					array(
						'id'       => 'header-fixed',
						'type'     => 'switch',
						'title'    => esc_html__( 'Fixed Header on Scroll', 'bakery-options' ),
						'desc'     => esc_html__( 'Enable fixed header on scroll.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => true
					),
					array(
						'id'       => 'header-fixed-offset',
						'type'     => 'text',
						'required' => array( 'header-fixed', '=', true ),
						'title'    => esc_html__( 'Fixed Header Offset', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter distance in px by which fixed header is shown.', 'bakery-options' ),
						'validate' => 'numeric',
						'default' => 150
					),
					array(
						'id'       => 'header-fixed-logo',
						'type'     => 'media',
						'required' => array( 'header-fixed', '=', true ),
						'title'    => esc_html__( 'Fixed Header Logo', 'bakery-options' ),
						'desc'     => esc_html__( 'Add a custom fixed header logo for your site.', 'bakery-options' ),
						'url'      => false,
						'default'  => array(
							'url' => get_template_directory_uri() .'/assets/img/bakery-logo-small.png',
							'width' => '575',
							'height' => '331'
						)
					),
					array(
						'id'       => 'header-fixed-logo-width',
						'type'     => 'slider',
						'required' => array( 'header-fixed', '=', true ),
						'title'    => esc_html__( 'Fixed Header Logo Width', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter logo width in px.', 'bakery-options' ),
						'min'      => 50,
						'max'      => 200,
						'step'      => 1,
						'default'  => 90
					),
					array(
						'id'       => 'header-fixed-padding',
						'type'     => 'spacing',
						'required' => array( 'header-fixed', '=', true ),
						'title'    => esc_html__( 'Fixed Header Padding', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter fixed header top and bottom padding.', 'bakery-options' ),
						'left'      => false,
						'right'      => false,
						'output'   => array('.vu_menu-affix.affix .vu_main-menu-container'),
						'units'    => array('px'),
						'default'  => array(
							'padding-top'     => '20px', 
							'padding-right'   => '0', 
							'padding-bottom'  => '20px', 
							'padding-left'    => '0',
							'units'          => 'px', 
						)
					)
				)
			);

			//Page Header
			$this->sections[] = array(
				'title'  => esc_html__( 'Page Header', 'bakery-options' ),
				'icon'   => 'fa-solid fa-square-minus',
				'fields' => array(
					array(
						'id'       => 'page-header-show',
						'type'     => 'switch',
						'title'    => esc_html__( 'Show Page Header', 'bakery-options' ),
						'desc'     => esc_html__( 'Show page header area on all pages.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => true,
					),
					array(
						'id'       => 'page-header-style',
						'type'     => 'image_select',
						'required' => array( 'page-header-show', '=', true ),
						'title'    => esc_html__( 'Style', 'bakery-options' ),
						'desc' => esc_html__( 'Select page header style.', 'bakery-options' ),
						'options'  => array(
							'1' => array(
								'alt' => 'Style 1',
								'img' => ReduxFramework::$_url .'assets/img/page-header-1.jpg'
							),
							'2' => array(
								'alt' => 'Style 2',
								'img' => ReduxFramework::$_url .'assets/img/page-header-2.jpg'
							)
						),
						'default'  => '1'
					),
					array(
						'id'       => 'page-header-breadcrumbs-show',
						'type'     => 'switch',
						'required' => array( 'page-header-style', '=', '1' ),
						'title'    => esc_html__( 'Show Breadcrumbs', 'bakery-options' ),
						'desc'     => esc_html__( 'Select yes to show breadcrumbs.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => true,
					),
					array(
						'id'       => 'page-header-breadcrumbs-content',
						'type'     => 'text',
						'required' => array( 'page-header-breadcrumbs-show', '=', true ),
						'title'    => esc_html__( 'Breadcrumbs Content', 'bakery-options' ),
						'desc'     => wp_kses( sprintf( __( 'Enter the page header breadcrumb content. We recommend using the <a href="%s" target="_blank">Yoast SEO</a> plugin, respectively their shortcode <b>[wpseo_breadcrumb]</b>, or you can use our built-in breadcrumb shortcode <b>[vu_breadcrumb]</b> instead. Don\'t forget to update the <a href="%s" target="_blank">separator between breadcrumbs</a> option with <code>%s</code>.' ), esc_url( 'https://wordpress.org/plugins/wordpress-seo/' ), admin_url( '/admin.php?page=wpseo_page_settings#/breadcrumbs' ), esc_html( '<span class="divider"><i class="fa fa-angle-right"></i></span>' ), 'bakery-options' ), array( 'a' => array( 'href' => array(), 'target' => array() ), 'b' => array(), 'code' => array() ) ),
						'default' => '[wpseo_breadcrumb]'
					),
					array(
						'id'       => 'page-header-height',
						'type'     => 'text',
						'required' => array( 'page-header-show', '=', true ),
						'title'    => esc_html__( 'Height', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter page header height in pixels.', 'bakery-options' ),
						'validate' => 'numeric',
						'default' => 250
					),
					array(
						'id'       => 'page-header-bg-image',
						'type'     => 'media',
						'required' => array( 'page-header-show', '=', true ),
						'title'    => esc_html__( 'Background Image', 'bakery-options' ),
						'desc'     => esc_html__( 'Add a default header background image.', 'bakery-options' ),
						'url'      => false,
						'default'  => array(
							'url' => ''
						)
					),
					array(
						'id'       => 'page-header-parallax',
						'type'     => 'switch',
						'required' => array( 'page-header-show', '=', true ),
						'title'    => esc_html__( 'Enable Parallax', 'bakery-options' ),
						'desc'     => esc_html__( 'Enable parallax effect on page header background image.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => true,
					),
					array(
						'id'       => 'page-header-color-overlay',
						'type'     => 'color',
						'required' => array( 'page-header-show', '=', true ),
						'title'    => esc_html__( 'Color Overlay', 'bakery-options' ),
						'desc'     => esc_html__( 'Select page header color overlay.', 'bakery-options' ),
						'transparent' => false,
						'validate' => 'color',
						'default'  => '#000000',
					),
					array(
						'id'       => 'page-header-color-overlay-opacity',
						'type'     => 'slider',
						'required' => array( 'page-header-show', '=', true ),
						'desc'     => esc_html__( 'Enter color overlay opacity.', 'bakery-options' ),
						'min'      => 0,
						'max'      => 1,
						'step'      => 0.1,
						'default'  => 0.5,
						'resolution'  => 0.1
					),
					array(
						'id'       => 'page-header-others-options',
						'type'     => 'checkbox',
						'required' => array( 'page-header-show', '=', true ),
						'title'    => esc_html__( 'Others Options', 'bakery-options' ),
						'desc'     => esc_html__( 'Select other options you want to apply on page header area.', 'bakery-options' ),
						'options'  => array(
							'border' => esc_html__('Border', 'bakery-options'),
							'pattern' => esc_html__( 'Pattern', 'bakery-options')
						),
						'default' => array(
							'border' => true,
							'pattern' => true
						)
					)
				)
			);
			
			//Blog
			$this->sections[] = array(
				'title'  => esc_html__( 'Blog', 'bakery-options' ),
				'desc'   => esc_html__( 'All blog related options are listed here.', 'bakery-options' ),
				'icon'   => 'fa-solid fa-pen-to-square',
				'fields' => array(
					array(
						'id'       => 'blog-image-ratio',
						'type'     => 'select',
						'title'    => esc_html__( 'Image Ratio', 'bakery-options' ),
						'desc'     => esc_html__( 'Select image ratio.', 'bakery-options' ),
						'select2'  => array('allowClear' => false),
						'options'  => array(
							"1:1" => "1:1",
							"2:1" => "2:1",
							"3:2" => "3:2",
							"3:4" => "3:4",
							"4:3" => "4:3",
							"16:9" => "16:9"
						),
						'default'  => '2:1'
					),
					array(
						'id'       => 'blog-social',
						'type'     => 'switch',
						'title'    => esc_html__( 'Social Media Sharing Buttons', 'bakery-options' ),
						'desc'     => esc_html__( 'Enable social sharing buttons on blog posts.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'blog-social-networks',
						'type'     => 'checkbox',
						'required' => array( 'blog-social', '=', true ),
						'title'    => esc_html__( 'Social Networks', 'bakery-options' ),
						'desc'     => esc_html__( 'Select social networks to be shown in single posts.', 'bakery-options' ),
						'options'  => array(
							'facebook' => esc_html__( 'Facebook', 'bakery-options' ),
							'twitter' => esc_html__( 'Twitter', 'bakery-options' ),
							'google-plus' => esc_html__( 'Google+', 'bakery-options' ),
							'pinterest' => esc_html__( 'Pinterest', 'bakery-options' ),
							'linkedin' => esc_html__( 'LinkedIn', 'bakery-options' ),
							'whatsapp' => esc_html__( 'WhatsApp', 'bakery-options' ),
							'viber' => esc_html__( 'Viber', 'bakery-options' ),
							'telegram' => esc_html__( 'Telegram', 'bakery-options' )
						),
						'default'  => array(
							'facebook' => '1',
							'twitter' => '1',
							'google-plus' => '1',
							'pinterest' => '1',
							'linkedin' => '0',
							'whatsapp' => '0',
							'viber' => '0',
							'telegram' => '0'
						)
					),
					array(
						'id'       => 'blog-show-date',
						'type'     => 'switch',
						'title'    => esc_html__( 'Show Date', 'bakery-options' ),
						'desc'     => esc_html__( 'Show date for blog posts.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => true
					),
					array(
						'id'       => 'blog-show-author',
						'type'     => 'switch',
						'title'    => esc_html__( 'Show Author', 'bakery-options' ),
						'desc'     => esc_html__( 'Show author for blog posts.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'blog-show-comments-number',
						'type'     => 'switch',
						'title'    => esc_html__( 'Show Comments Number', 'bakery-options' ),
						'desc'     => esc_html__( 'Show comments number for blog posts.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => true
					),
					array(
						'id'       => 'blog-show-categories',
						'type'     => 'switch',
						'title'    => esc_html__( 'Show Categories', 'bakery-options' ),
						'desc'     => esc_html__( 'Show categories for blog posts.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'blog-show-tags',
						'type'     => 'switch',
						'title'    => esc_html__( 'Show Tags', 'bakery-options' ),
						'desc'     => esc_html__( 'Show tags for blog posts.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'blog-single-show-page-header',
						'type'     => 'switch',
						'title'    => esc_html__( 'Show Page Header in Single Post', 'bakery-options' ),
						'desc'     => esc_html__( 'Show page header in single post.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => true,
					),
					array(
						'id'       => 'blog-single-show-sidebar',
						'type'     => 'switch',
						'title'    => esc_html__( 'Show Sidebar in Single Post', 'bakery-options' ),
						'desc'     => esc_html__( 'Show sidebar in single post.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => true,
					),
					array(
						'id'       => 'blog-single-show-tags',
						'type'     => 'switch',
						'title'    => esc_html__( 'Show Tags in Single Post', 'bakery-options' ),
						'desc'     => esc_html__( 'Show tags in single post.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => true
					),
					array(
						'id'       => 'blog-single-show-next-prev',
						'type'     => 'switch',
						'title'    => esc_html__( 'Show Next Prev in Single Post', 'bakery-options' ),
						'desc'     => esc_html__( 'Show next and prev links in single post.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => true
					)
				)
			);

			//Shop
			if ( class_exists( 'WooCommerce' ) ) {
				$this->sections[] = array(
					'title'  => esc_html__( 'Shop', 'bakery-options' ),
					'desc'   => esc_html__( 'All options listed here apply when WooCommerce is used.', 'bakery-options' ),
					'icon'   => 'fa-solid fa-cart-shopping',
					'fields' => array(
						array(
							'id'       => 'shop-product-style',
							'type'     => 'image_select',
							'title'    => esc_html__( 'Product Style', 'bakery-options' ),
							'desc' => esc_html__( 'Select default product style.', 'bakery-options' ),
							'options'  => array(
								'1' => array(
									'alt' => 'Style 1',
									'img' => ReduxFramework::$_url .'assets/img/product-1.jpg'
								),
								'2' => array(
									'alt' => 'Style 2',
									'img' => ReduxFramework::$_url .'assets/img/product-2.jpg'
								),
								'3' => array(
									'alt' => 'Style 3',
									'img' => ReduxFramework::$_url .'assets/img/product-3.jpg'
								),
								'4' => array(
									'alt' => 'Style 4',
									'img' => ReduxFramework::$_url .'assets/img/product-4.jpg'
								)
								/*'0' => array(
									'alt' => 'No Style',
									'img' => ReduxFramework::$_url .'assets/img/product-0.jpg'
								)*/
							),
							'default'  => '1'
						),
						array(
							'id'       => 'shop-product-image-display',
							'type'     => 'select',
							'required' => array( 'shop-product-style', '=', array('1', '2') ),
							'title'    => esc_html__( 'Product Shape', 'bakery-options' ),
							'desc'     => esc_html__( 'Select default product shape.', 'bakery-options' ),
							'select2'  => array('allowClear' => false),
							'options'  => array(
								'portrait' => esc_html__('Portrait', 'bakery-options'),
								'landscape' => esc_html__('Landscape', 'bakery-options'),
								'square' => esc_html__('Square', 'bakery-options')
							),
							'default'  => 'portrait'
						),
						array(
							'id'       => 'shop-product-content-display',
							'type'     => 'select',
							'required' => array( 'shop-product-style', '=', array('1', '2') ),
							'title'    => esc_html__( 'Product Content', 'bakery-options' ),
							'desc'     => esc_html__( 'Select when to show product content by default.', 'bakery-options' ),
							'select2'  => array('allowClear' => false),
							'options'  => array(
								'hover' => esc_html__('Show only on hover', 'bakery-options'),
								'always' => esc_html__('Show always', 'bakery-options')
							),
							'default'  => 'hover'
						),
						array(
							'id'       => 'shop-product-options',
							'type'     => 'checkbox',
							'required' => array( 'shop-product-style', '!=', array('0') ),
							'title'    => esc_html__( 'Product Options', 'bakery-options' ),
							'desc'     => esc_html__( 'Select default options for product item.', 'bakery-options' ),
							'options'  => array(
								'show-zoom-icon' => esc_html__('Show Zoom Icon', 'bakery-options'),
								'show-link-icon' => esc_html__('Show Link Icon', 'bakery-options'),
								'show-cart-icon' => esc_html__('Show Add to Cart Icon', 'bakery-options'),
								'show-title' => esc_html__('Show Title', 'bakery-options'),
								'show-categories' => esc_html__('Show Categories', 'bakery-options'),
								'show-quantity' => esc_html__('Show Quantity', 'bakery-options'),
								'show-price' => esc_html__('Show Price', 'bakery-options'),
								'disable-link' => esc_html__('Disable Link', 'bakery-options')
							),
							'default'  => array(
								'show-zoom-icon' => '1',
								'show-link-icon' => '1',
								'show-cart-icon' => '1',
								'show-title' => '1',
								'show-categories' => '1',
								'show-quantity' => '0',
								'show-price' => '1',
								'disable-link' => '0'
							)
						),
						array(
							'id'       => 'shop-product-count',
							'type'     => 'spinner',
							'title'    => esc_html__('Number of products', 'bakery-options' ),
							'desc'     => esc_html__('Select number of products per page.', 'bakery-options' ),
							'default'  => '12',
							'min'      => '1',
							'step'     => '1',
							'max'      => '50',
						),
						array(
							'id'       => 'shop-show-basket-icon',
							'type'     => 'switch',
							'title'    => esc_html__( 'Show Cart Icon', 'bakery-options' ),
							'desc'     => esc_html__( 'Show cart icon in main menu.', 'bakery-options' ),
							'on'       => esc_html__( 'Yes', 'bakery-options' ),
							'off'      => esc_html__( 'No', 'bakery-options' ),
							'default'  => true,
						),
						array(
							'id'       => 'shop-show-sidebar-single-product',
							'type'     => 'switch',
							'title'    => esc_html__( 'Single Product Sidebar', 'bakery-options' ),
							'desc'     => esc_html__( 'Show shop sidebar on single product.', 'bakery-options' ),
							'on'       => esc_html__( 'Yes', 'bakery-options' ),
							'off'      => esc_html__( 'No', 'bakery-options' ),
							'default'  => false,
						),
						array(
							'id'       => 'shop-show-product-socials',
							'type'     => 'switch',
							'title'    => esc_html__( 'Social Media Sharing Buttons', 'bakery-options' ),
							'desc'     => esc_html__( 'Enable social sharing buttons on single product.', 'bakery-options' ),
							'on'       => esc_html__( 'Yes', 'bakery-options' ),
							'off'      => esc_html__( 'No', 'bakery-options' ),
							'default'  => true,
						),
						array(
							'id'       => 'shop-product-socials',
							'type'     => 'checkbox',
							'required' => array( 'shop-show-product-socials', '=', true ),
							'title'    => esc_html__( 'Social Networks', 'bakery-options' ),
							'desc'     => esc_html__( 'Select social networks to be shown in single product.', 'bakery-options' ),
							'options'  => array(
								'facebook' => 'Facebook',
								'twitter' => 'Twitter',
								'google-plus' => 'Google+',
								'pinterest' => 'Pinterest',
								'linkedin' => 'LinkedIn',
								'whatsapp' => 'WhatsApp',
								'viber' => 'Viber',
								'telegram' => 'Telegram'
							),
							'default'  => array(
								'facebook' => '1',
								'twitter' => '1',
								'google-plus' => '0',
								'pinterest' => '1',
								'linkedin' => '0',
								'whatsapp' => '1',
								'viber' => '1',
								'telegram' => '1'
							)
						),
						array(
							'id'       => 'shop-show-upsells-products',
							'type'     => 'switch',
							'title'    => esc_html__( 'Up Sells Products', 'bakery-options' ),
							'desc'     => esc_html__( 'Show up sells products on single product.', 'bakery-options' ),
							'on'       => esc_html__( 'Yes', 'bakery-options' ),
							'off'      => esc_html__( 'No', 'bakery-options' ),
							'default'  => true,
						),
						array(
							'id'       => 'shop-show-related-products',
							'type'     => 'switch',
							'title'    => esc_html__( 'Related Products', 'bakery-options' ),
							'desc'     => esc_html__( 'Show related products on single product.', 'bakery-options' ),
							'on'       => esc_html__( 'Yes', 'bakery-options' ),
							'off'      => esc_html__( 'No', 'bakery-options' ),
							'default'  => true,
						),
						array(
							'id'       => 'shop-related-products-items-count',
							'type'     => 'spinner',
							'required' => array( 'shop-show-related-products', '=', true ),
							'title'    => esc_html__('Number of Related Products Items', 'bakery-options' ),
							'desc'     => esc_html__('Select number of related products items.', 'bakery-options' ),
							'default'  => '4',
							'min'      => '1',
							'step'     => '1',
							'max'      => '20',
						)
					)
				);
			}
			
			//Map
			$this->sections[] = array(
				'title'  => esc_html__( 'Map', 'bakery-options' ),
				'desc'   => wp_kses( __( 'All map related options are listed here. To convert an address into latitude & longitude please use <a href="https://www.latlong.net/convert-address-to-lat-long.html">this converter.</a>', 'bakery-options' ), array( 'a' => array( 'href' => array() ) ) ),
				'icon'   => 'fa-solid fa-map-location',
				'fields' => array(
					array(
						'id'       => 'map-google-api-key',
						'type'     => 'text',
						'title'    => esc_html__( 'Google Map API Key', 'bakery-options' ),
						'desc'     => wp_kses( __( 'As of <a href="https://googlegeodevelopers.blogspot.com/2016/06/building-for-scale-updates-to-google.html" target="_blank">June 22, 2016</a> Google Maps no longer allows request for new sites that doesn’t include an API key. <a href="https://developers.google.com/maps/documentation/javascript/get-api-key" target="_blank">Click here</a> to generate your Google Map API key', 'bakery-options' ), array('a' => array('href' => array(), 'target' => array())) ),
						'default'  => ''
					),
					array(
						'id'       => 'map-center-lat',
						'type'     => 'text',
						'title'    => esc_html__( 'Map Center Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for the map center point.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-center-lng',
						'type'     => 'text',
						'title'    => esc_html__( 'Map Center Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for the map center point.', 'bakery-options' ),
						'default'  => ''
					),
					array(
						'id'       => 'map-zoom-level',
						'type'     => 'text',
						'title'    => esc_html__( 'Default Map Zoom Level', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter default map zoom level. Note: Value should be between 1-18, 1 being the entire earth and 18 being right at street level.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-height',
						'type'     => 'text',
						'title'    => esc_html__( 'Map Height', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter map container height in px.', 'bakery-options' ),
						'validate' => 'numeric',
						'default'  => '580'
					),
					array(
						'id'       => 'map-type',
						'type'     => 'select',
						'title'    => esc_html__( 'Map Type', 'bakery-options' ),
						'desc'     => esc_html__( 'Select map type.', 'bakery-options' ),
						'options'  => array(
							"roadmap" => __("Roadmap", 'bakery-options'),
							"satellite" => __("Satellite", 'bakery-options'),
							"hybrid" => __("Hybrid", 'bakery-options'),
							"terrain" => __("Terrain", 'bakery-options')
						),
						'default'  => 'roadmap'
					),
					array(
						'id'       => 'map-id',
						'type'     => 'text',
						'title'    => esc_html__( 'Map ID', 'bakery-options' ),
						'desc'     => esc_html__( "A map ID is an identifier that's associated with a specific map style or feature. Configure a map style and associate it with a map ID in the Google Cloud Console.", 'bakery-options' ),
						'default'  => ''
					),
					array(
						'id'       => 'map-tilt-45',
						'type'     => 'switch',
						'required' => array( 'map-type', '=', 'satellite' ),
						'title'    => esc_html__( 'Tilt 45°', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-use-marker-img',
						'type'     => 'switch',
						'title'    => esc_html__( 'Use Image for Markers', 'bakery-options' ),
						'desc'     => esc_html__( 'Use a custom map marker.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-marker-img',
						'type'     => 'media',
						'required' => array( 'map-use-marker-img', '=', true ),
						'title'    => esc_html__( 'Marker Icon Upload', 'bakery-options' ),
						'desc'     => esc_html__( 'Upload image that will be used as map marker.', 'bakery-options' ),
						'url'      => false
					),
					array(
						'id'       => 'map-enable-animation',
						'type'     => 'switch',
						'title'    => esc_html__( 'Enable Marker Animation', 'bakery-options' ),
						'desc'     => esc_html__( 'Enable marker animation? This will cause marker(s) to do a quick bounce as they load in.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-others-options',
						'type'     => 'checkbox',
						'title'    => esc_html__( 'Others Options', 'bakery-options' ),
						'desc'     => esc_html__( 'Select other map options.', 'bakery-options' ),
						'options'  => array(
							'draggable' => esc_html__('Draggable', 'bakery-options'),
							'zoomControl' => esc_html__( 'Zoom Control', 'bakery-options'),
							'disableDoubleClickZoom' => esc_html__( 'Disable Double Click Zoom', 'bakery-options'),
							'panControl' => esc_html__( 'Pan Control', 'bakery-options'),
							'fullscreenControl' => esc_html__( 'Fullscreen Control', 'bakery-options'),
							'mapTypeControl' => esc_html__( 'Map Type Control', 'bakery-options'),
							'scaleControl' => esc_html__( 'Scale Control', 'bakery-options'),
							'streetViewControl' => esc_html__( 'Street View Control', 'bakery-options')
						),
						'default' => array(
							'draggable' => false,
							'fullscreenControl' => true,
							'disableDoubleClickZoom' => true
						)
					),

					array(
						'id'       => 'map-number-of-locations',
						'type'     => 'spinner',
						'title'    => esc_html__( 'Number of locations', 'bakery-options' ),
						'desc'     => esc_html__( 'Select number of locations to be shown in the map.', 'bakery-options' ),
						'default'  => '1',
						'min'      => '1',
						'step'     => '1',
						'max'      => '50',
					),

					// ***** Map Point 1 ***** //
					array(
						'id'       => 'map-point-1',
						'type'     => 'switch',
						'title'    => esc_html__( 'Location #1', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #1.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-1',
						'type'     => 'text',
						'required' => array( 'map-point-1', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #1.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-1',
						'type'     => 'text',
						'required' => array( 'map-point-1', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #1.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-1',
						'type'     => 'textarea',
						'required' => array( 'map-point-1', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your #1 location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 2 ***** //
					array(
						'id'       => 'map-point-2',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 2 ),
						'title'    => esc_html__( 'Location #2', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #2.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-2',
						'type'     => 'text',
						'required' => array( 'map-point-2', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #2.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-2',
						'type'     => 'text',
						'required' => array( 'map-point-2', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #2.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-2',
						'type'     => 'textarea',
						'required' => array( 'map-point-2', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your #2 location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 3 ***** //
					array(
						'id'       => 'map-point-3',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 3 ),
						'title'    => esc_html__( 'Location #3', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #3.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-3',
						'type'     => 'text',
						'required' => array( 'map-point-3', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #3.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-3',
						'type'     => 'text',
						'required' => array( 'map-point-3', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #3.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-3',
						'type'     => 'textarea',
						'required' => array( 'map-point-3', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your #3 location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 4 ***** //
					array(
						'id'       => 'map-point-4',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 4 ),
						'title'    => esc_html__( 'Location #4', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #4.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-4',
						'type'     => 'text',
						'required' => array( 'map-point-4', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #4.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-4',
						'type'     => 'text',
						'required' => array( 'map-point-4', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #4.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-4',
						'type'     => 'textarea',
						'required' => array( 'map-point-4', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your #4 location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 5 ***** //
					array(
						'id'       => 'map-point-5',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 5 ),
						'title'    => esc_html__( 'Location #5', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #5.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-5',
						'type'     => 'text',
						'required' => array( 'map-point-5', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #5.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-5',
						'type'     => 'text',
						'required' => array( 'map-point-5', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #5.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-5',
						'type'     => 'textarea',
						'required' => array( 'map-point-5', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your #5 location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 6 ***** //
					array(
						'id'       => 'map-point-6',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 6 ),
						'title'    => esc_html__( 'Location #6', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #6.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-6',
						'type'     => 'text',
						'required' => array( 'map-point-6', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #6.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-6',
						'type'     => 'text',
						'required' => array( 'map-point-6', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #6.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-6',
						'type'     => 'textarea',
						'required' => array( 'map-point-6', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your #6 location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 7 ***** //
					array(
						'id'       => 'map-point-7',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 7 ),
						'title'    => esc_html__( 'Location #7', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #7.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-7',
						'type'     => 'text',
						'required' => array( 'map-point-7', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #7.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-7',
						'type'     => 'text',
						'required' => array( 'map-point-7', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #7.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-7',
						'type'     => 'textarea',
						'required' => array( 'map-point-7', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your #7 location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 8 ***** //
					array(
						'id'       => 'map-point-8',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 8 ),
						'title'    => esc_html__( 'Location #8', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #8.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-8',
						'type'     => 'text',
						'required' => array( 'map-point-8', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #8.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-8',
						'type'     => 'text',
						'required' => array( 'map-point-8', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #8.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-8',
						'type'     => 'textarea',
						'required' => array( 'map-point-8', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your #8 location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 9 ***** //
					array(
						'id'       => 'map-point-9',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 9 ),
						'title'    => esc_html__( 'Location #9', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #9.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-9',
						'type'     => 'text',
						'required' => array( 'map-point-9', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #9.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-9',
						'type'     => 'text',
						'required' => array( 'map-point-9', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #9.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-9',
						'type'     => 'textarea',
						'required' => array( 'map-point-9', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your #9 location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 10 ***** //
					array(
						'id'       => 'map-point-10',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 10 ),
						'title'    => esc_html__( 'Location #10', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #10.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-10',
						'type'     => 'text',
						'required' => array( 'map-point-10', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #10.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-10',
						'type'     => 'text',
						'required' => array( 'map-point-10', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #10.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-10',
						'type'     => 'textarea',
						'required' => array( 'map-point-10', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your #10 location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 11 ***** //
					array(
						'id'       => 'map-point-11',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 11 ),
						'title'    => esc_html__( 'Location #11', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #11.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-11',
						'type'     => 'text',
						'required' => array( 'map-point-11', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #11.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-11',
						'type'     => 'text',
						'required' => array( 'map-point-11', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #11.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-11',
						'type'     => 'textarea',
						'required' => array( 'map-point-11', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 11th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 12 ***** //
					array(
						'id'       => 'map-point-12',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 12 ),
						'title'    => esc_html__( 'Location #12', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #12.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-12',
						'type'     => 'text',
						'required' => array( 'map-point-12', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #12.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-12',
						'type'     => 'text',
						'required' => array( 'map-point-12', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #12.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-12',
						'type'     => 'textarea',
						'required' => array( 'map-point-12', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 12th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 13 ***** //
					array(
						'id'       => 'map-point-13',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 13 ),
						'title'    => esc_html__( 'Location #13', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #13.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-13',
						'type'     => 'text',
						'required' => array( 'map-point-13', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #13.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-13',
						'type'     => 'text',
						'required' => array( 'map-point-13', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #13.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-13',
						'type'     => 'textarea',
						'required' => array( 'map-point-13', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 13th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 14 ***** //
					array(
						'id'       => 'map-point-14',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 14 ),
						'title'    => esc_html__( 'Location #14', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #14.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-14',
						'type'     => 'text',
						'required' => array( 'map-point-14', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #14.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-14',
						'type'     => 'text',
						'required' => array( 'map-point-14', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #14.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-14',
						'type'     => 'textarea',
						'required' => array( 'map-point-14', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 14th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 15 ***** //
					array(
						'id'       => 'map-point-15',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 15 ),
						'title'    => esc_html__( 'Location #15', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #15.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-15',
						'type'     => 'text',
						'required' => array( 'map-point-15', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #15.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-15',
						'type'     => 'text',
						'required' => array( 'map-point-15', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #15.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-15',
						'type'     => 'textarea',
						'required' => array( 'map-point-15', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 15th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 16 ***** //
					array(
						'id'       => 'map-point-16',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 16 ),
						'title'    => esc_html__( 'Location #16', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #16.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-16',
						'type'     => 'text',
						'required' => array( 'map-point-16', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #16.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-16',
						'type'     => 'text',
						'required' => array( 'map-point-16', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #16.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-16',
						'type'     => 'textarea',
						'required' => array( 'map-point-16', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 16th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 17 ***** //
					array(
						'id'       => 'map-point-17',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 17 ),
						'title'    => esc_html__( 'Location #17', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #17.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-17',
						'type'     => 'text',
						'required' => array( 'map-point-17', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #17.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-17',
						'type'     => 'text',
						'required' => array( 'map-point-17', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #17.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-17',
						'type'     => 'textarea',
						'required' => array( 'map-point-17', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 17th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 18 ***** //
					array(
						'id'       => 'map-point-18',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 18 ),
						'title'    => esc_html__( 'Location #18', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #18.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-18',
						'type'     => 'text',
						'required' => array( 'map-point-18', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #18.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-18',
						'type'     => 'text',
						'required' => array( 'map-point-18', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #18.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-18',
						'type'     => 'textarea',
						'required' => array( 'map-point-18', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 18th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 19 ***** //
					array(
						'id'       => 'map-point-19',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 19 ),
						'title'    => esc_html__( 'Location #19', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #19.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-19',
						'type'     => 'text',
						'required' => array( 'map-point-19', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #19.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-19',
						'type'     => 'text',
						'required' => array( 'map-point-19', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #19.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-19',
						'type'     => 'textarea',
						'required' => array( 'map-point-19', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 19th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 20 ***** //
					array(
						'id'       => 'map-point-20',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 20 ),
						'title'    => esc_html__( 'Location #20', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #20.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-20',
						'type'     => 'text',
						'required' => array( 'map-point-20', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #20.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-20',
						'type'     => 'text',
						'required' => array( 'map-point-20', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #20.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-20',
						'type'     => 'textarea',
						'required' => array( 'map-point-20', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 20th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 21 ***** //
					array(
						'id'       => 'map-point-21',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 21 ),
						'title'    => esc_html__( 'Location #21', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #21.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-21',
						'type'     => 'text',
						'required' => array( 'map-point-21', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #21.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-21',
						'type'     => 'text',
						'required' => array( 'map-point-21', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #21.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-21',
						'type'     => 'textarea',
						'required' => array( 'map-point-21', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 21th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 22 ***** //
					array(
						'id'       => 'map-point-22',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 22 ),
						'title'    => esc_html__( 'Location #22', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #22.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-22',
						'type'     => 'text',
						'required' => array( 'map-point-22', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #22.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-22',
						'type'     => 'text',
						'required' => array( 'map-point-22', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #22.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-22',
						'type'     => 'textarea',
						'required' => array( 'map-point-22', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 22th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 23 ***** //
					array(
						'id'       => 'map-point-23',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 23 ),
						'title'    => esc_html__( 'Location #23', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #23.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-23',
						'type'     => 'text',
						'required' => array( 'map-point-23', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #23.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-23',
						'type'     => 'text',
						'required' => array( 'map-point-23', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #23.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-23',
						'type'     => 'textarea',
						'required' => array( 'map-point-23', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 23th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 24 ***** //
					array(
						'id'       => 'map-point-24',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 24 ),
						'title'    => esc_html__( 'Location #24', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #24.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-24',
						'type'     => 'text',
						'required' => array( 'map-point-24', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #24.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-24',
						'type'     => 'text',
						'required' => array( 'map-point-24', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #24.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-24',
						'type'     => 'textarea',
						'required' => array( 'map-point-24', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 24th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 25 ***** //
					array(
						'id'       => 'map-point-25',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 25 ),
						'title'    => esc_html__( 'Location #25', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #25.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-25',
						'type'     => 'text',
						'required' => array( 'map-point-25', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #25.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-25',
						'type'     => 'text',
						'required' => array( 'map-point-25', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #25.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-25',
						'type'     => 'textarea',
						'required' => array( 'map-point-25', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 25th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 26 ***** //
					array(
						'id'       => 'map-point-26',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 26 ),
						'title'    => esc_html__( 'Location #26', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #26.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-26',
						'type'     => 'text',
						'required' => array( 'map-point-26', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #26.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-26',
						'type'     => 'text',
						'required' => array( 'map-point-26', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #26.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-26',
						'type'     => 'textarea',
						'required' => array( 'map-point-26', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 26th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 27 ***** //
					array(
						'id'       => 'map-point-27',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 27 ),
						'title'    => esc_html__( 'Location #27', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #27.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-27',
						'type'     => 'text',
						'required' => array( 'map-point-27', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #27.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-27',
						'type'     => 'text',
						'required' => array( 'map-point-27', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #27.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-27',
						'type'     => 'textarea',
						'required' => array( 'map-point-27', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 27th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 28 ***** //
					array(
						'id'       => 'map-point-28',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 28 ),
						'title'    => esc_html__( 'Location #28', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #28.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-28',
						'type'     => 'text',
						'required' => array( 'map-point-28', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #28.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-28',
						'type'     => 'text',
						'required' => array( 'map-point-28', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #28.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-28',
						'type'     => 'textarea',
						'required' => array( 'map-point-28', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 28th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 29 ***** //
					array(
						'id'       => 'map-point-29',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 29 ),
						'title'    => esc_html__( 'Location #29', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #29.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-29',
						'type'     => 'text',
						'required' => array( 'map-point-29', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #29.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-29',
						'type'     => 'text',
						'required' => array( 'map-point-29', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #29.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-29',
						'type'     => 'textarea',
						'required' => array( 'map-point-29', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 29th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 30 ***** //
					array(
						'id'       => 'map-point-30',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 30 ),
						'title'    => esc_html__( 'Location #30', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #30.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-30',
						'type'     => 'text',
						'required' => array( 'map-point-30', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #30.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-30',
						'type'     => 'text',
						'required' => array( 'map-point-30', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #30.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-30',
						'type'     => 'textarea',
						'required' => array( 'map-point-30', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 30th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 29 ***** //
					array(
						'id'       => 'map-point-31',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 31 ),
						'title'    => esc_html__( 'Location #31', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #31.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-31',
						'type'     => 'text',
						'required' => array( 'map-point-31', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #31.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-31',
						'type'     => 'text',
						'required' => array( 'map-point-31', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #31.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-31',
						'type'     => 'textarea',
						'required' => array( 'map-point-31', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 31st location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 32 ***** //
					array(
						'id'       => 'map-point-32',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 32 ),
						'title'    => esc_html__( 'Location #32', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #32.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-32',
						'type'     => 'text',
						'required' => array( 'map-point-32', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #32.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-32',
						'type'     => 'text',
						'required' => array( 'map-point-32', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #32.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-32',
						'type'     => 'textarea',
						'required' => array( 'map-point-32', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 32nd location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 33 ***** //
					array(
						'id'       => 'map-point-33',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 33 ),
						'title'    => esc_html__( 'Location #33', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #33.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-33',
						'type'     => 'text',
						'required' => array( 'map-point-33', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #33.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-33',
						'type'     => 'text',
						'required' => array( 'map-point-33', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #33.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-33',
						'type'     => 'textarea',
						'required' => array( 'map-point-33', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 33rd location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 34 ***** //
					array(
						'id'       => 'map-point-34',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 34 ),
						'title'    => esc_html__( 'Location #34', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #34.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-34',
						'type'     => 'text',
						'required' => array( 'map-point-34', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #34.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-34',
						'type'     => 'text',
						'required' => array( 'map-point-34', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #34.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-34',
						'type'     => 'textarea',
						'required' => array( 'map-point-34', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 34th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 35 ***** //
					array(
						'id'       => 'map-point-35',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 35 ),
						'title'    => esc_html__( 'Location #35', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #35.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-35',
						'type'     => 'text',
						'required' => array( 'map-point-35', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #35.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-35',
						'type'     => 'text',
						'required' => array( 'map-point-35', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #35.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-35',
						'type'     => 'textarea',
						'required' => array( 'map-point-35', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 35th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 36 ***** //
					array(
						'id'       => 'map-point-36',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 36 ),
						'title'    => esc_html__( 'Location #36', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #36.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-36',
						'type'     => 'text',
						'required' => array( 'map-point-36', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #36.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-36',
						'type'     => 'text',
						'required' => array( 'map-point-36', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #36.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-36',
						'type'     => 'textarea',
						'required' => array( 'map-point-36', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 36th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 37 ***** //
					array(
						'id'       => 'map-point-37',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 37 ),
						'title'    => esc_html__( 'Location #37', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #37.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-37',
						'type'     => 'text',
						'required' => array( 'map-point-37', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #37.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-37',
						'type'     => 'text',
						'required' => array( 'map-point-37', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #37.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-37',
						'type'     => 'textarea',
						'required' => array( 'map-point-37', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 37th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 38 ***** //
					array(
						'id'       => 'map-point-38',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 38 ),
						'title'    => esc_html__( 'Location #38', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #38.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-38',
						'type'     => 'text',
						'required' => array( 'map-point-38', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #38.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-38',
						'type'     => 'text',
						'required' => array( 'map-point-38', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #38.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-38',
						'type'     => 'textarea',
						'required' => array( 'map-point-38', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 38th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 39 ***** //
					array(
						'id'       => 'map-point-39',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 39 ),
						'title'    => esc_html__( 'Location #39', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #39.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-39',
						'type'     => 'text',
						'required' => array( 'map-point-39', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #39.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-39',
						'type'     => 'text',
						'required' => array( 'map-point-39', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #39.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-39',
						'type'     => 'textarea',
						'required' => array( 'map-point-39', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 39th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 40 ***** //
					array(
						'id'       => 'map-point-40',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 40 ),
						'title'    => esc_html__( 'Location #40', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #40.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-40',
						'type'     => 'text',
						'required' => array( 'map-point-40', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #40.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-40',
						'type'     => 'text',
						'required' => array( 'map-point-40', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #40.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-40',
						'type'     => 'textarea',
						'required' => array( 'map-point-40', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 40th location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 41 ***** //
					array(
						'id'       => 'map-point-41',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 41 ),
						'title'    => esc_html__( 'Location #41', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #41.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-41',
						'type'     => 'text',
						'required' => array( 'map-point-41', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #41.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-41',
						'type'     => 'text',
						'required' => array( 'map-point-41', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #41.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-41',
						'type'     => 'textarea',
						'required' => array( 'map-point-41', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 41st location, please enter it here.', 'bakery-options' )
					),

					// ***** Map Point 42 ***** //
					array(
						'id'       => 'map-point-42',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 42 ),
						'title'    => esc_html__( 'Location #42', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #42.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-42',
						'type'     => 'text',
						'required' => array( 'map-point-42', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #42.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-42',
						'type'     => 'text',
						'required' => array( 'map-point-42', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #42.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-42',
						'type'     => 'textarea',
						'required' => array( 'map-point-42', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 42nd location, please enter it here.', 'bakery-options' )
					),
					// ***** Map Point 43 ***** //
					array(
						'id'       => 'map-point-43',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 43 ),
						'title'    => esc_html__( 'Location #43', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #43.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-43',
						'type'     => 'text',
						'required' => array( 'map-point-43', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #43.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-43',
						'type'     => 'text',
						'required' => array( 'map-point-43', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #43.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-43',
						'type'     => 'textarea',
						'required' => array( 'map-point-43', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 43rd location, please enter it here.', 'bakery-options' )
					),
					// ***** Map Point 44 ***** //
					array(
						'id'       => 'map-point-44',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 44 ),
						'title'    => esc_html__( 'Location #44', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #44.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-44',
						'type'     => 'text',
						'required' => array( 'map-point-44', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #44.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-44',
						'type'     => 'text',
						'required' => array( 'map-point-44', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #44.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-44',
						'type'     => 'textarea',
						'required' => array( 'map-point-44', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 44th location, please enter it here.', 'bakery-options' )
					),
					// ***** Map Point 45 ***** //
					array(
						'id'       => 'map-point-45',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 45 ),
						'title'    => esc_html__( 'Location #45', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #45.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-45',
						'type'     => 'text',
						'required' => array( 'map-point-45', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #45.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-45',
						'type'     => 'text',
						'required' => array( 'map-point-45', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #45.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-45',
						'type'     => 'textarea',
						'required' => array( 'map-point-45', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 45th location, please enter it here.', 'bakery-options' )
					),
					// ***** Map Point 46 ***** //
					array(
						'id'       => 'map-point-46',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 46 ),
						'title'    => esc_html__( 'Location #46', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #46.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-46',
						'type'     => 'text',
						'required' => array( 'map-point-46', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #46.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-46',
						'type'     => 'text',
						'required' => array( 'map-point-46', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #46.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-46',
						'type'     => 'textarea',
						'required' => array( 'map-point-46', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 46th location, please enter it here.', 'bakery-options' )
					),
					// ***** Map Point 47 ***** //
					array(
						'id'       => 'map-point-47',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 47 ),
						'title'    => esc_html__( 'Location #47', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #47.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-47',
						'type'     => 'text',
						'required' => array( 'map-point-47', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #47.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-47',
						'type'     => 'text',
						'required' => array( 'map-point-47', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #47.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-47',
						'type'     => 'textarea',
						'required' => array( 'map-point-47', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 47th location, please enter it here.', 'bakery-options' )
					),
					// ***** Map Point 48 ***** //
					array(
						'id'       => 'map-point-48',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 48 ),
						'title'    => esc_html__( 'Location #48', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #48.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-48',
						'type'     => 'text',
						'required' => array( 'map-point-48', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #48.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-48',
						'type'     => 'text',
						'required' => array( 'map-point-48', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #48.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-48',
						'type'     => 'textarea',
						'required' => array( 'map-point-48', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 48th location, please enter it here.', 'bakery-options' )
					),
					// ***** Map Point 49 ***** //
					array(
						'id'       => 'map-point-49',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 49 ),
						'title'    => esc_html__( 'Location #49', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #49.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-49',
						'type'     => 'text',
						'required' => array( 'map-point-49', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #49.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-49',
						'type'     => 'text',
						'required' => array( 'map-point-49', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #49.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-49',
						'type'     => 'textarea',
						'required' => array( 'map-point-49', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 49th location, please enter it here.', 'bakery-options' )
					),
					// ***** Map Point 50 ***** //
					array(
						'id'       => 'map-point-50',
						'type'     => 'switch',
						'required' => array( 'map-number-of-locations', '>=', 50 ),
						'title'    => esc_html__( 'Location #50', 'bakery-options' ),
						'desc'     => esc_html__( 'Show location #50.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'map-lat-50',
						'type'     => 'text',
						'required' => array( 'map-point-50', '=', true ),
						'title'    => esc_html__( 'Latitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter latitude for location #50.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-lng-50',
						'type'     => 'text',
						'required' => array( 'map-point-50', '=', true ),
						'title'    => esc_html__( 'Longitude', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter longitude for location #50.', 'bakery-options' ),
						'validate' => 'numeric'
					),
					array(
						'id'       => 'map-info-50',
						'type'     => 'textarea',
						'required' => array( 'map-point-50', '=', true ),
						'title'    => esc_html__( 'Map Info Window Text', 'bakery-options' ),
						'desc'     => esc_html__( 'If you would like to display any text in an info window for your 50th location, please enter it here.', 'bakery-options' )
					)
				)
			);
			
			//Footer
			$this->sections[] = array(
				'title'  => esc_html__( 'Footer', 'bakery-options' ),
				'desc'   => esc_html__( 'All footer area related options are listed here.', 'bakery-options' ),
				'icon'   => 'fa-regular fa-window-maximize fa-flip-vertical',
				'fields' => array(
					array(
						'id'       => 'footer-show',
						'type'     => 'switch',
						'title'    => esc_html__( 'Show Footer', 'bakery-options' ),
						'desc'     => esc_html__( 'Show footer.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => true
					),
					array(
						'id'       => 'footer-type',
						'type'     => 'button_set',
						'required' => array( 'footer-show', '=', true ),
						'title'    => esc_html__( 'Footer Type', 'bakery-options' ),
						'desc'     => esc_html__( 'Select footer type.', 'bakery-options' ),
						'options'  => array(
							'widgetized' => esc_html__( 'Widgetized', 'bakery-options'),
							'page' => esc_html__( 'Page', 'bakery-options')
						),
						'default'  => 'widgetized'
					),
					array(
						'id'       => 'footer-layout',
						'type'     => 'image_select',
						'required' => array( 'footer-type', '=', 'widgetized' ),
						'title'    => esc_html__( 'Footer Layout', 'bakery-options' ),
						'desc' => esc_html__( 'Select footer layout.', 'bakery-options' ),
						'options'  => array(
							'6-6' => array(
								'alt' => '1/2 + 1/2',
								'img' => ReduxFramework::$_url .'assets/img/6-6.jpg'
							),
							'4-4-4' => array(
								'alt' => '1/3 + 1/3 + 1/3',
								'img' => ReduxFramework::$_url .'assets/img/4-4-4.jpg'
							),
							'3-3-3-3' => array(
								'alt' => '1/4 + 1/4 + 1/4 + 1/4',
								'img' => ReduxFramework::$_url .'assets/img/3-3-3-3.jpg'
							),
							'5-2-5' => array(
								'alt' => '5/12 + 2/12 + 5/12',
								'img' => ReduxFramework::$_url .'assets/img/5-2-5.jpg'
							),
							'6-3-3' => array(
								'alt' => '2/4 + 1/4 + 1/4',
								'img' => ReduxFramework::$_url .'assets/img/6-3-3.jpg'
							),
							'3-3-6' => array(
								'alt' => '1/4 + 1/4 + 2/4',
								'img' => ReduxFramework::$_url .'assets/img/3-3-6.jpg'
							)
						),
						'default'  => '3-3-3-3'
					),
					array(
						'id'       => 'footer-page',
						'type'     => 'select',
						'required' => array( 'footer-type', '=', 'page' ),
						'title'    => esc_html__( 'Footer Page', 'bakery-options' ),
						'desc'     => esc_html__( 'Select footer page.', 'bakery-options' ),
						'data'  => 'pages',
						'args'  => array(
							'meta_key' => '_wp_page_template',
							'meta_value' => 'templates/footer.php'
						)
					),
					array(
						'id'       => 'footer-background',
						'type'     => 'background',
						'required' => array( 'footer-type', '=', 'widgetized' ),
						'title'    => esc_html__( 'Footer Background', 'bakery-options' ),
						'desc'     => esc_html__( 'Select footer background options.', 'bakery-options' ),
						'output'   => '.vu_main-footer',
						'default'  => array(
							'background-color' => '#1a1a1a'
						)
					),
					array(
						'id'       => 'footer-text-color',
						'type'     => 'color',
						'required' => array( 'footer-type', '=', 'widgetized' ),
						'title'    => esc_html__( 'Footer Text Color', 'bakery-options' ),
						'desc'     => esc_html__( 'Select footer text color.', 'bakery-options' ),
						'transparent' => false,
						'output'   => '.vu_main-footer',
						'default'  => '#ffffff'
					),
					array(
						'id'       => 'subfooter-show',
						'type'     => 'switch',
						'title'    => esc_html__( 'Show Subfooter', 'bakery-options' ),
						'desc'     => esc_html__( 'Show subfooter.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => true
					),
					array(
						'id'       => 'subfooter-layout',
						'type'     => 'image_select',
						'required' => array( 'subfooter-show', '=', true ),
						'title'    => esc_html__( 'Subfooter Layout', 'bakery-options' ),
						'desc' => esc_html__( 'Select subfooter layout.', 'bakery-options' ),
						'options'  => array(
							'1' => array(
								'alt' => '1 Column',
								'img' => ReduxFramework::$_url .'assets/img/12.jpg'
							),
							'2' => array(
								'alt' => '2 Columns',
								'img' => ReduxFramework::$_url .'assets/img/6-6.jpg'
							)
						),
						'default'  => '1'
					),
					array(
						'id'       => 'subfooter-alignment',
						'type'     => 'select',
						'required' => array( 'subfooter-layout', '=', '1' ),
						'title'    => esc_html__( 'Subfooter alignment', 'bakery-options' ),
						'desc'     => esc_html__( 'Select subfooter text alignment.', 'bakery-options' ),
						'options'  => array(
							'left' => esc_html__( 'Left', 'bakery-options'),
							'center' => esc_html__( 'Center', 'bakery-options'),
							'right' => esc_html__( 'Right', 'bakery-options')
						),
						'default'  => 'center'
					),
					array(
						'id'       => 'subfooter-full-content',
						'type'     => 'textarea',
						'required' => array( 'subfooter-layout', '=', '1' ),
						'title'    => esc_html__( 'Subfooter Content', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter subfooter content. HTML code is allowed!', 'bakery-options' ),
						'validate' => 'html',
						'default'  => 'Copyright &copy; 2019 <a href="https://themeforest.net/user/milingona_/portfolio" target="_blank">Milingona</a>. All Rights Reserved.'
					),
					array(
						'id'       => 'subfooter-left-content',
						'type'     => 'textarea',
						'required' => array( 'subfooter-layout', '=', '2' ),
						'title'    => esc_html__( 'Subfooter Left Content', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter subfooter left side content. HTML code is allowed!', 'bakery-options' ),
						'validate' => 'html',
						'default'  => 'Copyright &copy; 2019 <a href="https://themeforest.net/user/milingona_/portfolio" target="_blank">Milingona</a>. All Rights Reserved.'
					),
					array(
						'id'       => 'subfooter-right-content',
						'type'     => 'textarea',
						'required' => array( 'subfooter-layout', '=', '2' ),
						'title'    => esc_html__( 'Subfooter Right Content', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter subfooter right site content. HTML code is allowed!', 'bakery-options' ),
						'validate' => 'html',
						'default'  => ''
					),
					array(
						'id'       => 'subfooter-bg-color',
						'type'     => 'background',
						'required' => array( 'subfooter-show', '=', true ),
						'title'    => esc_html__( 'Subfooter Background Color', 'bakery-options' ),
						'desc'     => esc_html__( 'Select subfooter background color.', 'bakery-options' ),
						'background-repeat' => false,
						'background-attachment' => false,
						'background-position' => false,
						'background-image' => false,
						'background-size' => false,
						'preview' => false,
						'transparent' => false,
						'output'   => '.vu_main-footer .vu_mf-subfooter',
						'default'  => array(
							'background-color' => '#000000'
						)
					),
					array(
						'id'       => 'subfooter-text-color',
						'type'     => 'color',
						'required' => array( 'subfooter-show', '=', true ),
						'title'    => esc_html__( 'Subfooter Text Color', 'bakery-options' ),
						'desc'     => esc_html__( 'Select subfooter text color.', 'bakery-options' ),
						'transparent' => false,
						'output'   => '.vu_main-footer .vu_mf-subfooter',
						'default'  => '#ffffff'
					),
					array(
						'id'       => 'back-to-top-show',
						'type'     => 'switch',
						'title'    => esc_html__( 'Back to Top', 'bakery-options' ),
						'desc'     => esc_html__( 'Show the back to top button.', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => true
					)
				)
			);

			//Sidebars
			$this->sections[] = array(
				'title'  => esc_html__( 'Sidebars', 'bakery-options' ),
				'icon'   => 'fa-regular fa-window-maximize fa-rotate-90',
				'fields' => array(
					array(
						'id' => 'sidebars',
						'type' => 'multi_text',
						'title' => esc_html__( 'Custom Sidebars', 'bakery-options'),
						'desc' => wp_kses( __( 'Create a custom sidebar. Sidebar name should be <b>unique</b>. Do not use the names of existing sidebars.', 'bakery-options' ), array('b' => array()) ),
						'validate' => 'no_special_chars',
						'add_text' => esc_html__( 'Add Sidebar', 'bakery-options')
					)
				)
			);

			//Error 404
			$this->sections[] = array(
				'title'  => esc_html__( 'Error 404', 'bakery-options' ),
				'desc'   => esc_html__( 'Edit options below only if you want to customize error 404 page content. Important: if your site is multilingual make sure all fields are empty.', 'bakery-options' ),
				'icon'   => 'fa-solid fa-face-frown',
				'fields' => array(
					array(
						'id'       => 'error-page-header-title',
						'type'     => 'text',
						'title'    => esc_html__( 'Page Header Title', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter error page header title.', 'bakery-options' ),
						'default'  => ''
					),
					array(
						'id'       => 'error-page-header-subtitle',
						'type'     => 'text',
						'title'    => esc_html__( 'Page Header Subtitle', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter error page header subtitle.', 'bakery-options' ),
						'default'  => ''
					),
					array(
						'id'       => 'error-page-heading',
						'type'     => 'text',
						'title'    => esc_html__( 'Error Page Heading', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter error page heading.', 'bakery-options' ),
						'default'  => ''
					),
					array(
						'id'       => 'error-page-description',
						'type'     => 'textarea',
						'title'    => esc_html__( 'Error Page Description', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter error page description.', 'bakery-options' ),
						'default'  => ''
					),
					array(
						'id'       => 'error-page-btn-text',
						'type'     => 'text',
						'title'    => esc_html__( 'Return to Home Button', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter return to home button text.', 'bakery-options' ),
						'default'  => ''
					)
				)
			);

			//Advanced
			$this->sections[] = array(
				'title'  => esc_html__( 'Advanced', 'bakery-options' ),
				'icon'   => 'fa fa-cog',
				'fields' => array(
					array(
						'id'       => 'advanced-dequeue-libraries',
						'type'     => 'checkbox',
						'title'    => esc_html__( 'Dequeue Libraries', 'bakery-options' ),
						'desc'     => esc_html__( 'Select libraries you want to stop loading automatically by the theme. This is usally used to avoid conflicts between theme and plugins or to speed up your site.', 'bakery-options' ),
						'options'  => array(
							'youtube-player-api' => esc_html__('YouTube Player API', 'bakery-options'),
							'bootstrap-datepicker' => esc_html__('Bootstrap Datepicker', 'bakery-options'),
							'bootstrap-timepicker' => esc_html__('Bootstrap Timepicker', 'bakery-options')
						),
						'default' => array(
							'youtube-player-api' => false,
							'bootstrap-datepicker' => false,
							'bootstrap-timepicker' => false
						)
					),
					array(
						'id'       => 'advanced-countdown-language',
						'type'     => 'select',
						'title'    => esc_html__( 'Countdown Language', 'bakery-options' ),
						'desc'     => esc_html__( 'Select countdown language.', 'bakery-options' ),
						'select2'  => array('allowClear' => false),
						'options'  => array(
							'en' => 'English',
							'sq' => 'Albanian (Gjuha shqipe)',
							'ar' => 'Arabic (العربية)',
							'hy' => 'Armenian (Հայերեն)',
							'bn' => 'Bengali/Bangla (বাংলা)',
							'bs' => 'Bosnian (Bosanski)',
							'bg' => 'Bulgarian (български език)',
							'my' => 'Burmese (မြန်မာစာ)',
							'ca' => 'Catalan (Català)',
							'zh-CN' => 'Chinese/Simplified (简体中文)',
							'zh-TW' => 'Chinese/Traditional (繁體中文)',
							'hr' => 'Croatian (Hrvatski jezik)',
							'cs' => 'Czech (Čeština)',
							'da' => 'Danish (Dansk)',
							'nl' => 'Dutch (Nederlands)',
							'et' => 'Estonian (eesti keel)',
							'fo' => 'Faroese (føroyskt)',
							'fa' => 'Farsi/Persian (فارسی)',
							'fi' => 'Finnish (suomi)',
							'fr' => 'French (Français)',
							'gl' => 'Galician (Galego)',
							'de' => 'German (Deutsch)',
							'el' => 'Greek (Ελληνικά)',
							'gu' => 'Gujarati (ગુજરાતી)',
							'he' => 'Hebrew (עברית)',
							'hu' => 'Hungarian (Magyar)',
							'id' => 'Indonesian (Bahasa Indonesia)',
							'is' => 'Icelandic (Íslenska)',
							'it' => 'Italian (Italiano)',
							'ja' => 'Japanese (日本語)',
							'kn' => 'Kannada (ಕನ್ನಡ)',
							'ko' => 'Korean (한국어)',
							'lv' => 'Latvian (Latviešu Valoda)',
							'lt' => 'Lithuanian (lietuvių kalba)',
							'mk' => 'Macedonian (македонски јазик)',
							'ml' => 'Malayalam (മലയാളം)',
							'ms' => 'Malaysian (Bahasa Melayu)',
							'nb' => 'Norwegian (Bokmål)',
							'pl' => 'Polish (Polski)',
							'pt-BR' => 'Portuguese/Brazilian (Português)',
							'ro' => 'Romanian (Română)',
							'ru' => 'Russian (Русский)',
							'sr' => 'Serbian (српски језик)',
							'sr-SR' => 'Serbian (srpski jezik)',
							'sk' => 'Slovak (Slovenčina)',
							'sl' => 'Slovenian (Slovenščina)',
							'es' => 'Spanish (Español)',
							'sv' => 'Swedish (Svenska)',
							'th' => 'Thai (ภาษาไทย)',
							'tr' => 'Turkish (Türkçe)',
							'uk' => 'Ukrainian (українська мова)',
							'ur' => 'Urdu (‫اُردوُ‬)',
							'uz' => 'Uzbek (O‘zbek tili)',
							'vi' => 'Vietnamese (Tiếng Việt)',
							'cy' => 'Welsh (Cymraeg)'
						),
						'default'  => 'en'
					)
				)
			);
			
			//3rd Party
			$this->sections[] = array(
				'title'  => esc_html__( '3rd Party', 'bakery-options' ),
				'icon'   => 'fa-solid fa-plug',
				'fields' => array(
					array(
						'id'       => 'google-analytics-tracking-code',
						'type'     => 'textarea',
						'title'    => esc_html__( 'Google Analytics Tracking Code', 'bakery-options' ),
						'desc'     => esc_html__( 'Include <script> tag.', 'bakery-options' ),
						'default'  => ''
					),
					array(
						'id'       => 'twitter-consumer-key',
						'type'     => 'text',
						'title'    => esc_html__( 'Twitter Consumer Key', 'bakery-options' ),
						'desc'     => wp_kses( __( '1. Go to "https://dev.twitter.com/apps", login with our twitter account and click "Create a new application".<br>2. Fill out the required fields, accept the rules of the road, and then click on the "Create your Twitter application"<br>3. Once the app has been created, click the "Create my access token" button.<br>4. You are done! You will need the following data later on', 'bakery-options' ), array('br' => array()) ),
						'default'  => ''
					),
					array(
						'id'       => 'twitter-consumer-secret',
						'type'     => 'text',
						'title'    => esc_html__( 'Twitter Consumer Secret', 'bakery-options' ),
						'default'  => ''
					),
					array(
						'id'       => 'twitter-user-token',
						'type'     => 'text',
						'title'    => esc_html__( 'Twitter Access Token', 'bakery-options' ),
						'default'  => ''
					),
					array(
						'id'       => 'twitter-user-secret',
						'type'     => 'text',
						'title'    => esc_html__( 'Twitter Access Token Secret', 'bakery-options' ),
						'default'  => ''
					)
				)
			);
			
			//Cookie Consent
			$this->sections[] = array(
				'title'  => esc_html__( 'Cookie Consent', 'bakery-options' ),
				'desc'   => wp_kses( __( 'To customize cookie conset please use <a href="https://www.osano.com/cookieconsent/download/" target="_blank">this</a> link. Click Start Coding button, go over configuration wizard and finally copy and paste the generated code here.', 'bakery-options' ), array('a' => array('href' => array(), 'target' => array())) ),
				'icon'   => 'fa-solid fa-cookie-bite',
				'fields' => array(
					array(
						'id'       => 'cookieconsent-show',
						'type'     => 'switch',
						'title'    => esc_html__( 'Show Cookie Consent?', 'bakery-options' ),
						'on'       => esc_html__( 'Yes', 'bakery-options' ),
						'off'      => esc_html__( 'No', 'bakery-options' ),
						'default'  => false
					),
					array(
						'id'       => 'cookieconsent-head-code',
						'type'     => 'text',
						'required' => array( 'cookieconsent-show', '=', true ),
						'title'    => esc_html__( 'Head Code', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter generated head code.', 'bakery-options' ),
						'class'    => 'vu_fullwidth',
						'default'  => '<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/cookieconsent@3/build/cookieconsent.min.css" />',
					),
					array(
						'id'       => 'cookieconsent-body-code',
						'type'     => 'textarea',
						'required' => array( 'cookieconsent-show', '=', true ),
						'title'    => esc_html__( 'Body Code', 'bakery-options' ),
						'desc'     => esc_html__( 'Enter generated body code.', 'bakery-options' ),
						'default'  => '<script src="https://cdn.jsdelivr.net/npm/cookieconsent@3/build/cookieconsent.min.js" data-cfasync="false"></script><script>window.cookieconsent.initialise({ "palette": { "popup": { "background": "#f9f9f9" }, "button": { "background": "#fdb822", "text": "#ffffff" } }, "showLink": false, "theme": "classic"});</script>',
					)
				)
			);
			
			//Custom Code
			$this->sections[] = array(
				'title'  => esc_html__( 'Custom Code', 'bakery-options' ),
				'icon'   => 'fa-solid fa-code',
				'fields' => array(
					array(
						'id'       => 'custom-css',
						'type'     => 'ace_editor',
						'title'    => esc_html__( 'CSS Code', 'bakery-options' ),
						'subtitle' => esc_html__( 'Enter custom CSS code here.', 'bakery-options' ),
						'mode'     => 'css',
						'theme'    => 'monokai',
						'desc'     => wp_kses( __( 'Possible modes can be found at <a href="https://ace.c9.io" target="_blank">https://ace.c9.io/</a>.', 'bakery-options' ), array('a' => array('href' => array(), 'target' => array())) ),
						'default'  => ''
					),
					array(
						'id'       => 'custom-js',
						'type'     => 'ace_editor',
						'title'    => esc_html__( 'JS Code', 'bakery-options' ),
						'subtitle' => esc_html__( 'Enter custom JS code here.', 'bakery-options' ),
						'mode'     => 'javascript',
						'theme'    => 'monokai',
						'desc'     => wp_kses( __( 'Possible modes can be found at <a href="https://ace.c9.io" target="_blank">https://ace.c9.io/</a>.', 'bakery-options' ), array('a' => array('href' => array(), 'target' => array())) ),
						'default'  => ''
					)
				)
			);

			$this->sections[] = array(
				'type' => 'divide'
			);

			//Import / Export
			$this->sections[] = array(
				'title'  => esc_html__( 'Import / Export', 'bakery-options' ),
				'desc'   => esc_html__( 'Import and Export your theme settings from file, text or URL.', 'bakery-options' ),
				'icon'   => 'fa-solid fa-rotate',
				'fields' => array(
					array(
						'id'         => 'import-export',
						'type'       => 'import_export',
						'title'      => esc_html__('Import Export', 'bakery-options' ),
						'subtitle'   => esc_html__( 'Save and restore your theme options', 'bakery-options' ),
						'full_width' => false,
					),
				)
			);

			$this->sections[] = array(
				'type' => 'divide'
			);

			//Theme Information
			$this->sections[] = array(
				'icon'   => 'fa-solid fa-circle-info',
				'title'  => esc_html__( 'Theme Information', 'bakery-options' ),
				'fields' => array(
					array(
						'id'      => 'theme-info',
						'type'    => 'raw',
						'content' => $theme_info,
					)
				)
			);

			if ( $this->check_theme_license() ) {
				$this->sections[] = array(
					'type' => 'divide'
				);

				//Install Demo Content
				$this->sections[] = array(
					'id'     => 'wbc_importer_section',
					'icon'   => 'fa-solid fa-hand-pointer',
					'title'  => esc_html__( 'Install Demo Content', 'bakery-options' ),
					'desc'   => '
						<div style="overflow: hidden;">
							<div style="background-color: #F5FAFD; margin: 0px 0px 15px 0px; padding: 0 15px; color: #0C518F; border: 1px solid #CAE0F3; clear:both; line-height:18px;">
								<p class="tie_message_hint">Importing demo content is the easiest way to setup your site. It allows you to quickly edit everything instead of creating content from scratch. When you import the data please be aware of the followings:</p>

								<ul style="padding-left: 20px; list-style-position: inside; list-style-type: square;">
									<li>Make sure that no other posts, pages or media already exist.</li>
									<li>To reset your installlation we recommend to use <a href="' . admin_url( '/plugin-install.php?s=wp-reset&tab=search&type=term' ) . '" target="_blank">WP Reset</a> plugin.</li>
									<li>Posts, pages, images, widgets and menus will be imported.</li>
									<li>Current active widgets will be deactivated.</li>
									<li>Images shown in demo pages are copyrighted and come with a watermark when imported.</li>
									<li>Import process might take couple of minutes.</li>
								</ul>
							</div>

							<div style="background-color: #FFC7C7; margin: 10px 0 15px 0px; padding: 0 15px; color: #7B0000; border: 1px solid #FF7C7C; clear:both; line-height:18px;">
								<p class="tie_message_hint" style="margin: 15px 0 15px 0;">Before you begin, make sure <code>max_execution_time</code> is at least <code>300</code>, <code>memory_limit</code> is at least <code>256M</code> and all the required plugins are activated.</p>
							</div>
						</div>
					',
					'fields' => array(
						array(
							'id'   => 'wbc_demo_importer',
							'type' => 'wbc_importer'
						)
					)
				);
			} else {
				add_filter( 'wbc_importer_abort', '__return_false' );
			}
		}

		public function set_arguments() {
			$this->args = array(
				'opt_name'             => 'bakery_theme_options',
				'display_name'         => $this->theme->get( 'Name' ),
				'display_version'      => $this->theme->get( 'Version' ),
				'menu_title'           => esc_html__( 'Bakery', 'bakery-options' ),
				'page_title'           => esc_html__( 'Bakery Options', 'bakery-options' ),
				'admin_bar_icon'       => 'dashicons-admin-generic',
				'page_slug'            => 'bakery_options',
				'page_permissions'     => 'edit_theme_options',
				'page_priority'        => 99,
				'dev_mode'             => false,
				'forced_dev_mode_off'  => true,
				'update_notice'        => false,
				'show_import_export'   => true,
				'show_options_object'  => true,
				'footer_credit'        => wp_kses( __('Copyright &copy; 2024 <a href="https://themeforest.net/user/milingona_/portfolio" target="_blank">Milingona</a>. All Rights Reserved.', 'bakery-options'), array('a' => array('href' => array(), 'target' => array())) )
			);
		}
	}

	global $Redux_Framework_Bakery_Options;

	$Redux_Framework_Bakery_Options = new Redux_Framework_Bakery_Options();
}
