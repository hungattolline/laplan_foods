<?php 
/*
	Plugin Name: Bakery Options
	Plugin URI: http://milingona.co/
	Author: Milingona
	Author URI: http://themeforest.net/user/milingona
	Description: This plugin is required in order for the theme to work properly. It includes advanced and flexible options that have been developed exclusively for this theme.
	Version: 2.8.1
	Text Domain: bakery-options
	Domain Path: /languages
	License: GNU General Public License v2.0
	License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/

if ( ! defined( 'ABSPATH' ) ) exit();

// Check if purchase code is valid or current theme is 'bakery'
$bakery_purchase_code = get_option( 'envato_purchase_code_11112118', '' );
$bakery_purchase_code = $bakery_purchase_code ?? get_option( '_bakery_theme_license', '' );
$bakery_theme_info = json_decode( get_option( '_bakery_theme_info', '' ), true );

if ( empty( $bakery_purchase_code ) || strlen( $bakery_purchase_code ) != 36 || ( ! isset( $bakery_theme_info['name'] ) && $bakery_theme_info['name'] != 'bakery' ) ) {
	return;
}

if ( ! class_exists( 'Bakery_Options' ) ) {
	class Bakery_Options {
		public static $_version = '2.8.1';
		public static $_dir;
		public static $_url;
		
		public function __construct() {
			// Variables
			self::$_dir = plugin_dir_path( __FILE__ );
			self::$_url = plugin_dir_url( __FILE__ );

			// Framework
			require_once( self::$_dir . 'framework/framework.php' );
			
			// Options
			require_once( self::$_dir . 'options.php' );
			
			// Demo Import
			require_once( self::$_dir . 'demo-import.php' );

			// Actions
			add_action( 'init', array( $this, 'load_plugin_textdomain' ) );
		}

		// Plugin Textdomain
		public function load_plugin_textdomain() {
			load_plugin_textdomain( 'bakery-options', false, self::$_dir . 'languages/' );
		}
	}
}

$Bakery_Options = new Bakery_Options();
